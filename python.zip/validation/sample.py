def check_age(age):
    if(age>=23 and age<=60):
        return age


    else:
        message = '''Invalid Age
        Age must between 23 and 60'''
        raise ValueError(message)



