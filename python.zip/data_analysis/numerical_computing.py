# Find the  yield of apple

# yield_of_apple = w1*temperature + w2*rainfall + w3*humidity

#  we will fimd the yield of apple by using weighted sum of temp,rainfall and humidity


w1,w2,w3=0.3,0.2,0.5

# Region        temp(f)     rainfall(mm)        humidity(%)
# Kanto         73          67                      43
# Johto         91          88                      64
# Hoenn         87          134                     58
# Sinnoh        102         43                      37
# Unova         69          96                      70


#find the yield in Kanto

kanto_temp=73
kanto_rainfall=67
kanto_humidity=43

kanto_yield_apples=kanto_temp*w1+kanto_rainfall*w2+kanto_humidity*w3
print("The expected yield of apple in kanto region is "+ str(kanto_yield_apples)+"tons per hector")

kanto=[73,67,43]
johto=[91,88,64]
hoenn=[87,134,58]
sinnoh=[102,43,37]
unova=[69,96,70]
