def add(a,b):
    print("summation is:",a+b)

add(10,23)
add(b=30,a=-10)#calling function using name and argument
