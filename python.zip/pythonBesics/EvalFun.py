res=eval(input("Enter your value:"))
print(res)
print((type(res)))