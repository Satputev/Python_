def display():
    
    print("hello i am display")

def show():
    print("I am show")
    display()
display()
show()
