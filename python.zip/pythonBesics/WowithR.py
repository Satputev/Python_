def add(arg1,arg2):
    return(arg1+arg2)

def sub(arg1,arg2):
    print("sum is=",add(arg1,arg2))
    return (arg1-arg2)

def mul(arg1,arg2):
    print("sub=",sub(arg1,arg2))
    return (arg1*arg2)

def div(arg1,arg2):
    print("mul is=",mul(arg1,arg2))
    return (arg1/arg2)

no1=int(input("Enter 1st no:"))
no2=int(input("Enter 2nd no:"))

print("Division is",div(no1,no2))