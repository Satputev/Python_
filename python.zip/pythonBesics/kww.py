from PIL import Image
Image.open("jerry.jpg").show()
Image.open("jerry.jpg").rotate(128).convert("L").show()
