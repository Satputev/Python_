#function without argument with return
#"return is keyword"
#return is used to return a object from input defination to called place
#return must be last in function defination because once the return statement executed the
#the controller will exit the fnction defination


def add():
    a=int(input("Enter first no:"))
    b=int(input("Enter the second no:"))
    return a+b

x=add()
print("sum =",x)
print("the sum = ",add())