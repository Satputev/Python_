def add(arg1=0,arg2=0):
    print(arg1+arg2)

add(10,20)    #30
add("hello","world")#hello world
add(True,100)#101
#add(True,"hello")#TypeError: unsupported operand type(s) for +: 'bool' and 'str'
add(False,True)#1
add(arg2=23.5,arg1=0.2)#23.7
