count = 0
def wish():
    print("this is wish function...")
    global count
    count+=1
    if (count !=10):
        wish()

wish()