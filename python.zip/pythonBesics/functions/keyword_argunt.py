def details(**data):
    print(data)

details(name="ravi")
details(srno=101,name="ravi",salary=185000.0,workes=["developer","python","django"])
#
# {'name': 'ravi'}
# {'srno': 101, 'name': 'ravi', 'salary': 185000.0, 'workes': ['developer', 'python', 'django']}