def do_sum(*no):
    print("Sum=",sum(no))

do_sum(10,20,30)