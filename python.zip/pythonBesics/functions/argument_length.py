def display(*arg):
    for x in arg:
        print(x,end=" ")
    print()

display(10)
display(10,20)
display(10,20,30)
display(10,20,30,"sathya")