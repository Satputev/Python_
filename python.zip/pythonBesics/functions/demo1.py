#combination of all
def add(x,*y,**n1):
    print(x,y,n1)

add(101,102,103,rno=10)

#101 (102, 103) {'rno': 10}

print("----------------------------")

def show(*y,x,**z):
    print(y,x,z)
show(10,20,30,x=40,name="Ravi")#(10, 20, 30) 40 {'name': 'Ravi'}

