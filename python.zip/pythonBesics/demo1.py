no = int(input("Enter the number"))
lis = []
i = 1
for x in range(1, no):
    if (no % x == 0):
        lis.append(x)


if len(lis )>2:
    print("it is not prime no")
else:
    print("it is the prime no")


