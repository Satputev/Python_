import keyword as kw
print(kw.kwlist)
print(len(kw.kwlist))
