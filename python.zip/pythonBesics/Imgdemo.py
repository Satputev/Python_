from PIL import Image
Image.open("jerry.jpg").rotate(120).convert("L").save("AiOjerry.jpg").show()#we cannot do save and show in one program
