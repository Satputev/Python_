emp={"idno":101,"name":"Ravi","salary":185000.00}

#to print value from dictionary
print(emp["idno"])#101
print(emp["name"])#Ravi

print(emp["salary"])#Ravi

