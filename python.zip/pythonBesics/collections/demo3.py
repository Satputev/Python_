#modification on dictionary

#dict of 1 employee

emp={"idno":101,"name":"Ravi","salary":185000}
print(emp)#{'idno': 101, 'name': 'Ravi', 'salary': 185000}

emp["salary"]=225000
print(emp)#{'idno': 101, 'name': 'Ravi', 'salary': 225000}


emp["status"]=False
print(emp)#{'idno': 101, 'name': 'Ravi', 'salary': 225000, 'status': False}
