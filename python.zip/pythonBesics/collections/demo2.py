#dict example of three employee

emps={"101":{"name":"Ravi","salary":185000},
      "102":{"name":"Kumar","salary":145000},
      "103":{"name":"mohan","salary":130000}
      }
#print 103 employee details

print(emps["103"]["name"])#mohan

print(emps["103"]["salary"])#130000
