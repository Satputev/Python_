year=int(input("Enter the year:"))
month=int(input("Enter the month[1-12]"))
day=int(input("Enter the date[1-31]"))

if month in range(1,13):
    if day in range(1,32):
        if(month==12 and day==31):
            year+=1
            month=1
            day=1
            print("Next day is[yy-mm-dd]",str(year)+" "+ str( month)+" " +str(day))
        elif(day==31):
            day=1
            month+=1
            print("Next day is[yy-mm-dd]",str(year)+" "+ str( month)+" " +str(day))
        else:
            day+=1
            print("Next day is[yy-mm-dd]",str(year)+" "+ str( month)+" " +str(day))
    else:
        print("Enter the valid date...")

else:
    print("Enter the valid month...")




