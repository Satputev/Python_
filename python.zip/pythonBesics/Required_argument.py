def add(arg1,arg2):
    print("summation is",arg1+arg2)
    print("substraction is",arg1-arg2)
    print("multifiaction is",arg1*arg2)
    print("division is",arg1/arg2)


add(10,20)
add(10,20.5)
add(False,True)
#add(10,[10,20,30])#TypeError: unsupported operand type(s) for +: 'int' and 'list'

# add("hello",3)      #TypeError: can only concatenate str (not "int") to str

add("hello","world")#only addition is possible
