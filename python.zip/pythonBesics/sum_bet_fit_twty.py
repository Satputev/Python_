no1=int(input("Enter the 1st no:"))
no2=int(input("Enter the 2nd no:"))

def displaySum(no1,no2):
    sum=no1+no2
    if(15<=sum<=20):
        print("sum=",20)
    else:
        print("Sum=",sum)

displaySum(no1,no2)