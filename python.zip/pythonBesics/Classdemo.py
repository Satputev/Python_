ins_id = "satya"


class Student:
    subject = "python"


class Faculty:
    sub1 = "python"
    sub2 = "django"


print(ins_id)
print(Student.subject)
print(Faculty.sub1)
print(Faculty.sub2)
