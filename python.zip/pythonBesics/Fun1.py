def display():
    print("hello")
    print("thanks")

print("hello")
display()
print("bye")
