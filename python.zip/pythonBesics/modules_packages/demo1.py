#using admin login details

from pythonBesics.cms.admin.login import *
print("Username:",u_name,"\nPassoword:",upwd)