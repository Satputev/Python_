#using time variable and wish function

from pythonBesics.cms.admin.welcome import time,wish
print(time)#10.45
wish()#welcome