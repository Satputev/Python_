#getting salary from salary
from pythonBesics.cms.admin.accounts.salary import salary
print(salary)#185000.0
