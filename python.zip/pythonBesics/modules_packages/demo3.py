#using time variable from welcome

from pythonBesics.cms.admin.welcome import time
print(time)#10.45
