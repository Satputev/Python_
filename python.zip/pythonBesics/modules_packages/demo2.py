#calling wish function from welcome
from pythonBesics.cms.admin.welcome import wish
wish()#welcome
