#2 leap_year
year=int(input("Enter the year"))
print(year)
if(year%400==0 and year%100!=0 or year%4==0):
    print(year,"is the leap year")
else:
    print("Not leap year")
