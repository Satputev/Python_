from PIL import Image
Image.open("jerry.jpg").show()
Image.open("jerry.jpg").rotate(180).show()
Image.open("jerry.jpg").rotate(111).save("RRjerry.jpg")
Image.open("jerry.jpg").convert("L").show()
Image.open("jerry.jpg").convert("L").save("BBWWjerry.jpg")
