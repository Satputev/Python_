def fun1():
    print("I m one")
    fun2()
def fun2():
    print("Im two")
    fun3()
def fun3():
    print("iam here...Three...")
print("hello...")
fun3()
fun1()
fun2()
print("bye")
