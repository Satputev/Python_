ins_name="Satya"

class Pfaculty:
    sub_one="python"
    sub_two="Django"

    @staticmethod
    def Display_sub():
        print(ins_name)
        print(Pfaculty.sub_one,Pfaculty.sub_two)


Pfaculty.Display_sub()

x=lambda arg1,arg2,arg3:arg1+arg2+arg3
sum=x(10,20,30)
print(sum)