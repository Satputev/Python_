no=int(input("Enter the no:"))
for x in range(1,no+1):
    print("table:",x,end="      ")
print()
for x in range(1,no+1):
    for y in range(1,11):
        print(x*y,end="             ")
    print()

