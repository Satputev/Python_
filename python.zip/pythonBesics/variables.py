idno=13132131
#print(idno)
print(type(idno))

                      #with same name it will point to latest object and destry previous obj
idno="aaaa" 
print(idno)
print(type(idno)) #<class 'str'>

print("--------------------------------------")
a=1111
print(id(a))    #60199104    #if multivariables handling same value will be refer to same obj
b=1111
print(id(b))    #60199104

print("-----------------------------------------")
name="'Python'"
print(name)
print(type(name))#<class 'str'>

x=True
print(x)
print(type(x))#<class 'bool'>

trippleQu="""Tripple quotes demo"""
print(trippleQu)

x,y,z,w=10,20,30,40
print(x,y,z,w)
print(z)
print(type(x))

sal=1,00,32,21,9
print(sal)
print(type(sal))#<class 'int'>



val=10,20,30,40  #whenever you put values with quoma seperated then it acts as tuple() is called packing
print(val,sal)   
print(type(val))#<class 'tuple'>

print("-----------------------------------------")

a,b,c=101,"hello",True
print(a,b,c)

