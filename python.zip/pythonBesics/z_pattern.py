print("****")
for x in range(4):
    for y in range(2,x,-1):
        print(" ",end="")
    for z in range(x):
        print("*",end="")
    print()