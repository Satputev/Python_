days=[31,28,31,30,31,30,31,30,31,30,31,30]
months=["Jan","Feb","March","April","May","June","July","August","Sept","Oct","Nov","Dec"]

month=input("Enter the month:")

if(month in months):
    index=months.index(month)
    print("Matching day is:",days[index])
else:
    print("Invalid Month..")