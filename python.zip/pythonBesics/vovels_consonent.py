vovels=["A","E","I","O","U"]
consonent=["B","C","D","F","Q","R","S","T","G","H","J","K","V","W","X","L","M","N","P","Y","Z"]

alphabet=input("Enter the capital alphabet:")

if(alphabet in vovels):
    print(alphabet,"is Vovel")
elif(alphabet in consonent):
    print(alphabet,"is consonent")
else:
    print("Enter the valid alphabet")

