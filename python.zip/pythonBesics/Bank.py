ATM_NAME="Ammerpet SBI ATM"

def Deposit(name,accno,ammount):
    
    
    print("WELCOME: ",name," AcccountNo: ",accno," ammount=: ",ammount)
    print("Transaction Sucessfull  !!!!!!")
          
def Withdraw(name,accno,ammount):
        print("AccHolderName ",name,"AcccountNo: ",accno,"ammount=: ",ammount)
        print("Transaction Sucessfull  !!!!!!")
        print("collect your cash")
        

print("Welcome to",ATM_NAME)
Deposit("Ravi",56984568956,900000)
Withdraw("SAI",95886523549,5000)
print("thank you for choosing SBI,Have a nice day")              
