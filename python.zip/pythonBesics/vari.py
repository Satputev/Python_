a=100,200,"trug",False
def VariDemo():
    print("hello")
    print(a)
    print(type(a))
VariDemo()

