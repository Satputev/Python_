a1=int(input("Enter 1st angle:"))
a2=int(input("Enter the 2nd angle:"))
a3=int(input("Enter the 3rd angle:"))

if(a1+a2+a3==180):
    if (a1 == a2 == a3):
        print("equilateral triangle...")
    elif (a1 != a2 != a3):
        print("Sclence triangle..")
    else:
        print("Isoscles triangle...")

else:
    print("Enter the valid angles..")
    print("sum of all angle should be equal to 180..")