#write a script to validate the atm pin no
#If pin no is not valid allow user for 3 attempts only
#if 3rd attempt is also invalid then show your account is blocked else show welcome User
#for 2nd and 3rd attempts ask user to continue or not

for x in range(3):
    pin = int(input("Enter the pin:"))
    if (pin == 6528):
        print("Welcome User")
        break
    else:
        print("Invalid User")
        if(x<2):
            ans=int(input("Do you want to Continue?? press 1:"))
            if(ans==1):
                continue
            else:
                print("thanks for using NMK ATM")
                break
        else:
            print("Your account is blocked..")
print("Visit again")