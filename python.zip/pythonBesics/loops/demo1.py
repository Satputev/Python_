#1 2 3
#1 2 3
#1 2 3


for r in range(3):
    for c in range(3):
        print(c+1, end=" ")
    print()
print("===============================================")
#1 2 3
#4 5 6
#7 8 9

counter=1
for r in range(3):
    for c in range(3):
        print(counter,end=" ")
        counter+=1
    print()

print("------------------------------------------")

#A B C
#D E F
#G H I

counter=65
for r in range(3):
    for c in range(3):
        print(chr(counter),end=" ")
        counter+=1
    print()

print("-----------------------------------------")

#A A A A A
#B B B B B
#C C C C C
#D D D D D
#E E E E E
counter=65
for x in range(5):
    for y in range(5):
        print(chr(counter),end=" ")
    counter+=1
    print()

print("--------------------------------------")

#9 8 7
#6 5 4
#3 2 1
counter=9
for r in range(3):
    for s in range(3):
        print(counter,end=" ")
        counter -=1
    print()
print("-------------------------------------")

#0 1 2 3 4
#5 6 7 8 9
#0 1 2 3 4
#5 6 7 8 9


counter=0
for r in range(4):
    if r==2:
        counter=0
    for c in range(5):
        print(counter,end=" ")
        counter +=1

    print()
print("----------------------------------------")
