for x in range(1,11):
    print(x,end=" ")
else:
    print("\nNos from 1 to 11")


# 1 2 3 4 5 6 7 8 9 10
# Nos from 1 to 11

print("--------------------------")

for x in range(1,11):
    if(x==6):
        break
    print(x,end=" ")
else:
    print("\nNo from 1 to 11")

# 1 2 3 4 5

print("\n---------------------------------")
for x in range(1,11):
    if(x==6):
        continue
    print(x,end=" ")
else:
    print("\n no from 1 to 11")

# 1 2 3 4 5 7 8 9 10
#  no from 1 to 11