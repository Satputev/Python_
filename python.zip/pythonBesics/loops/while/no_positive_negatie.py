no=[]
for x in range(10):
    no.append(int(input("Enter the no:")))

p_sum = 0
n_sum = 0

for x in no:
    if(x>=0):
        p_sum+=x
    else:
        n_sum+=x
print("Positive sum=",p_sum,"\n negative sum=",n_sum)

#using reduce function
p=[]
n=[]
from functools import reduce
res=reduce(res=(lambda x: p.append(x)if x>=0 else n.append(x),no))
print("positive nos:",sum(p),"\nnegative no:",sum(n))