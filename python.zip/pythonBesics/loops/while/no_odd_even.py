no=int(input("Enter the no:"))
odd_sum=0
even_sum=0
while no!=0:
    r=no%10
    no=no//10
    if(r%2==0):
        even_sum+=r
    else:
        odd_sum+=r
print("OddDigitSum:",odd_sum)
print("EvenDigitSum:",even_sum)