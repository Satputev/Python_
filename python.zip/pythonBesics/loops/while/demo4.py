n=10
sum=0
while(n>0):
    r=n%10
    n=n//10
    sum=sum*10+r
print("sum is:",sum)
    