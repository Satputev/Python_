n=1
while(n<=5):
    print(n,end="\t")
n=n+1
print("Thank you")

#printing 1 1 1 in infinite no of time