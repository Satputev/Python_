import random
sys_num=random.randint(1,10)

print("Guess number Game")

while True:
    user_no=int(input("Enter the no between (1-10):"))
    if sys_num==user_no:
        print("Your guess is correct..")
        break
    else:
        print("Try again..")
        continue