no=int(input("Enter the no:"))

sum=0
count=1
while no!=0:
    r=no%10
    no=no//10
    if count%2==0:
        sum+=r

    count+=1
print(sum)