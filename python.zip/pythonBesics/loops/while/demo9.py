for i in range(5):
    while(i<5):
        print(i,end="\t")
        i+=1
    print()

#0	1	2	3	4
#1	2	3	4
#2	3	4
#3	4
#4