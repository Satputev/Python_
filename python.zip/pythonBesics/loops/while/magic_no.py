no=int(input("Enter the no:"))
No=no*no
sum=0
while( No!=0):
    r=No%10
    No=No//10
    sum+=r

if(sum==no):
    print(no,"Is magic no..")
else:
    print(no,"Is not magic no..")