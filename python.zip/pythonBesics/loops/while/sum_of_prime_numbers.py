no=int(input("Enter the no:"))

sum=0
count=2
while no!=0:
    r=no%10
    no=no//10
    if(r==2 or r==3  or r==5 or r==7):
        sum+=r
print(sum)
