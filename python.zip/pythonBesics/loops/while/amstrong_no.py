no=int(input("Enter the no:"))
No=no
sum=0
while no!=0:
    r=no%10
    no=no//10
    sum=sum+r**3

if(sum==No):
    print(No,"is Amstrong no...")
else:
    print(No," is not armostrong no")