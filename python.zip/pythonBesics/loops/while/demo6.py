n=6
while(n<0):
    print(n,end="\t")
    n-=1
print("Thank you")