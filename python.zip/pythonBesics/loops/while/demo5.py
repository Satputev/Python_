n=2
while(n>0):
    print(n,end="\t")
    n-=1