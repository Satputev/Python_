#WAP to print 1 to 10 no:

no=1
while no<=10:
   print(no)
   no+=1

