no=int(input("Enter the no:"))

if no>0:
    def factorial(no):
        return 1 if (no == 1 or no == 0) else no * factorial(no - 1)


    print("Factorial of", no, ": is", factorial(no))
else:
    print("Enter the valid no..")




