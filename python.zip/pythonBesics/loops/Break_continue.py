#without continue and without break

for x in range(1,11):
    print(x,end=" ")#1 2 3 4 5 6 7 8 9 10
print("\nThanks..")#Thanks..

print("-------------------------------")
#with break

for x in range(1,11):
    if(x==6):
        break
    print(x,end=" ")#1 2 3 4 5
print("\n--------------------------------")

#using continue

for x in range(1,11):
    if(x==6):
        continue
    print(x,end=" ")  #1 2 3 4 5 7 8 9 10
print("\n----------------------------")