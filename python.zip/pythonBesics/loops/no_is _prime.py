no=int(input("Enter the no:"))

if no>1:
    for x in range(2, no):
        if (no % x == 0):
            print(no,"is not a prime no..")
            break
    else:
        print(no,"is Prime no")
else:
    print(no,"is not prime no")