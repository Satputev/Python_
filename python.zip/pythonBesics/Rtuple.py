def details():
    id=int(input("Enter 1st no:"))
    name=input("Enter name")
    sal=float(input("Enter salary:"))
    return id,name,sal  #note:function can return one object only....here packing is doing and it return
#tuple class object
res=details()
print(res)#(10, 'ravi', 850000.0)

print(type(res))#<class 'tuple'>
