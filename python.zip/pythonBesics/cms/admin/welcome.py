def wish():
    print("welcome")
time=10.45
