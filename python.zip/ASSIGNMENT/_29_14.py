speed=int(input("Enter the speed of the car:"))
time=int(input("Enter the time:"))
distance=speed*time
print("Total distance traveled by a car is:",distance)
distance=speed*6

print("Total distance traveled by a car in 6 hours is:",distance)
distance=speed*10
print("Total distance traveled by a car in 10 hours is:",distance)

distance=speed*15
print("Total distance traveled by a car in 15 hours is:",distance)

