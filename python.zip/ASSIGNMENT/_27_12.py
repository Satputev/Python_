acre=43560
srf=int(input("Enter the total square feet:"))
new_acr=srf/acre
print("Total acre is:",new_acr)
nwacr=float(input("Enter the Acre:"))
new_scr=nwacr*acre
print("Total sqrFeet is",new_scr)