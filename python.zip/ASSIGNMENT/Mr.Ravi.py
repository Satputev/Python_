product1=eval(input("Mr.Ravi Enter product cost"))
produt2=eval(input("Mr.Ravi Enter product cost"))
print("Mr.Rvai its time to pay the bill.....\nproduct1 cost is:",product1,"\nProduct2 cost is",produt2,"\n---------------------"
                                        "-----\nTotal bill is:",product1+produt2)


#product1 cost is: 2500
#Product2 cost is 3000
#--------------------------
#Total bill is: 5500


