one_pt_biryani=eval(input("Enter the biryani price: "))
one_pt_mnctn=eval(input("input manchurian price:"))


total_biryani_cost=2*one_pt_biryani
total_manchurian_cost=3*one_pt_mnctn

print("2 biryani cost :",total_biryani_cost)
print("3 manchurian cost:",total_manchurian_cost)


print("------------------------------------")
print("Total bill is:",total_manchurian_cost+total_biryani_cost)
print("-------------------------------------")
print("Each one share ammount:",(total_biryani_cost+total_manchurian_cost)/3)
print("-------------------------------------")