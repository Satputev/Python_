print("welcome to CTC...")
name=input("Whats your name")
lCost=eval(input("Enter laptop price:"))
bill_ammount=lCost
discount_ammount=((bill_ammount*15)/100)
total_to_pay=bill_ammount-discount_ammount

print("Customer name:",name,"\nBill Ammount:",bill_ammount,"\nDiscount Ammount:",discount_ammount,"\nTotal To pay:",total_to_pay)


#welcome to CTC...
#Whats your nameRavi
#Enter laptop price:46500
#Bill Ammount: 46500
#Discount Ammount: 6975.0
#Total To pay: 39525.0


