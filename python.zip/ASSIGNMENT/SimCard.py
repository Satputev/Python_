p_s1=eval(input("Enter first 1st sim card price"))
p_s2=eval(input("Enter first 2nd sim card price"))
p_s3=eval(input("Enter first 3rd sim card price"))
p_s4=eval(input("Enter first 4th sim card price"))

total_sim_cost=p_s1+p_s2+p_s3+p_s4
print("Total sim price is:",total_sim_cost)

#Enter first 1st sim card price230
#Enter first 2nd sim card price125
#Enter first 3rd sim card price352
#Enter first 4th sim card price123
#Total sim price is: 830
