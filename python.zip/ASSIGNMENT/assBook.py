#print("Hello student this is \'Naveen\',I am a \"python\"faculty in \"satya\"\nmy contact No is:\'9052492329\'")
#print("satya"+"technology")
#print(12/2)#6.0
#print("satya","technology")#satya technology
#print("core","-","python")
#print("\n","satya","-","tech")# satya - tech
#print("python"+3)#can only concatenate str (not "int") to str
#print(3+3+"Python")#TypeError: can only concatenate str (not "int") to str
#print("7"-2)
#print("sathya"-"technology")#TypeError: unsupported operand type(s) for -: 'str' and 'str'
#print("**sathya Technology**)
#      print("\n---Python---")
#print("\t\tNaveen\tKumar")
#print("\t\t=========")
#27
#print("welcome to satya technology")#welcome to satya technology

#28
#name=input("Enter name:")#Enter name:naveen
#print("welcome",name)#welcome naveen

#29
#no1=int(input("Enter 1st no:"))#Enter 1st no:10

#no2=int(input("Enter 2st no:"))#Enter 2st no:5

#print("sum is:",no1+10
# no2)
#print("Sub is:",no1-no2)
#print("mul is:",no1*no2)
#print("div is:",no1/no2)

#30

#a=eval(input("Enter any thing:"))#Enter any thing:10,20,"hello"
#print(type(a))#<class 'tuple'>

#31
#fName=input("Enter 1st name:")
#lName=input("Enter last name")
#print("Full name is:",fName+lName)

#32

#str=input("Enter  no:")
#no=int(str)
#print(no)
#print(type(no))

#33
#val=input("Enter float value")
#val=float(val)
#print("The float value is:",val)
#print(type(val))


#34
#stno=int(input("Enter studentNo:"))
#stName=input("Enter name:")
#mark1,mark2,mark3=int(input(("Enter first mark"))),int(input(("Enter second sub mark:"))),int(input(("Enter third sub mark")))
#totalM=mark1+mark2+mark3
#avgm=totalM/3
#print("Idno:",stno,"Stname is:",stName,"Total marks:",totalM,"avgMarks:",avgm)#Idno: 1 Stname is: Ravi Total marks: 83 avgMarks: 27.666666666666668

#35
#no1=int(input("Enter first no"))
#no2=int(input("Enter second no"))
#temp=0

#def swap(no1,no2):
 #   temp=no1;
  ## no2=temp

    #return no1,no2

#print("Swapped no is:",swap(no1,no2))

#36

#eid=int(input("Enter the EmployeeID:"))
#ename=input("enter the Employee name:")
#bsal=float(input("Enter the besic salary"))
#hra=float(input("Enter the hra"))
#da=float(input("Enter the da"))

#print("Gross Sal:",bsal+hra+da)

#p,q,r=10,20,30,12#ValueError: too many values to unpack (expected 3)
a=10
A=20
print(a)