l_sal=eval(input("Enter salary:"))
ta=l_sal*10/100
da=l_sal*8/100
hra=l_sal*12/100

total_sal=ta+da+hra+l_sal
monthly_sal=total_sal/12
print("Total salary",total_sal)
print("Allowence:",ta+da+hra)
print("total monthly salary is:",monthly_sal)