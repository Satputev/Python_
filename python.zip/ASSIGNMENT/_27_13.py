p1=float(input("Enter 1st product price:"))
p2=float(input("Enter 2st product price:"))
p3=float(input("Enter 3st product price:"))
p4=float(input("Enter 4st product price:"))
p5=float(input("Enter 5st product price:"))

total_amt=p1+p2+p3+p4+p5
print("The sub total is:",total_amt)
print("The sale tax is:",total_amt*0.07)
print("The total ammount with tax is:",total_amt+total_amt*0.07)