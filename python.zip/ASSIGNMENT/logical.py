
a=6.43
b=20
c=30
#print(a,b,c,end="-")
print("a={0}".format(a))