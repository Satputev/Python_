pkg=float(input("Enter the package amt:"))
print("monthly sal is:",pkg/12)