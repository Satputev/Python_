#accept float and convert float to string
print("Float to string value is:",input("Enter float value:"))
#Enter float value:10.30
#Float to string value is: 10.30
