#Write a python program to find a max of three no

def findMax(arg1,arg2,arg3):
    if(arg1>arg2):
        if(arg1>arg3):
            return arg1
        else:
            return arg3
    elif(arg2>arg3):
        return arg2
    else:
        return arg3


print("max is",findMax(40,30,20))

print("max is",findMax(10,30,20))
print("max is",findMax(20,10,30))
print("max is",findMax(30,10,20))




