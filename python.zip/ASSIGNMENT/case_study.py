name=input("Enter your name: ")
code=0
for x in range(len(name)):
    code+=(ord(name[x])-96)
print(code)
def lucky(code):
    sum = 0
    if code>9:
        while code != 0:
            r = code % 10
            code = code // 10
            sum += r
        x=sum
        if x>0 and x<=9:
            print("Your lucky no is: ",x)
        else:
            lucky(x)

    else:
        print("Your lucky no is: ", code)

lucky(code)


