total_sales=float(input("Enter projected ammount of sales:"))
annual_profit=total_sales*0.22
print("The profit is:",annual_profit)
