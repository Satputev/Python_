p_price=int(input("Enter the product price:"))
gst=(10/100)
gstAmt=p_price*gst
print("Bill ammount is:",p_price)
print("GST is:        10%")
print("Gst Ammount:",gstAmt)
print("--------------------------------")
print("Total Bill is:",p_price+gstAmt)
print("---------------------------------")
