p1=float(input("Enter 1st product price:"))
p2=float(input("Enter 2nd product price:"))
p3=float(input("Enter 3rd product price:"))
print("Prod-1 cost      :",p1)
print("Prod-2 cost      :",p2)
print("Prod-3 cost      :",p3)
total_bill=p1+p2+p3
discount=total_bill*0.1
print("Total bill is:",total_bill)
print("Discount(10%)Amt:",discount)
print("Final Bill is:",total_bill-discount)
print("Customer paid:",total_bill)
print("Balance Amt:",discount)