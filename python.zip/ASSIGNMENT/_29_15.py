amt=float(input("Enter the purchase ammount:"))

sgst=amt*0.05;
cgst=amt*0.025

print("Total purchase ammount:",amt)
print("State tax:",sgst)
print("Central tax:",cgst)
print("Total ammount:",amt+sgst+cgst)