#1
for i in range(1,5,1):
    print(i,end=" ")#1 2 3 4

#2--------------------------------------
print("\n-----------------------------------------")
for x in range(10):
    print(x,end=" ")#0 1 2 3 4 5 6 7 8 9
print("\n-----------------------------------------")

#3
for x in range(2,11,2):
    print(x,end=" ")#2 4 6 8 10

print("\n-----------------------------------------")
#4
for x in range(10,1):
    print(x,end=" ")#no output
print("\n-----------------------------------------")
#5
for x in range(10,1,-1):
    print(x,end=" ")#10 9 8 7 6 5 4 3 2

print("\n-----------------------------------------")
#6
for x in range(4,10,-1):
    print(x,end=" ")#no output

print("\n-----------------------------------------")
#7
for x in range(4,10,3):
    print(x,end=" ")#4 7

print("\n-----------------------------------------")

#8
for i in range(6,0,-2):
    print(i,end=" ")#6 4 2

print("\n-----------------------------------------")
#9
for i in range(10):
    if(i%2!=0):
        print(i,end=" ")#1 3 5 7 9

print("\n-----------------------------------------")

#10
sum=0
for i in range(1,6):
    if(i%2==0):
        sum=sum+i

print(i)#5
print("\n-----------------------------------------")

#11
for i in range(1,6):
    if(i%3==0):
        print(i,end=" ")#3
print("\n-----------------------------------------")
#12
n=10
count=0
for i in range(1,n):
    if(n%i==0):
        count=count+1
print(count)#ZeroDivisionError: integer division or modulo by zero

print("\n-----------------------------------------")
#13
n=5
a=1
for i in range(1,n+1):
    a=a*i
    print(a)

print("\n-----------------------------------------")
#14
x=[2,5,3,6,1,4]
s=0
for i in x:
    if(i%2==0):
        s=s+i
print(s)#12

print("\n-----------------------------------------")
#15
x=[2,5,3,6,1,4]
s=0
for i in x:
    if(i%2 !=0):
        s=s+i
print(s)#9

print("\n-----------------------------------------")
#16
for i in range(1,5):
    for j in range(1,5):
        print(j,end=" ")#1 2 3 4 1 2 3 4 1 2 3 4 1 2 3 4

print("\n-----------------------------------------")
#17
for i in range(1,5):
    for j in range(1,5):
        print(j,end=" ")
    print()


#1 2 3 4
#1 2 3 4
#1 2 3 4
#1 2 3 4

print("\n-----------------------------------------")

#18
for i in range(1,5):
    for j in range(1,5):
        print(i,end=" ")
    print()

#1 1 1 1
#2 2 2 2
#3 3 3 3
#4 4 4 4
print("\n-----------------------------------------")

#19
for i in range(1,5):
    for j in range(1,i+1):
        print(i,end=" ")
    print()
#1
#2 2
#3 3 3
#4 4 4 4
print("\n-----------------------------------------")

#20
for i in range(1,5):
    for j in range(1,i+1):
        print(j,end=" ")
    print()

#1
#1 2
#1 2 3
#1 2 3 4
print("\n-----------------------------------------")
#21
for i in range(1,5):
    for j in range(1,i+1):
        print("*" ,end=" ")
    print()

#*
#* *
#* * *
#* * * *

print("\n-----------------------------------------")

#22
k=1
for i in range(1,5):
    for j in range(1,i+1):
        print(k,end=" ")
        k+=1
    print()

#1
#2 3
#4 5 6
#7 8 9 10

