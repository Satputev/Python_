for x in range(1,11):
    print(x,end=" ") #1 2 3 4 5 6 7 8 9 10
print("\n--------------------------------------------")

for x in range(2,11,2):
    print(x,end=" ")#2 4 6 8 10

print("\n--------------------------------------------")
for x in range(1,10,2):
    print(x,end=" ")#1 3 5 7 9

print("\n--------------------------------------------")

for x in range(10,0,-1):
    print(x,end=" ")#10 9 8 7 6 5 4 3 2 1

print("\n--------------------------------------------")

for x in range(-10,0):
    print(x,end=" ")#-10 -9 -8 -7 -6 -5 -4 -3 -2 -1
print("\n--------------------------------------------")

for x in range(5,51,5):
    print(x,end=" ")#5 10 15 20 25 30 35 40 45 50
print("\n--------------------------------------------")

for x in range(65,91):
    print(chr(x),end=" ")#A B C D E F G H I J K L M N O P Q R S T U V W X Y Z

print("\n--------------------------------------------")

for x in range(122,96,-1):
    print(chr(x),end=" ") #z y x w v u t s r q p o n m l k j i h g f e d c b a