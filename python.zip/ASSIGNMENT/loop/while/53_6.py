#print sum of prime numbers between 1 to 100

start=1
end=100
sum=0
nos=[]
print(" prime nos from 1 to 100 numbers:")

for x in range(2,end):
    for y in range(2,x):
        if(x%y==0):
            break
        else:
            continue
    else:
        nos.append(x)

for x in nos:
    print(x,end=" ")
print("\nnos:",len(nos))

print("-----------sum--------------------")
for x in range(2,end):
    for y in range(2,x):
        if(x%y==0):
            break
        else:
            continue
    else:
        sum=sum+x
print(sum)
