#print sum of prime no 1-100
first=1
last=100
sum=0

for x in range(2,last-1):
    for y in range(2,x):
        if(x%y==0):
            break
    else:
        sum=sum+x

print(sum)

