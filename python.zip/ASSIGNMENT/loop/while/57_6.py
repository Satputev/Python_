#check no is palindrome or not

no=input("Enter the no")

for x in range(int(len(no)/2)):
    if no[x]==no[-(x+1)]:
        continue
    else:
        print("not palindrome..")
        break


else:
    print("palindrome")


