
for x in range(5):
    for y in range(x+1):
        print(y+1,end=" ")
    print()

# 1
# 1 2
# 1 2 3
# 1 2 3 4
# 1 2 3 4 5


print("-----------------")

for x in range(5):
    for y in range(x+1):
        print("*",end=" ")
    print()

# *
# * *
# * * *
# * * * *
# * * * * *


print("-----------------------")


for x in range(5):
    for y in range(x+1):
        print("A",end=" ")
    print()

# A
# A A
# A A A
# A A A A
# A A A A A


print("-----------------------")

for x in range(5):
    for y in range(x+1):
        print(chr(65+x),end=" ")
    print()

# A
# B B
# C C C
# D D D D
# E E E E E

print("---------------------")
no=0
for x in range(5):
    for y in range(x+1):
        print(chr(65+no),end=" ")
        no+=1
    print()


# A
# B C
# D E F
# G H I J
# K L M N O


print("---------------------")

for x in range(5):
    for y in range(x+1):
        print(chr(65+y),end=" ")
    print()

# A
# A B
# A B C
# A B C D
# A B C D E

print("------------------")

for x in range(5):
    for y in range(x+1):
        print("#",end=" ")
    print()

#
# #
# # #
# # # #
# # # # #

print("-----------------")

for x in range(5):
    for i in range(4,x,-1):
        print(" ",end=" ")
    for y in range(x+1):
        print("*",end=" ")
    print()

#         *
#       * *
#     * * *
#   * * * *
# * * * * *

print("-----------")

for x in range(5):
    for i in range(4,x,-1):
        print(" ",end=" ")
    for y in range(x+1):
        print("A",end="")
    print()

#         A
#       AA
#     AAA
#   AAAA
# AAAAA

print("---------------------")

for x in range(5):
    for i in range(4,x,-1):
        print(" ",end=" ")
    for y in range(x+1):
        print(chr(65+x),end="")
    print()

#         A
#       BB
#     CCC
#   DDDD
# EEEEE

print("-----------------")

for x in range(5):
    no=x
    for y in range(x+1):
        print(chr(65+no),end=" ")
        no-=1
    print()

# A
# B A
# C B A
# D C B A
# E D C B A

print("-------------------------")

for x in range(5):
    for y in range(4,x,-1):
        print(" ",end="")
    for y in range(x+1):
        print("*",end=" ")
    print()


#     *
#    * *
#   * * *
#  * * * *
# * * * * *

print("-----------------------")
no=1
for x in range(5):
    for y in range(4,x,-1):
        print(" ",end="")
    for z in range(x+1):
        print(no,end=" ")
        no+=1
    print()

#    1
#    2 3
#   4 5 6
#  7 8 9 10
# 11 12 13 14 15

print("--------------------")
no=1
for x in range(6):

    for y in range(x+1):
        if(x<4):
            print(no, end=" ")
            no += 1
        else:
            if(x==4 and y<4):
                print(no,end=" ")
                no+=1
            if x==5 and y==0:
                print(no)

    print()


# 1
# 2 3
# 4 5 6
# 7 8 9 10
# 11 12 13 14
# 15

print("---------------")

for x in range(9):
    for y in range(8,x,-1):
        print(" ",end="")
    for z in range(x+1):
        if(z==x):
            print("*", end=" ")
        else:
            print("*", end="*")
    print()

#         *
#        ***
#       *****
#      *******
#     *********
#    ***********
#   *************
#  ***************
# *****************

print("-------------------------")

for x in range(7,0,-1):

    for y in range(x):
        print("*",end=" ")

    for m in range(x, 7):
        print("   ", end=" ")
    for n in range(x):
            print("*", end=" ")

    print()
print("-----------------------------------")
for x in range(7):
    for y in range(x+1):
        print(x*y,end=" ")
    print()

# 0
# 0 1
# 0 2 4
# 0 3 6 9
# 0 4 8 12 16
# 0 5 10 15 20 25
# 0 6 12 18 24 30 36

print("------------------------------")
for x in range(1,5):
    for y in range(4,x,-1):
        print(" ",end="")
    for y in range(1,x+1):
        print(x,end=" ")
    print()

#   1
#  2 2
# 3 3 3
#4 4 4 4






