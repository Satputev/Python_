x=0
while True:
    if x<4:
        print("*",end=" ")
    else:
        break
    x+=1

#* * * *
