for i in range(1,6):
    if(i%2==0):
        continue
    if(i%3==0):
        break
    print(i,end="\t")

#1