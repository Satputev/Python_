

strn=input("Enter the string: ")
no=int(input("Enter the no:"))
def front_times(s,n):
    st = ''

    if(isinstance(s,str) ):
        if (len(s) > 0):
            for x in range(3):
                st=st+s[x]
    return (n*st)

print(front_times(strn,no))

# Enter the string: Chocolate
# Enter the no:2
# ChoCho

# Enter the string: Chochlate
# Enter the no:3
# ChoChoCho


# Enter the string: Abc
# Enter the no:3
# AbcAbcAbc
