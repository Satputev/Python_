#print the fabonacci series
#1 1 2 3 5 8 13 21 34 55 89

no1=1
no2=1
for x in range(11):
    if(x>1):
        no3 = no1 + no2
        no1 = no2
        no2 = no3
        print(no2 ,end=" ")
    else:
        print(no2,end=" ")

#1 1 2 3 5 8 13 21 34 55 89
