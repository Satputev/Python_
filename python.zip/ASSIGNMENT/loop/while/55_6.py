for i in range(1,6):
    for j in range(1,5):
        if(j%2==0):
            break
        print(j,end="\t")

#1	1	1	1	1
