for i in range(1,6):
    for j in range(1,5):
        if(j%2==0):
            continue
        print(j,end="\t")
    print()

# 1	3
# 1	3
# 1	3
# 1	3
# 1	3