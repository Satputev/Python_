#perfect no

#No is equal to sum of its proper divesors

no=int(input("Enter the no: "))
sum=0
for x in range(1,no):
    if (no%x==0):
        sum=sum+x

if(no==sum):
    print(no,"Is a perfect no")
else:
    print(no,"Is not perfect no")

#Enter the no: 12
#12 Is not perfect no

# Enter the no: 6
# 6 Is a perfect no