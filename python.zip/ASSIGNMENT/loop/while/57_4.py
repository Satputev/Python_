
for x in range(3):
    no = int(input("Enter the no: "))
    if no > 0:
        for y in range(3):
            st = input("Enter the string: ")
            if (len(st) > 0):
                def string_times(s, n):
                    return s * n
                print(string_times(st, no))
                break
            else:
                if(y==2):
                    print("maximum 3 chances you consumed ")
                    print("thanks")
                else:
                    print("String should not be empty ")
                    continue
        break


    else:
        if(x==2):
            print("you cross the limit  ")
            print("thanks")
        else:
            print("No should not be negative ")
            continue


# Enter the no: -5
# No should not be negative
# Enter the no: -10
# No should not be negative
# Enter the no: 2
# Enter the string:
# String should not be empty
# Enter the string: Hi
# HiHi