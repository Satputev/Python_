#finding given no is strong or not
def factorial(any):
    if(any==0 or any==1):
        return 1
    else:
        return any*factorial(any-1)

#print(factorial(6))


no=int(input("Enter the no:"))
No=no
sum=0
while no!=0:
    r=no%10
    sum=sum+factorial(r)
    no=no//10

if(sum==No):
    print(No,"is strong")
else:
    print(No,"is not strong")
