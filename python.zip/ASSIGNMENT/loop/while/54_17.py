x=0

while True:
    if x<4:
        if (x % 2 == 0):
            print("*", end=" ")
        else:
            print("#", end=" ")
        x += 1

#* # * #