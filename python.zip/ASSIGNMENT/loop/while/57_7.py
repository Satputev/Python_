#check wheather no is amstrong no or not

#sum of cubes of digits is equal to number itself

no=int(input("Enter the no: "))
No=no
sum=0
while no!=0:
    r=no%10
    no=no//10
    sum=sum+r**3

if No==sum:
    print(No," Amstrong no")
else:
    print(No," Is not amstrong no ")

#Enter the no: 153
#153  Amstrong no

# Enter the no: 32165
# 32165  Is not amstrong no

