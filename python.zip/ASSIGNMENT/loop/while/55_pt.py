for x in range(7):
    for m in range(x, 7):
        print(" ", end=" ")
    for n in range(x):
        print("*", end=" ")
    print()