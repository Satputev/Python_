#check given no is amstrong no or not
#153=1**3+5**3+3**3

no=int(input("enter the no: "))
No=no
sum=0
while no!=0:
    r=no%10
    no=no//10
    sum=sum+(r**3)
if(sum==No):
    print(No," is amstrong no")
else:
    print(No," is not amstrong no")

# enter the no: 153
# 153  is amstrong no

# enter the no: 564
# 564  is not amstrong no