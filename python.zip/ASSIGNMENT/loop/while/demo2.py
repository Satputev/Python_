#find the sum of digit using cmd

no=int(input("Enter no:"))
sum=0
while no!=0:
    r=no%10
    sum=sum+r
    no=no//10
print(sum)

# Enter no:123456789
# 45