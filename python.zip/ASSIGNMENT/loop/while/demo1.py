#print nos from 10 to 1
no=10
while no!=0:
    print(no,end=" ")#10 9 8 7 6 5 4 3 2 1
    no-=1

print("\n-------------No of even and odd nos------------")

n=0
en=0
od=0
while n!=10:
    no=int(input("Enter no:"))
    if(no%2==0):
        en+=1
    else:
        od+=1
    n+=1
print("Even nos:",en)
print("odd nos:",od)

print("------------------")