#finding first bigest and second bigest
max=0
s_max=-1
for x in range(10):
    no=int(input("Enter Number"))
    if(s_max>no and s_max<max):
        s_max=s_max
    elif max>s_max:
        s_max=no
    if(max>no):
        s_max=max
    else:
        max=no

print("First biggest no is:",max)
print("Second Bigest no is:",s_max)

# Enter Number10
# Enter Number50
# Enter Number60
# Enter Number90
# Enter Number80
# Enter Number70
# Enter Number60
# Enter Number455
# Enter Number552
# Enter Number623
# First biggest no is: 623
# Second Bigest no is: 552