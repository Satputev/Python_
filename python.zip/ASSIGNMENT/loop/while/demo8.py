#finding the sum of middle digits

no=int(input("Enter the no:"))
l=[]
while no!=0:
    r=no%10
    l.append(r)
    no=no//10
if(len(l)>=4):
    if(len(l)%2==0):
        print("Sum of middle elements=", l[(int(len(l) / 2)) - 1] + l[int((len(l) / 2))])
    else:
        print("middle element=",l[int(len(l)/2)])
else:
    print("there is no more than two middle element")
