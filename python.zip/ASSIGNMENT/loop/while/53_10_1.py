#finding perfect no from1 to 100

start=int(input("Enter the start: "))
end=int(input("Enter the end: "))
perfect=''
for x in range(2,end):
    perfect_nos = 0

    for y in range(1,x):
        if x%y==0:
            perfect_nos+=y

        else:
            continue
    if(perfect_nos==x):
        perfect=perfect+' '+str(x)

if perfect:
    print("perfect no from: ",start," to ",end , ' is ',perfect)
else:
    print("no perfect no in between given range...")
