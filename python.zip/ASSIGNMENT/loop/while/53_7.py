#extract the digits from given nos

no=int(input("Enter the no:"))
split=''
while no!=0:
    r=no%10
    no=no//10
    split=str(r)+' '+split

print(split)