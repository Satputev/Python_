#strong no----

#the sum of factorial of digits is equal to that no


def fact(n):
    if n==0 or n==1:
        return 1
    else:
        return n*fact(n-1)

no=int(input("Enter the no:"))
No=no
sum=0
while no!=0:
    r=no%10
    no=no//10
    sum=sum+fact(r)


if(sum==No):
    print(No," Is strong no ")
else:
    print(No,"is not strong because sum of factorial of digits:",sum)

# Enter the no:145
# 145  Is strong no

# Enter the no:56
# 56 is not strong because sum of factorial of digits: 840
