#finding the sum of first and last digit

no=int(input("Enter the no:"))
l=[]

while no!=0:
    r=no%10
    l.append(r)
    no=no//10

print("sum of first and last digit is:",l[0]+l[-1])