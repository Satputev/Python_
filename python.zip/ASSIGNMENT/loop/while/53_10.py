#check no is perfect no or not

# sum of its proper divisers is equal to no then its proper no

no=int(input("Enter the no: "))
sum=0
for x in range(1,no):
    if(no%x==0):
        sum=sum+x
    else:
        continue

if no==sum:
    print(no," Its perfect no")
else:
    print(no," is not perfect no")

