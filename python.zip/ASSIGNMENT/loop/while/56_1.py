str=input("enter the string")
st=''
for x in range(len(str)):
    for y in range(x+1):
        print( str[y],end="")

#enter the stringCode
#CCoCodCode

# enter the stringabc
# aababc

# enter the stringab
# aab


print("---------------------")

for x in range(10):
    for y in range(9,x,-1):
        print(" ",end="")
    for z in range(x+1):
        print("*",end=" ")
    print(end='\n')

print("---------------------------------")
for x in range(9):
    for s in range(x + 1):
        print(" ", end="")

    for m in range(9, x, -1):
        print("*", end=" ")
    print()

print("------------------------------------")

#          *
#         * *
#        * * *
#       * * * *
#      * * * * *
#     * * * * * *
#    * * * * * * *
#   * * * * * * * *
#  * * * * * * * * *
# * * * * * * * * * *
#  * * * * * * * * *
#   * * * * * * * *
#    * * * * * * *
#     * * * * * *
#      * * * * *
#       * * * *
#        * * *
#         * *
#          *