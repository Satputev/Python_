for x in range(1,6):
    if(x%2==0):
        break
    if(x%3==0):
        continue
    print(x,end="\t")

#1