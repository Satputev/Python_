#49_1
print(5*"Sathya technology ",end=" ")#Sathya technology Sathya technology Sathya technology Sathya technology Sathya technology


#49_2
print()
for i in range(1,6):
    print(i,end=" ")#1 2 3 4 5


#49_3
for x in range(100,0,-1):
    print(x,end=" ")#100 99 98 97 96 .....3 2 1

#49_4
no = int(input("Enter end no:"))
for i in range(2, no, 2):
    print(i, end=" ")

# Enter end no:21
# 2 4 6 8 10 12 14 16 18 20

#49_5
no = int(input("Enter no"))
for i in range(1, no, 2):
    print(i, end=" ")

# Enter no45
# 1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 31 33 35 37 39 41 43

#49_6

no=int(input("Enter the no:"))
print("Odd Even")
print("== ==")
for x in range(1,no):
    print(x*2-1,x*2)

#Enter the no:10
#Odd Even
#== ==
#1 2
#3 4
#5 6
#7 8
#9 10
#11 12
#13 14
#15 16
#17 18

#49_7
no=int(input("Enter the no:"))
for x in range(5,no+1,5):
        print(x,end=" ")#5 10 15 20 25 30 35 40 45 50 55 60 65




#49_8
no=int(input("Enter the no:"))
for x in range(no,no*10+1,no):
    print(x)

#49_9


