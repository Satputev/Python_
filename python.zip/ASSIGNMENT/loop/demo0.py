
#1
for x in range(1,6):
    for y in range(x):
        print("*", end="")
    print()
print("-----------------")

#2
for x in range(5,0,-1):
    for y in range(x):
        print("*",end="")
    print()
print("-----------------")

#3
for x in range(1,6):
    for z in range(5,x,-1):
        print(" ",end="")
    for y in range(x):
        print("*",end="")
    print()
print("-------------------")

#4
for x in range(5,0,-1):
    for z in range(x,5):
        print(" ",end="")
    for y in range(x):
        print("*",end="")
    print()