c_food=float(input("Enter the charge of food:"))
tip=c_food*0.18
tax=c_food*0.07

print("Charge for food is:",c_food)
print("Tip amt is:",tip)
print("sales tax:",tax)
print("Total Ammount is:",c_food+tip+tax)