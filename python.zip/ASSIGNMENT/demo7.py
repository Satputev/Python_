#accept student no,name,mark1,mark2,mark3 from cmd calculate total and avg mark nd dispaly

m1=int(input("Enter first sub mark:"))#Enter first sub mark:60

m2=int(input("Enter second Sub mark:"))#Enter second Sub mark:20

m3=int(input("Enter 3rd sub mark:"))#)Enter 3rd sub mark:30


total=m1+m2+m3

print("Total mark is",total,"Average mark is:",total/3)#Total mark is 110 Average mark is: 36.666666666666664
