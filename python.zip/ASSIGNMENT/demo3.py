#Accept fistname and last name and display full name

print("FULL_NAME IS:",input("ENTER FIRST NAME:")+input("ENTER SECOND NO:"))
#ENTER FIRST NAME:Naveen
#ENTER SECOND NO:Kumar
#FULL_NAME IS: NaveenKumar