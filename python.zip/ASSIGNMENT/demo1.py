#wap to accept student name and display welcome name
print("WELCOME ",input("ENTER STUDENT NAME:"))#ENTER STUDENT NAME:naveen
                                                #WELCOME  naveen
