def makes(no1,no2):
    if(no1==10 or no2==10 or no1+no2==10):
        return True
    else:
        return False

n1=int(input("Enter the no1:"))
n2=int(input("Enter the no2:"))

print(makes(n1,n2))

#Enter the no1:10
#Enter the no2:2
#True

#Enter the no1:2
#Enter the no2:8
#True

#Enter the no1:56
#Enter the no2:6
#False