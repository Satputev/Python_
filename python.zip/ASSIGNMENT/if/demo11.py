#44_50

#triangle type(equilateral/scalence/isosceles/acute/obtuse/right angle triangle

a1=int(input("Enter the 1st angle:"))
a2=int(input("Enter 2nd angle:"))
a3=int(input("Enter the 3rd angle:"))

if(a1<90 and a2<90 and a3<90 and a1+a2+a3==180):
    if(a1 !=a2 and a1 != a3 and a2 !=a3 and a1+a2+a3==180):
        print("Triangle is accute scalence..")
    if(a1==a2 and a1==a3 and a2 !=a3 or a2==a3 and a2==a1 and a1!=a3 and a1+a2+a3==180):
        print("Triangel is acute isoscles")
    if(a1==a2==a3 and a1+a2+a3==180):
        print("Tringle is Accute equilateral..")



if(a1!=a2!=a3 and a1+a2+a3==180):
    print("Triangle is sclence..")

if(a1==a2==a3 and a1+a2+a3==180):
    print("Triangle is equilateral..")


if(a1+a2+a3==180 and a1==90 and a2==a3 or a2==90 and a1==a3 or a3==90 and a1==a2 ):
    print("isoscles right angle triangle.")

if( a1+a2+a3==180 and a1==90 and a2!=a3 or a2==90 and a1!=a3 or a3==90 and a1!=a2 ):
    print("sclence right angle triangle..")

if(a1>90 and a2==a3 or a2>90 and a1==a3 or a3>90 and a1==a2 and a1+a2+a3==180):
    print("Obtuse isosceles triangle..")

if(a1+a2+a3 !=180):
    print("Enter valid Angles..")

