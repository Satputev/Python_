p_cost=float(input("Enter the product cost:"))
gst=p_cost*0.1
netPrice=p_cost+gst

if(netPrice>500):
    total_bill=netPrice-netPrice*0.2
    print("Total Bill:",total_bill)
else:
    print("Total bill=",netPrice)

#Enter the product cost:501
#Total Bill: 440.88

#Enter the product cost:400
#Total bill= 440.0