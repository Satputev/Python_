n=5
if(n%2==0):
    print("Even")
else:
    print("Odd")
print("Thank you")

    #Odd
    #Thank you
#======================================================================
n=5
if(n>0):
    print("+ve")
else:
    print("-ve")
print("Thanks")

#+ve
#Thanks

#===========================================
n=-3
if(n>0):
    print("+ve")
else:
    print("-ve")
print("Thanks")

#-ve
#Thanks

#===========================================

n=0
if(n>0):
    print("+ve")
else:
    print("-ve")
print("Thanks")

#-ve
#Thanks

#========================================
s1=52
s2=36

if(s1>=35 and s2>35):
    print("Pass")
    total=s1+s2
else:
    print("Fail")
    print("All the Best")
print("Thank You")
#Pass
#Thank You

#======================================
s1=52
s2=35
if(s1>=35 and s2>35):
    print("PASS")
    total=s1+s2
else:
    print("FAIL")
    print("All the best")
print("Thank you")

#FAIL
#All the best
#Thank you

#===========================================

a, b, c = 4, 6, 2
if (a > 3 and b > 5 and c > 6):
    print("Sathya Technology")
else:
    print("Ravi Kumar")

# Ravi Kumar
#=================================================

uname = "Ravi kumar"
pwd = "Python"

if (uname == "Ravi kumar" or pwd == "Sathya"):
    print("Valid user")
else:
    print("Invalid User")

# Valid user
#===========================================

x=5
y=8
if(x>y):
    print("X is big")
else:
    print("Y is big")
#Y is big
#=========================================

a = 2
b = 3
c = 4
if (a > 1 and b > 2 or c > 5):
    print("Hai")
else:
    print("Bye")

# Hai
#============================================

a=2
b=1
c=4

if(a>1 and b>2 or c>5):
    print("Hai")
else:
    print("Bye")

#Bye

#======================================

p = 6
if (not p):
    print("Ravi kumar")
else:
    print("Sathya Technology")

# Sathya Technology
#=========================================

billAmt = 4500
card = 'SBI'
if (billAmt > 5000 or card == "SBI"):
    print("Eligible for Discount")
else:
    print("Not Eligible")

# Eligible for Discount
#=============================================

#if(true):
 #   print("Hai")
#else:
 #   print("Bye")
#NameError: name 'true' is not defined
#=====================================

x = 5
if (x > 0):
    print("+ve Number")
elif (x < 0):
    print("-ve Number")
else:
    print("Zero")

# +ve Number
#=============================================

x=5
if(x>0):
    print("+ve Number")
print(x)
#elif(x<0):
 # print("-ve Number")
#else:
 # print("Zero")

#SyntaxError: invalid syntax

#=========================================================

x=5
if(x>0):
    print("+ve Number")
    print(x)
elif(x<0):
    print("-ve Number")
else:
    print("Zero")

#+ve Number
#5
#=====================================================

x=5
if(x>0):
    print("+ve Number")
elif(True):
    print("-ve Number")
else:
    print("Zero")

#+ve Number
#========================================================

x=-5
if(x>0):
    print("+ve Number")
else:
    print("Zero")
#elif(x<0):
print("-ve Number")

#SyntaxError: invalid syntax

#=============================================

x = -2
if (x > 0):
    print("+ve Number")
elif (x < 0):
    print("Zero")

# Zero
#===============================================

item="idly"
if(item=="Dosa"):
    cost=30
elif(item=="Puri"):
    cost=45
elif(item=="idly"):
    cost=25
else:
    cost=50
print(cost)

#25
#==================================================
c='r'
if(c=='b' or c=="B"):
    print('Blue')
elif(c=='g' or c=="G"):
    print("Green")
elif(c=='r' or c=="R"):
    print("RED")

#RED
#================================================
if (True):
    if (False):
        print("Hai")
    else:
        print("Bye")

# Bye
#================================================

if(False):
    if (False):
        print("core Python")
    else:
        print("Adv Python")
else:
    print("Sathya Technology")

#Sathya Technology
#==================================================
x = -2
if (x != 0):
    if (x > 0):
        print("+ve Number")
    else:
        print("-ve Number")
else:
    print("Zero")

# -ve Number
#====================================================

x=2
if(x!=0):
    if(x>0):
        print("+ve number")
    else:
        print("-ve Number")
else:
    print("Zero")

#+ve number
#==========================================

x = 0
if (x != 0):
    if (x > 0):
        print("+ve number")
    else:
        print("-ve Number")
else:
    print("Zero")

# Zero
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++
x = 15
if (x != 0):
    if (x % 2 == 0):
        print("2 Divisible")
    elif (x % 3 == 0):
        print("3 Divisible")
    elif (x % 5 == 0):
        print("5 Divisible")
    else:
        print("Zero")

# 3 Divisible
#=============================================================
