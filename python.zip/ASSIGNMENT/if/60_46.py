def diff21(no):
    if no>21:
        return 2*(no-21)
    else:
        return (21-no)

num=int(input("Enter the number:"))
print(diff21(num))

#Enter the number:10
#11

#Enter the number:22
#2

#Enter the number:21
#0