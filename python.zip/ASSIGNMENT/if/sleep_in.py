def sleep_in(weekday,vacation):
    if(weekday==True and vacation==False):
        return False
    else:
        return True

wk_day=eval(input("Is Weekday  (True/False):"))
Vac_info=eval(input("Are you in vacation??(True/False):"))
x=sleep_in(wk_day,Vac_info)
print(x)

#Note:To read boolean value  we must use eval function