#44_53

cost_price=float(input("Enter the cost price:"))
selling_price=float(input("Enter the selling price:"))

if(selling_price>cost_price):
    profit = ((selling_price - cost_price) / cost_price) * 100
    print("profit",profit)
else:
    loss=((cost_price-selling_price)/cost_price)*100
    print("loss",loss)

#Enter the cost price:100
#Enter the selling price:150
#profit 50.0