pin=int(input("Enter the pin:"))
balance=20000.0

if(pin==2564):
    print("Welcome to NMK ATM")
    ammt=int(input("Enter the ammount:"))
    if ammt%100==0:
        if ammt<=10000:
            if ammt<=balance:
                balance -=ammt
                print("Available Balance is:",balance)
            else:
                print("No funds")
        else:
            print("maximum limit is 10000/- only")

    else:
        print("Invalid ammount")

else:
    print("Invalid pin")

print("thanks..")


#Enter the pin:2564
#Welcome to NMK ATM
#Enter the ammount:6000
#Available Balance is: 14000.0
#thanks..
