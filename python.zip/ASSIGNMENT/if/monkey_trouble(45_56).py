def monkey_trouble(a_smile,b_smile):
    if(a_smile==b_smile):
        return True
    else:
        return False

a_smile=eval(input("a_smiling (True/False):"))
b_smile=eval(input("b_smiling (True/False):"))

print(monkey_trouble(a_smile,b_smile))

#a_smiling (True/False):True
#b_smiling (True/False):True
#True

#a_smiling (True/False):False
#b_smiling (True/False):True
#False

#a_smiling (True/False):False
#b_smiling (True/False):False
#True
