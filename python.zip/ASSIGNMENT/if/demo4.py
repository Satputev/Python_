#43_37

no1=int(input("Enter the 1st no:"))
no2=int(input("Enter the 2nd no:"))

if(no1>no2):
    print(no1,"is big number")

if(no2>no1):
    print(no2,"is big number")

#Enter the 1st no:20
#Enter the 2nd no:30
#30 is big number

#------------------------------------------------
#43_38

n1=int(input("1st no:"))
n2=int(input("2nd no:"))
n3=int(input("3rd no:"))

if(n1>n2 and n1>n3):
    print(n1,"is big no")
if(n2>n1 and n2>n3):
    print(n2,"is big no")

if(n3>n1 and n3>n2):
    print(n3,"is big no")

#1st no:10
#2nd no:5
#3rd no:30
#30 is big no
#-----------------------------------------------------
#43_39


n=int(input("Enter no:"))

if(n>0):
    print("+ve no")

if (n<0):
    print("-ve no")

#Enter no:-5
#-ve no

#----------------------------------------------------------
#43_40

no=int(input("Enter the no:"))
if(no%2==0):
    print("Even")
if(no%2 !=0):
    print("Odd")

#Enter the no:5
#Odd

#------------------------------------------------------
#43_41

no=int(input("Enter the no:"))
if(no%5==0 and no%11==0):
    print(no,"is divisiable by 5 and 11")

if(no%5 !=0 or no%11 !=0):
    print(no,"is not divisible by 5 or 11")

#Enter the no:55
#55 is divisiable by 5 and 11


#Enter the no:25
#25 is not divisible by 5 or 11