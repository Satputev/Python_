def sleep_in(weekday,vacation):
    if(weekday==True and vacation==False):
        return False
    else:
        return True

day=eval(input("Enter weekday True/False:"))
vac=eval(input("Are you in vacation? True/False:"))
print(type(vac))
res=sleep_in(day,vac)

print(res)

#Enter weekday True/False:True
#Are you in vacation? True/False:True
#<class 'bool'>
#True

