#44_46

#check wheather the given character is lowercse or uppercase

char=input("Enter the char:")
lCase=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
uCase=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
if(char in lCase):
    print(char,"Is lower case letter..")
if(char in uCase):
    print(char,"is Upper case letter..")

if(char not in lCase and char not in uCase):
    print("Enter valid Alphabet..")

#---------------------OR--------------------------------

if(char>='A' and char<='Z'):
    print(char,"is Capital letter..")
if(char>='a' and char <='z'):
    print(char,"is small letter..")

if ((char <= 'A' or char >= 'Z' and char <= 'a' or char >= 'z')):
    print(char, "is not a valid Alphabet")


#---------------------------------------------------------------
print(ord('a'))#97
print(ord('A'))#65

print(chr(197))#Å
print(chr(97))#a
#-----------------------------------------------------------------



#case1:
#Enter the char:b
#b Is lower case letter..


#case:2
#Enter the char:H
#H is Upper case letter..


#case:3

#Enter the char:5
#Enter valid character..
