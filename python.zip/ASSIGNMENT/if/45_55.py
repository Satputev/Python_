def sum_double(no1,no2):
    if(no1==no2):
        return 2*(no1+no2)
    else:
        return no1+no2
no1=int(input("Enter the 1st no:"))
no2=int(input("Enter the 2nd no:"))
print(sum_double(no1,no2))

#Enter the 1st no:20
#Enter the 2nd no:20
#80

#Enter the 1st no:10
#Enter the 2nd no:20
#30