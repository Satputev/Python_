#program to calculate the profit or loss
cost_price=float(input("Enter the cost price:"))
selling_price=float(input("Enter the Selling price:"))

if(cost_price>selling_price):
    loss=(cost_price-selling_price)/cost_price
    print("Percentage loss =",loss*100)
else:
    profit=(selling_price-cost_price)/cost_price
    print("Percentage profit =", profit*100)
print("Thanks..")

# Enter the cost price:1000
# Enter the Selling price:1020
# Percentage profit = 2.0
# Thanks

# Enter the cost price:1000
# Enter the Selling price:800
# Percentage loss = 20.0
# Thanks..

