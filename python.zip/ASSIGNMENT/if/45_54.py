unit=int(input("Enter the units consumed:"))

if unit >0 and unit<=50:
    per_unt_charge=0.5
    bill=unit*per_unt_charge
    print("Total bill =",bill+bill*0.2)
elif unit>50 and unit<=150:
    b1=25
    b2=(unit-50)*0.75
    total_bill=b1+b2
    print("Total bill:",total_bill+total_bill*0.2)
elif unit>150 and unit <=250:
    bill=25+75+(unit-150)*1.2
    print("Total bill:",bill+bill*0.2)

elif unit >250:
    bill=25+75+120+(unit-250)*1.5
    print("Total bill=",bill+bill*0.2)

else:
    print("Enter the valid units")

#Enter the units consumed:50
#Total bill = 30.0

#Enter the units consumed:155
#Total bill: 127.2

#Enter the units consumed:190
#Total bill: 177.6


#Enter the units consumed:265
#Total bill= 291.0

#Enter the units consumed:1000
#Total bill= 1614.0
