if None:
    print("hello")

#44_51

#not(True and False)
 #           True or False
#not(False and True)
 #           False or True


#44_53

c_price=float(input("Enter the cost price:"))
s_price=float(input("Enter the selling price:"))

if(c_price>s_price):
    print("Loss is :",((c_price-s_price)/c_price)*100,"%")
else:
    print("Profit is:",((s_price-c_price)/c_price)*100,"%")

print("Thanks..")


#Enter the cost price:100
#Enter the selling price:80
#Loss is : 20.0 %
#Thanks..


#Enter the cost price:100
#Enter the selling price:120
#Profit is: 20.0 %
#Thanks..
