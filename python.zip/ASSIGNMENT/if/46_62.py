seconds=int(input("Enter the seconds:"))
hour=seconds/3600
if(hour<=24):
    if (hour < 18):
        print("Hour:",hour)
        print("Good day")
    else:
        print("Hour:",hour)
        print("Good evening")
else:
    print("Hour:",hour)
    print("Enter valid seconds")

#Enter the seconds:80000
#Hour: 22.22222222222222
#Good evening

#Enter the seconds:5000
#Hour: 1.3888888888888888
#Good day

