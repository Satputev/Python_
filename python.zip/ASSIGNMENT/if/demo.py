#1
for x in range(5):
    for y in range(5):
        print(x+1, end=" ")
    print()

print("------------------------------")

for x in range(5):
    for y in range(5):
        print(y+1,end=" ")
    print()

print("------------------------------")
for x in range(5):
    k=x
    for y in range(5):
        print(k+2,end=" ")
        k+=1
    print()
print("-------------------------")


for x in range(5):
    k=x
    for y in range(5):
        print(k,end=" ")
        k-=1
    print()
print("------------------------------------")

for x in range(1,6):
    for y in range(1,6):
        print(x*y,end=" ")
    print()
print("---------------------------")

k=1
for x in range(5):
    for y in range(5):
        print(k,end=" ")
        k+=1
    print()
print("----------------------")

for x in range(1,6):
    for y in range(x):
        print(y+1,end=" ")
    print()
print("---------------------------")
for x in range(1,6):
    for y in range(x):
        print(x,end=" ")
    print()
print("-----------------------------")

for x in range(1,6):
    k=x+1
    for y in range(x):
        print(k,end=" ")
        k+=1
    print()
print("---------------")

for x in range(1,6):
    for y in range(1,x+1):
        print(x*y,end=" ")
    print()
print("-----------------")

for x in range(1,6):
    for y in range(x):
        print("*", end=" ")
    print()
print("-----------------------")

for x in range(5,0,-1):
    for y in range(x):
        print("$",end=" ")
    print()
print("---------------------------")

for x in range(1,6):
    for s in range(5,x,-1):
        print(" ",end="")

    for y in range(x):
        print("*" ,end=" ")
    print()

print("-----------------------")

for x in range(1,6):
    for y in range(x):
        print(chr(y+65),end=" ")
    print()
print("-----------------------")
for x in range(1,6):
    for y in range(x):
        print(chr(x+64),end=" ")
    print()
print("----------------------------")
k=65
for x in range(1,6):
    for y in range(x):
        print(chr(k),end=" ")
        k+=1
    print()
print("-------------------------")



for x in range(5,0,-1):
    for y in range(x):
        print(y+1,end="")
    print()
#--------------------------------------------
for x in range(5):
    for s in range(4,x,-1):
        print(" " ,end="")
    for j in range(x):
        print("*",end=" ")
    print()
#-------------------------------------------------

