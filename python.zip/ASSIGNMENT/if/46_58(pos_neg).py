def pos_neg(no1,no2,isNegative):
    if(no1<0 and no2<0 and isNegative==True):
        return True
    elif(no1>0 and no2>0):
        return False
    else:
        return True

n1=int(input("Enter the 1st no:"))
n2=int(input("Enter the 2nd no"))
isNG=eval(input("Is egative(True/False:"))

print(pos_neg(n1,n2,isNG))

#Enter the 1st no:10
#Enter the 2nd no20
#Is egative(True/False:True
#False

#Enter the 1st no:-20
#Enter the 2nd no-30
#Is egative(True/False:True
#True

#Enter the 1st no:-20
#Enter the 2nd no10
#Is egative(True/False:True
#True

#Enter the 1st no:-50
#Enter the 2nd no30
#Is egative(True/False:False
#True
