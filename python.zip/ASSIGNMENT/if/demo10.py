#44_49
#to check triangle validity

a1=int(input("Enter the 1st angle:"))
a2=int(input("Enter the 2nd angle:"))
a3=int(input("Enter the 3rd angle:"))

if(a1+a2+a3==180):
    print("Triangle is valid..")
if(a1+a2+a3 !=180):
    print("Triangle is invalid..")


#case1:
#Enter the 2nd angle:40
#Enter the 3rd angle:90
#Triangle is valid..


#case2:
#Enter the 2nd angle:32
#Enter the 3rd angle:22
#Triangle is invalid..