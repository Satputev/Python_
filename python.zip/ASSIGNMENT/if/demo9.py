#44_47

#char is alphabet or not
char=input("Enter the char:")
if((char>='A' and char <='Z') or ( char>='a' and char<='z')):
    print(char,"is alphabet..")

if(char <='A' or char >='Z' and char <='a' or char>='z' ):
    print("Enter the valid Alphabet..")

#----------------------------------------------------------------

(print("Character is alphabet") if char.isalpha()==True else print("char is not alphabet"))



#Enter the char:G
#G is alphabet..

#print(ord('_')) #95

#Enter the char:_
#Enter the valid Alphabet..