#43_42


name=input("Enter name:")
accNo=int(input("AccNo:"))
crntBalance=float(input("Enter the Current Balance:"))
tCode=input("Enter the tCode:d/w")
trnsAmmount=float(input("Enter transection ammount:"))


if(tCode=='d' or tCode =='D'):
    crntBalance+=trnsAmmount
    print("Net balance:",crntBalance)

if(tCode =='w' or tCode =='W'):
    crntBalance-=trnsAmmount
    print("Net balance:",crntBalance)
print("Thank for using...")


#Enter name:Ravi
#AccNo:56324789659
#Enter the Current Balance:20000
#Enter the tCode:d/wd
#Enter transection ammount:5000
#Net balance: 25000.0
#Thank for using...



#Enter name:Ravi
#AccNo:45698562
#Enter the Current Balance:50000
#Enter the tCode:d/wW
#Enter transection ammount:25300
#Net balance: 24700.0
#Thank for using...