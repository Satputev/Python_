s1=43
s2=57
if(s1>=35 and s2>=35):
    print("pass")
print("Thank you")
#pass
#Thank you

#--------------------------------------------------

s1=25
s2=57
if(s1>=35 and s2>=35):
    print("pass")
print("Thank you")#Thank you

#------------------------------------------------
billAmt=5600
card="ICICI"
discount=0

if(card=='ICICI' or billAmt>=5000 ):
    discount=20
print(discount)#20

#---------------------------------------------------

