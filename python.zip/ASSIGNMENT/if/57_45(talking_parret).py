hour=int(input("Enter the hour between(0-23):"))
parrot_is_talking=eval(input("Parrot is talking(True/False):"))

def parrot_trouble(talking,hr):
    if hr >=0 and hr<=23:
        if((talking==True and hr<7) or (talking==True and hr>20)):
            return True
        else:
            return False
    else:
        print("Enter valid hour")

x=parrot_trouble(parrot_is_talking,hour)
print(x)

#Enter the hour between(0-23):6
#Parrot is talking(True/False):False
#False


#Enter the hour between(0-23):6
#Parrot is talking(True/False):True
#True

#Enter the hour between(0-23):21
#Parrot is talking(True/False):False
#False

#Enter the hour between(0-23):21
#Parrot is talking(True/False):True
#True