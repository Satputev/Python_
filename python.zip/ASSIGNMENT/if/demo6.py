#44_44

eno=int(input("Eno:"))
ename=input("Ename:")
sal=float(input("Salary:"))
desg=input("Designation m/a/c:")



if(desg=='m' or desg=='M'):
    sal+=(sal*20)/100
    print("Total sal:",sal)
if(desg=='a' or desg=='A'):
    sal+=(sal*10)/100
    print("Total sal:",sal)

if(desg=='c' or desg=='C'):
    sal+=(sal*5)/100
    print("Total sal:",sal)
if(desg !='m' and desg !='M' and desg !='a' and desg !='A' and desg !='c' and desg  !='C'):
    print("Enter valid designation..")


#Eno:102
#Ename:Ravi
#Salary:100
#Designation m/a/c:a
#Total sal: 110.0


#Eno:101
#Ename:Ravi
#Salary:125562.0
#Designation m/a/c:k
#Enter valid designation..