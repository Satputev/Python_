#accept string from user conver to int and display

print("String to int:",input("ENTER ANY INT VALUE:"))
#ENTER ANY INT VALUE:60
#String to int: 60
