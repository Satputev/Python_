#Accept two no an perform add ,sum ,mul, div and display

no1=int(input("Enter 1st number:"))#Enter 1st number:62
no2=int(input("Enter 2nd number:"))#Enter 2nd number:10
print("ADDITION IS:",no1+no2,"SUBSTRACTION IS:",no1-no2,"MULTIFICATION IS:",no1*no2,"DIVISION IS:",no1/no2)
#ADDITION IS: 72 SUBSTRACTION IS: 52 MULTIFICATION IS: 620 DIVISION IS: 6.2
