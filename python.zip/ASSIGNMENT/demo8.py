#accept two no and swap them and print

no1=int(input("Enter first no:"))#Enter first no:10
no2=int(input("Enter second no:"))#Enter second no:30

print("before swap:",no1,no2)#before swap: 10 30

temp=no1;
no1=no2
no2=temp

print("after swap:",no1,no2)#after swap: 30 10
