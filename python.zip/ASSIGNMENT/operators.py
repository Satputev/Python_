
def balEnq():
    print("fbh")
    withdraw()

def withdraw():
    print("withdraw ammount")
    balEnq()

withdraw()