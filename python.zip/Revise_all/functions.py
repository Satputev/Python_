# There are four ways to define the functions

# 1.without argument without return

def show():
    print('without argument without return')

show()#without argument without return

print('-'*45)
#2 without argument with return

def sum():
    return 10+20
print(sum())#30

print('-'*45)

# 3 with argument without return

def sum(num1,num2):
    print(num1+num2)

sum(100,200)#300

print('-'*45)

# 4 with argument with return

def sum(num1,num2):
    return num1+num2

print(sum(1000,2000))#3000


#the latest variable defination is consider if name is duplicate
