
# python is dynamically typed language it means data type of vaiable is depend on value asociated with it

#int
int_var=10
print(int_var,type(int_var))#10 <class 'int'>

#str
str_var='welcome to python'
print(str_var,type(str_var))#welcome to python <class 'str'>

#float

float_var=10.2

print(float_var,type(float_var))#10.2 <class 'float'>

#bool

bool_var=True

print(bool_var,type(bool_var))#True <class 'bool'>

print('-'*35)
#advanced types(collections)

# list,tuple,set,dict,str



#list

l1=list()
l2=[]
print(l1,type(l1))#[] <class 'list'>


