from bs4 import BeautifulSoup
import requests
res=requests.get("https://www.youtube.com/")
print(res)
bs=BeautifulSoup(res.text,"html.parser")
bs.prettify()
print(bs.title)

l1=bs.find_all({"body":"ltr"})
for a in l1:
    print(a.text)
#l1=bs.find_all("div",{"class":"_2-riNZ"})

#print(l1.append())
#for x in l1:
   # print(x)