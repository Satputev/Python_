import qrcode as qr
res=qr.create("Hellow tommorow we have class at 9AM")
res.show()
