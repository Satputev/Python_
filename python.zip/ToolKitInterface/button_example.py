from tkinter import *

window=Tk()
window.title("Button example")
window.geometry("500x300")

total_bill=0

count_cb=0#280
count_vb=0#200
count_fb=0#350
def inc_chicken():
    global count_cb,total_bill
    count_cb+=1
    l5.configure(text=count_cb)
    total_bill+=280
    l4.configure(text="Total Bill:  "+str(total_bill))

def dec_chicken():
    global count_cb,total_bill
    if count_cb>0:
        count_cb -= 1
        l5.configure(text=count_cb)
        total_bill-=280
        l4.configure(text="Total Bill:  "+str(total_bill))

def inc_veg():
    global count_vb,total_bill
    count_vb+=1
    l6.configure(text=count_vb)
    total_bill+=200
    l4.configure(text="Total Bill:  "+str(total_bill))

def dec_veg():
    global count_vb,total_bill
    if count_vb>0:
        count_vb-=1
        l6.configure(text=count_vb)
        total_bill-=200
        l4.configure(text="Total Bill:  "+str(total_bill))

def inc_fish():
    global count_fb,total_bill
    count_fb+=1
    l7.configure(text=count_fb)
    total_bill+=350
    l4.configure(text="Total Bill:  "+str(total_bill))
def dec_fish():
    global count_fb,total_bill
    if count_fb>0:
        count_fb-=1
        l7.configure(text=count_fb)
        total_bill-=350
        l4.configure(text="Total Bill:  "+str(total_bill))



l1=Label(window,text="Chicken Biryani   280/-",font=("Arial black",15))
l1.grid(row=0,column=0)

l2=Label(window,text="Veg Biryani   200/-",font=("Arial black",15))
l2.grid(row=1,column=0)

l3=Label(window,text="Fish Biryani  350/-",font=("Arial black",15))
l3.grid(row=2,column=0)

l4=Label(window,text="Total Bill:    0.0",font=("Arial black",15))
l4.grid(row=3,column=0)

b1=Button(window,text=" + ",font=("Arial black",20),bg="blue",fg="yellow",command=inc_chicken)
b1.grid(row=0,column=1)

b2=Button(window,text=" + ",font=("Arial black",20),bg="blue",fg="yellow",command=inc_veg)
b2.grid(row=1,column=1)

b3=Button(window,text=" + ",font=("Arial black",20),bg="blue",fg="yellow",command=inc_fish)
b3.grid(row=2,column=1)

l5=Label(window,text=" 0 ",font=("Arial black",15))
l5.grid(row=0,column=2)

l6=Label(window,text=" 0 ",font=("Arial black",15))
l6.grid(row=1,column=2)

l7=Label(window,text=" 0 ",font=("Arial black",15))
l7.grid(row=2,column=2)

b4=Button(window,text=" - ",font=("Arial black",20),bg="red",fg="yellow",command=dec_chicken)
b4.grid(row=0,column=3)

b5=Button(window,text=" - ",font=("Arial black",20),bg="red",fg="yellow",command=dec_veg)
b5.grid(row=1,column=3)

b6=Button(window,text=" - ",font=("Arial black",20),bg="red",fg="yellow",command=dec_fish )
b6.grid(row=2,column=3)
window.mainloop()