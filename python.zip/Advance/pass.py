#Example script to demonstrate pass
#pass is used for just declaration and used for  future Implementation

def fun():
    pass

class Employee:
    pass

if 50>100:
    pass

for x in range(100):
    pass
