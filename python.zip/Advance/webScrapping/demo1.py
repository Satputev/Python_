html_doc='''
<html><head><title>WebScrapping</title></head>
<body><p>This demo of web scrapping</p></body></html>
'''

from bs4 import BeautifulSoup

bs=BeautifulSoup(html_doc,"html.parser")
print(bs.prettify())
print("--------------------")

print(bs.title)#<title>WebScrapping</title>

print(bs.title.text)#WebScrapping

