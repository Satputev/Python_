from bs4 import BeautifulSoup
import requests

response=requests.get("https://www.flipkart.com/search?q=iphone&sid=tyy%2C4io&as=on&as-show=on&otracker=AS_QueryStore_OrganicAutoSuggest_0_1_na_na_na&otracker1=AS_QueryStore_OrganicAutoSuggest_0_1_na_na_na&as-pos=0&as-type=RECENT&suggestionId=iphone%7CMobiles&requestId=6bb446e5-1b9d-485b-8615-153c1b7cebae&as-backfill=on")
bs=BeautifulSoup(response.text,"html.parser")
# x=bs.title
# print(x.text)

print(bs.title.text)

iphones=bs.findAll("div",{"class":"_3wU53n"})
print("------------------")

for i in iphones:
    print(i.text)
print("-------------------------")

features=bs.findAll("ul",{"class":"vFw0gD"})

print(iphones[0].text,":")

for f in features:
    print("* ",f.text)