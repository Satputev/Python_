from bs4 import BeautifulSoup
import requests

res=requests.get("https://www.flipkart.com/apple-iphone-xs-gold-64-gb/product-reviews/itmf944emgqmhujk?pid=MOBF944EAPESBRZM&sortOrder=MOST_HELPFUL&certifiedBuyer=false&aid=overall")
print(res)#<Response [200]>
print(type(res))#<class 'requests.models.Response'>

bs=BeautifulSoup(res.text,"html.parser")
#print(bs.prettify())
print(type(bs))#<class 'bs4.BeautifulSoup'>
