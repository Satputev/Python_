no1=int(input("Enter the first no:"))
no2=int(input("Enter the second number"))
print("sum=",no1+no2)
try:
    print("div=",no1/no2)
except ZeroDivisionError as zde:
    print (zde)
print("mul=",no1*no2)
print("sub=",no1-no2)
print("thanks")