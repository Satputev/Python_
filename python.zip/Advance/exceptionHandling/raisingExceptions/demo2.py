def checkAge(age):
    if(age>=30):
        return age

    else:
        raise ValueError("enter valid age")

age=int(input("Enter the age"))
try:
    print("age=", checkAge(age))
except ValueError as ve:
    print(ve)
    print("Age should not less than 30")

