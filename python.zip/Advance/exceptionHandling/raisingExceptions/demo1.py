from validation.sample import check_age
name=input("Enter the name:")
salary=float(input("Enter the salary:"))
age = int(input("Enter the age:"))

try:
    print(check_age(age))
except ValueError as ve:
    print(ve)


print("thanks")