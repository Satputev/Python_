def check_age(age):
    assert age>=23 and age<=60,'''Invalid age
'You are not eligible\''''
    return "age is: "+str(age)


try:
    age = int(input("Enter the age: "))
    res=check_age(age)
    print(res)
except ValueError as ve:
    print("age must be int type.....")
except AssertionError as ae:
    print(ae)
print("thanks")