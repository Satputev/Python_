x=56
try:
    assert x >= 10, "you are vary weak in python"
    print("You are not practiseing all in proper manner  that are learned in class")

except AssertionError as ae:
    print(ae)
