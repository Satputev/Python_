#Example on try with default except

try:
    no1=int(input("Enter 1st no"))
    no2=int(input("Enter 2nd no"))
    print("sum=",no1+no2)
    print("div=",no1/no2)
    print("mul=",no1/no2)
    print("sub=",no1-no2)

#named except block
except ValueError:
    print("Enter the valid value")
except:
    print("Cannot divide by zero")
print("thanks")