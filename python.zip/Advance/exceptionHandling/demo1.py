

try:
    no1 = int(input("Enter the 1st no:"))
    no2 = int(input("Enter the 2nd no:"))

    print("sum=", no1 + no2)
    print("Division=", no1 / no2)
    print("Multification=", no1 * no2)
    print("Sub=", no1 - no2)

except ValueError:
    print("Enter the valid no..")
except ZeroDivisionError:
    print("No cannot be divide by zreo")
    print("Multification=", no1 * no2)
    print("Sub=", no1 - no2)

print("Thanks..")
