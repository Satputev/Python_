#Example on try,except and finally

no1=int(input("Enter the 1st no:"))
no2=int(input("Enter the 2nd no:"))
print("sum=",no1+no2)

try:
    print("div=",no1/no2)
except ZeroDivisionError as zde:
    print(zde)
finally:
    print("mul=",no1*no2)
    print("sub=",no1-no2)
print("thanks")