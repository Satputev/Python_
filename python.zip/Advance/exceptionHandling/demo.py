def foo():
    try:
        return 1
    finally:
        return 2
k=foo()
print(k)
print("------------------------------")
def foo1():
    try:
        print(1)
    finally:
        print(2)
foo1()

print("-------------------------------")
