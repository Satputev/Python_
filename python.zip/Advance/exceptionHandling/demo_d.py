try:
    if '1'!=1:
        raise "someError"+str(str(102)+str(True)+str('true'))
    else:
        print("some error has not occured")

except TypeError:
    print("what are you doing")
