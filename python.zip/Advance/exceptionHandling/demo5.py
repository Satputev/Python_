#Example on try ,except,else

no1=int(input("Enter 1st no:"))
no2=int(input("Enter 2nd no:"))
print("sum=",no1+no2)
try:
    print("div=",no1/no2)
except:
    print("cannot divide by zero")
else:
    print("mul=",no1*no2)
    print("sub=",no1-no2)
print("thanks")

#if exception is not occured then only else block will executed