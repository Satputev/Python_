class PFaculty:
    def assign(self,id,no):
        self.idno=id
        self.name=no
    def display(self):
        print("Faculty Id no:",self.idno)
        print("Faculty name:",self.name)

f1=PFaculty()
f1.assign(101,"Ravi")
f1.display()