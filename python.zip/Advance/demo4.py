#using class
from sample import PFaculty
print(PFaculty.subject)