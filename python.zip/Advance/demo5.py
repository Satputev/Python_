#using calss function

from  sample import wish
from  sample import PFaculty
wish()
f1=PFaculty()
f1.assign(1001,"Naveen")
f1.display()