#using two functions

from sample import wish,createInstance
wish()
pp1=createInstance()
pp1.display()