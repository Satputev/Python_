class First:
    def calc(self,no1,no2):
        print("Sum = ",no1+no2)
        print("Sub = ",no1-no2)

class Second(First):
    def calc(self,no1,no2):
        super().calc(no1,no2)
        print("Mul = ",no1*no2)
        print("Div = ",no1/no2)

class Third(Second):
    def calc(self,no1,no2):
        super().calc(no1,no2)
        print("Mod = ",no1%no2)
        print("Exp = ",no1**no2)
