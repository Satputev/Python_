#single inheritance
#constructor inheritance

class A:
    def __init__(self):
        print("I am A class constructor")
class B(A):
    def show(self):
        print("I am B class method")

b=B()#I am A class constructor
b.show()#I am B class method
