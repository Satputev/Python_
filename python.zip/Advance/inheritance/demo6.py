#method overriding

class A:
    def show(self):
        print("This is A class show method")

class B(A):
    def show(self):
        print("This is a B show method")
b=B()
b.show()#This is a B show method

