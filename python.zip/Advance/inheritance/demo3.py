#Example on static method inheritance

class A:
    @staticmethod
    def show():
        print("I am A class static method")
class B(A):
    def __init__(self):
        print("I am B class constructor")

B.show()#I am A class static method
b=B()#I am B class constructor
