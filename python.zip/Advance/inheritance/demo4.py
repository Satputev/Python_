#constructor overriding

class A:
    def __init__(self):
        print("I am A class constructor")

class B(A):
    def __init__(self):
        print("I am B class constructor")

B()#I am B class constructor
