class A:
    def __init__(self):
        print("A class Constructor")
class B:
    def __init__(self):
        A()
        print("B class constructor")

class C(B,A):
    def show(self):
        print("Show in C")


class D(A,B):

    def show(self):
        print("this is D show")
c=C()#A class Constructor    B class constructor

c.show()#Show in C

D()#A class Constructor

