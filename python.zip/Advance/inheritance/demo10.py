#third class stdent

from Advance.inheritance.calculator.main import Third
t=Third()
t.calc(15,2)

# Sum =  17
# Sub =  13
# Mul =  30
# Div =  7.5
# Mod =  1
# Exp =  225
