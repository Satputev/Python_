#second class student

from Advance.inheritance.calculator.main import Second
s=Second()
s.calc(10,2)

# Sum =  12
# Sub =  8
# Mul =  20
# Div =  5.0