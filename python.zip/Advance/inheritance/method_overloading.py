
class B(A):
    def m1(self,*arg1):
        print('B m1',arg1)
        super().m1()#call Parent class m1

b=B()
b.m1(20)
b.m1()