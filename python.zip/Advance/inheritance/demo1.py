#Accesing parent class method into child class

class Employee:
    def assign(self,id,name):
        self.idno=id
        self.name=name

class Developer(Employee):
    def projectInfo(self,pname,manager):
        self.project_name=pname
        self.project_manager=manager

    def display(self):
        print("IDNO:",self.idno)
        print("NAME:",self.name)
        print("ProjcetName:",self.project_name)
        print("Projct_manager",self.project_manager)

d=Developer()
d.assign(101,"Ravi")
d.projectInfo("CMS","Ravi")
d.display()