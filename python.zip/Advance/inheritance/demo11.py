#multiple inheritence

class Institute:
    def ins_details(self):
        print("Sathya")


class Subject:
    def sub_info(self):

       print("Python")
class Faculty(Institute,Subject):
    def faculty_details(self):
        super().ins_details()
        super().sub_info()
        print("Naveen")

f=Faculty()
f.faculty_details()

# Sathya
# Python
# Naveen