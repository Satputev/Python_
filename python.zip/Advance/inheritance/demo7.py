#example script to call overriden method

class A:
    def show(self):
        print("I am A class Show")
class B(A):
    def show(self):
        print("I am B class show")
        super().show()#callig overriden method

b=B()
b.show()
# I am B class show
# I am A class Show