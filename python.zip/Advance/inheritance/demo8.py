#first class student

from Advance.inheritance.calculator.main import First

f=First()
f.calc(10,20)

# Sum =  30
# Sub =  -10