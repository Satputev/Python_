class A:

    def m1(self,arg1=0,arg2=''):
        print('m1 with arg:',arg1,arg2)

b=A()
b.m1()
b.m1(10)
b.m1(10,'20')

