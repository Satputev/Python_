#example script to call super class constructor

class A:
    def __init__(self):
        print("I am A class constructor")

class B(A):
    def __init__(self):
        super().__init__()#calling superclass constructor we use super()
        print("I am B class constructor")

B()#I am A class constructor
#I am B class constructor

