
import re
data='Th is2'
res = re.search(r"^[a-z+A-Z+ +0-9+@]*$", data)
print(res.group(0))
