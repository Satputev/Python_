import re
data="Sathya tech from AMPT"
x=re.match(r"Sathya",data)
y=re.match(r"tech",data)

print(x)
print(y)#None


# Enter some data: Sathya tech
# <re.Match object; span=(0, 6), match='Sathya'>


