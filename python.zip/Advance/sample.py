def wish():
    a=10
    print(a)

ins_name="sathyaa"

class PFaculty:
    subject="Python"

    def assign(self,id,na):
        self.idno=id
        self.name=na

    def display(self):
        print(PFaculty.subject)
        print(self.idno)
        print(self.name)
        print(ins_name)

def createInstance():
    p1=PFaculty();
    p1.assign(101,"Ravi")
    return p1

