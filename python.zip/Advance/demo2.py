#using one function

from sample import wish

#function calling
wish()