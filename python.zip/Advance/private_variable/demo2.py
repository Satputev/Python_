class Employee:
    def __init__(self,id,na):
        self.idno=id
        self.__name=na



class Developer(Employee):
    def setSal(self, sal):
        self.salary = sal

    def display(self):
        print("IDNO:",self.idno)
        #print("Name:",self.__name)#AttributeError: 'Developer' object has no attribute '_Developer__name'

        print("SALARY:",self.salary)

d1=Developer(101,"Ravi")
d1.setSal(185000.00)
d1.display()