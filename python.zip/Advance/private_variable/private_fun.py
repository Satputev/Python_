class Employee:
    def __setDetails(self,idno,name,sal):
        self.idno=idno
        self.name=name
        self.salary=sal

    def displayDetails(self):
        print("Idno:",self.idno)
        print("Name:",self.name)
        print("Salary:",self.salary)

class Developer(Employee):
    def setDes(self,role):
        self.designation=role
    def display(self):
        print("Idno:",self.idno)
        print("Name:",self.name)
        print("Salary:",self.salary)
        print("Role:",self.designation)


d=Developer()
d.__setDetails(101,"Ravi",185000)#AttributeError: 'Developer' object has no attribute '__setDetails'


