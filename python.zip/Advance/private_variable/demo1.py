#private variable
#The scope of private variable is inside class only
class Employee:
    def __init__(self,id,na):
        self.idno=id
        self.__name=na

    def getSal(self,sal):
        self.salary=sal

e1=Employee(101,"Ravi")
e1.getSal(18500.00)
#calling instance variable
print(e1.idno)#101
print(e1.salary)#18500.00
#calling private instance variable
print(e1.__name)#AttributeError: 'Employee' object has no attribute '__name'


