class Employee:
    def __init__(self,id,na):
        self.idno=id
        self.name=na

    def setSal(sathya,sal):
        sathya.salary=sal

    def dispaly(Ravi):
        print("IDNO:",Ravi.idno)
        print("Name:",Ravi.name)
        print("Salary:",Ravi.salary)

e1=Employee(101,"Kumar")
#Interpreter convert above statement in following format
#Employee(e1,101,"kumar")
e1.setSal(185000.00)
#Employee.setSal(e1,185000.00)
e1.dispaly()
#Employee.display(e1)