class PFaculty:
    subject1="python"
    subject2="Django"

    def assign(self,id,no):
        self.idno=id
        self.name=no

    def display(self):
        print("faculty subject1=",PFaculty.subject1)
        print("faculty subject2=",PFaculty.subject2)
        print("Facult name is=",self.name)
        print("Faculty id is=",self.idno)


p1=PFaculty()
p1.assign(101,"Naveen")
p1.display()

p2=PFaculty()
p2.assign(102,"Kumar")
p2.display()

p3=PFaculty()
p3.assign(103,"Naveen")
p3.display()
print(id(p1.name))
print(id(p3.name))

