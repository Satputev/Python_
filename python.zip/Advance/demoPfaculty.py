for x in range (1,5):
    for y in range(x):
        if x==5:
            print("*",end="")
    for z in range(4,x,-1):
        print(" ",end="")
    for k in range (x):
        print("*", end="")
    print()
    
    
