#inner function returning outer function object

def outer():
    a=25
    print("I am outer")
    def inner():
        print(a)
        return outer
    return inner

x=outer()#I am outer

print(x)  #<function outer.<locals>.inner at 0x03431148>


y=x()#25
y()#i am outer
