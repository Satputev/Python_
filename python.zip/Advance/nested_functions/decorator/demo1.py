
#decorator is a technoque to adding extra features in exinting function

def check_contact(fun_name):
    def inner():
        cno=int(input("Enter the contact no:"))
        if cno==987654321:
            print("ok")
            fun_name()
        else:
            print("Wrong contact no..")
    return inner

def show_password():
    print("Hi Ravi")
    print("Your password is:ravi@123")

def show_accountno():
    print("Hi Ravi")
    print("Your account no is:4561255555665")


inn=check_contact(show_password)
inn()

inn=check_contact(show_accountno)
inn()
