def check_contact(fun_name):
    def inner():
        cno=int(input("Enter the contact no:"))
        if cno==987654321:
            print("ok")
            fun_name()
        else:
            print("not ok")
    return inner


@check_contact
def show_password():
    print("hi Ravi")
    print("Your password is:ravi@123")


@check_contact
def show_account():
    print("hi Ravi")
    print("your account no is:9875611225563225")

show_password()
show_account()