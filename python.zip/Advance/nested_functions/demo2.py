#passing function name as argument

def inc(no):
    no=no+1
    return no

def dec(no):
    no=no-1
    return no

def opertion(fun,no):
    print(fun(no))

x=opertion(inc,10)
y=opertion(dec,20)
