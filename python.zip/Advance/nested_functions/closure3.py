
def inner(x):
    return x

def outer(arg1,fun):

    return fun(arg1)


x=outer(10,inner)
print(x)
del outer
try:
    y = outer(20, inner())  # NameError: name 'outer' is not defined
except NameError:
    try:
        print(y)
    except NameError:
        print("Hello")


