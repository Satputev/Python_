def outer():
    print("I am outer")
    a=100
    def inner():
        print("I am inner")
        print(a)
    return inner

print(outer)#<function outer at 0x02EA11D8>

inn=outer()
del outer
inn()

# I am outer
# I am inner
# 100