#nested function

def outer():
    print("I am outer..")
    a=10
    def inner():
        print("I am inner")
        print(a)
    inner()

outer()

# I am outer..
# I am inner
# 10