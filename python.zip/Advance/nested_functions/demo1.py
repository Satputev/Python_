def sample():
    print("hii")
    print("I am sample")


x = sample
x()#calling function

# hii
# I am sample