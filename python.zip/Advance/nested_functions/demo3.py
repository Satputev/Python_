def sum(no1,no2):
    return no1+no2

def sub(no1,no2):
    return no1-no2

def mul(no1,no2):
    return no1*no2

def div(no1,no2):
    return no1/no2

def operation(fun,no1,no2):
    print(fun(no1,no2))

operation(sum,10,20)#30
operation(sub,25,10)#15
operation(mul,10,3)#30
operation(div,6,2)#3.0
