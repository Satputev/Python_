def outer():
    print("Outer function")
    a=10
    def inner():
        print("Inner function")
        return a
    return inner()

x=outer()
print(x)

# Outer function
# Inner function
# 10