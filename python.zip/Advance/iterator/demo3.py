class MyIterator:
    def __init__(self,m):
        self.ma=m

    def __iter__(self):
        self.no=0
        return self

    def __next__(self):
        if self.no<=self.ma:
            x=self.no
            self.no+=1
            return x
        else:
            raise StopIteration



for x in MyIterator(10):
    print(x)

print("-------------------------------")
