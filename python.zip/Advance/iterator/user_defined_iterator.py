class MyIterator:
    def __init__(self,m):
        self.max=m

    def __iter__(self):
        self.no=1
        return self

    def __next__(self):
        if self.max>=self.no:
            x=self.no
            self.no += 1
            return x
        else:
            raise StopIteration


m=MyIterator(3)
i=iter(m)
print(next(i))
print(next(i))
print(next(i))
#print(next(i))#StopIteration


print("--------------------------")
#using for loop

for x in MyIterator(50):
    print(x)

print("--------------")
#using while loop
w=MyIterator(10)
i=iter(w)
while True:
    try:
        print(next(i),end=" ")
    except StopIteration:
        break