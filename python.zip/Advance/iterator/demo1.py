#reading individual element manually without using loop on list

data=[10,20,30,40,50,60]
i=iter(data)
print(i)#<list_iterator object at 0x016EEA60>

print(type(i))#<class 'list_iterator'>

print(next(i))
print(next(i))
print(next(i))
print(next(i))
print(next(i))
print(next(i))
#print(next(i))#StopIteration
