#using while loop on iterator
data=[10,20,30,40,50,100]
i=iter(data)
while True:
    try:
        print(next(i))
    except StopIteration:
        break
print("---------------------------")
#using for loop

for x in data:
    print(x)

