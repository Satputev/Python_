#listing pass and fail subject

marks=[10,80,45,62,32,34]

res=[]
def myfun(mks):
    for x in mks:
        if x>=35:
            res.append("Pass")
        else:
            res.append("Fail")
myfun(marks)
print(res)#['Fail', 'Pass', 'Pass', 'Pass', 'Fail', 'Fail']


print("-----------------------------------------------------")

#using lambda function
res=list(map(lambda x:"Pass" if x>=35 else "Fail",marks))
print(res)#['Fail', 'Pass', 'Pass', 'Pass', 'Fail', 'Fail']

print("-----------------------------------------------------")

#using list comprehension

rs=["Pass" if x >=35 else "Fail" for x in marks]
print(rs)#['Fail', 'Pass', 'Pass', 'Pass', 'Fail', 'Fail']

