d1={"idno":101,"name":"Ravi","Salary":185000.00}
print(d1)
print("--------------------------------")

#example on dictionary comprehension

d2={k:v*2 for k,v in d1.items()}
print(d2)#{'idno': 202, 'name': 'RaviRavi', 'Salary': 370000.0}
print("-----------------------------------")


d3={k*3:v for k,v in d1.items()}
print(d3)#{'idnoidnoidno': 101, 'namenamename': 'Ravi', 'SalarySalarySalary': 185000.0}
print("----------------------------------------")

d4={k*2 for k,v in d1.items()}
print(d4)#{'idnoidno', 'SalarySalary', 'namename'}

print(type(d4))#<class 'set'>

print("----------------------------------")

d5={k*2 for k in d1}
print(d5)#{'idnoidno', 'namename', 'SalarySalary'}
print("------------------------------------------")

d6={k for k,v in d1.items()}
print(d6)#{'Salary', 'idno', 'name'}
print("-------------------------------------------")

d7={v for k,v in d1.items()}
print(d7)#{185000.0, 'Ravi', 101}






