#list comprehensions

#print 5 table
#without using list comprehensions

#1

res=[]

for x in range(1,11):
    res.append(x*5)

for x in res:
    print(x,end=" ")

print("\n-----------------------------")

#2
for x in range(1,11):
    print(x*5,end=" ")

print("\n-----------------------------------------")
#using list comprehension
y=[x*5 for x in range(1,11)]
print(y)