#find even nos in 3 table

#using generator function
def mygen(max):
    no=0
    while True:

        if max>=no:
            no += 1
            x=no*3
            if(x%2==0):
                yield x
            else:
                continue
        else:
            break
for x in mygen(9):
    print(x)
print("--------------------------------")


#using generator expression

gn=(x*3 for x in range(1,11) if x%2==0)
print(gn)#<generator object <genexpr> at 0x017DA4F8>
print(type(gn))#<class 'generator'>

for y in gn:
    print(y,end=" ")#6 12 18 24 30


