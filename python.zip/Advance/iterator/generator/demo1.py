def myFun():
    no=1
    yield no

    no+=1
    yield no

    no+=1
    yield no

x=myFun()
print(next(x))
print(next(x))
print(next(x))
#print(next(x))#StopIteration
