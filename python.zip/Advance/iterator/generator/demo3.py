#Generator function

def multi(max=0):
    no=1
    while True:
        if max>=no:
            x=no*3
            no+=1
            yield x
        else:
            break


for x in multi(10):
    print(x,end=" ")#3 6 9 12 15 18 21 24 27 30

print("\n-----------------")


#Generator Expression

res=(x*3 for x in range(1,11))
for x in res:
    print(x,end=" ")