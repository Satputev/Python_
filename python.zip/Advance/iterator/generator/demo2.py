#defining generator function to work for defined no of times

def myGen(max):
    no=0
    while True:
        no+=1
        if max>=no:
            yield no
        else:
            break

x=myGen(5)
print(next(x))#1
print(next(x))#2
print(next(x))#3
print(next(x))#4
print(next(x))#5
#print(next(x))#StopIteration

#using for loop
for x in myGen(10):
    print(x)