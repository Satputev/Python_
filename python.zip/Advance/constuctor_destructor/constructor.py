class PFaculty:
    def __init__(self):
        self.idno=101
        self.name="Ravi"
        self.sal=185000.0
        print("I am default constructor..")


    def display(self):
        print(self.idno)
        print(self.name)
        print(self.sal)


p1=PFaculty()#I am default constructor..
p1.display() #101
            #Ravi
            #185000.0
p1.__init__()#I am default constructor..

p1.__init__()#I am default constructor..

