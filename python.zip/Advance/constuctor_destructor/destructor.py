class PFaculty:
    def __init__(self):
        self.idno = 101
        self.name = "Ravi"
        print("this is the constructor")
    def __del__(self):

        print("this is the destructor")
        print("Idno:",self.idno,"name:",self.name)
    def display(self):
        print(self.idno,self.name)

p1=PFaculty()
p1.display()

#now here first constructor is called then display() ,the destructor is called.