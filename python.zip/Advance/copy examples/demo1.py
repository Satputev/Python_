#copy

l1=[10,20,30,40,50]
print(l1)#[10, 20, 30, 40, 50]

l2=l1#copy
print(l2)#[10, 20, 30, 40, 50]

#l2 list is modified

l2[3]=90

print(l1)#[10, 20, 30, 90, 50]

print(l2)#[10, 20, 30, 90, 50]
