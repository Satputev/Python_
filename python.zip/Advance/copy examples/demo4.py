import copy as c

l1=[[10,20],[30,40]]
l2=c.copy(l1)#create shallow copy of l2 and assign to l2

print(l1)
print(l2)

#outer list is modified

l1.append(50)
print(l1)#[[10, 20], [30, 40], 50]
print(l2)#[[10, 20], [30, 40]]


#inner list is modified

l1[0][1]=99
print(l1)#[[10, 99], [30, 40], 50]
print(l2)#[[10, 99], [30, 40]]
