l1=[10,20,30,40,50]
l2=l1.copy()#it is list class method used to create shallow copy
print(l1)
print(l2)

l2[3]=99
print(l1)#[10, 20, 30, 40, 50]

print(l2)#[10, 20, 30, 99, 50]

#if l2 is modified l1 is not affected because in shallow copy l1 and l2 has different objects

