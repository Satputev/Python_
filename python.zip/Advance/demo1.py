#using global variable

from sample import ins_name
print(ins_name)