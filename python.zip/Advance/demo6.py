from demo5 import f1
f1.display()
print(f1.subject)