# Write a python program to find the longest words in a file
# Using test.txt file in same folder
#
# file=open('test.txt')
# data=file.read()
# dl=data.split()
# l_word=len(dl[0])
# for word in dl:
#     if len(word) > l_word:
#         l_word = len(word)
# file.close()
# print([word for word in dl if len(word)==l_word])


def longest_word(filename):
    with open(filename) as infile:
        words=infile.read().split()
        max_len=len(max(words,key=len))
        infile.close()
    return [word for word in words if len(word)==max_len]
print(longest_word('test.txt'))
