# Write a Python program to read a random line from a file.
# Using test.txt

import random

def random_line(filename):
    lines=open(filename).read().splitlines()
    return random.choice(lines)
print(random_line('test.txt'))