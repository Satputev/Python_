# xyz=x!+y!+z! can you find values of x,y,z
# xyz=1!+2!+3!
#     =1+2+6
#     =1,2,(2,3)
#     =1,2,3

x=256
y=(2*1)+(5*4*3*2*1)+(6*5*4*3*2*1)
data=[]
while x!=0:
    r=x%10
    data.append(r)
    x=x//10

print('z,y,x ',data,'res')