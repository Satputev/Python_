# Print the longest palindrome in a file along with no of time it is repeated

def longest_palindrome(file):
    with open(file) as f:
        words=f.read().split()
        pd={}
        for word in words:
            for x in range (len(word)):
                if word[x]==word[-x-1]:
                    continue
                else:
                    break
            else:
                if word in pd:
                    pd[word]+=1
                else:
                    pd[word]=1

        pdlen=len(max(pd.keys(),key=len))
        f.close()
    return {word:pd[word] for word in pd if len(word)==pdlen}


print(longest_palindrome('test.txt'))#{'madam': 2}