#write a python program to print all the unique word in the file along with no of times each word is repeated
# words=open('test.txt').read().split()
# from collections import Counter
# print(Counter(words))

def find_count(fname):
    file=open(fname)
    words=file.read().split()
    d1={}
    for word in words:
        if word in d1:
            d1[word]=d1[word]+1
        else:
            d1[word]=1
        file.close()
    return d1

print(find_count('test.txt'))