#print all unique palindromes in file along with number of times each word is repeated.

def find_unique_palindromes(fname):
    file=open(fname)
    words=file.read().split()
    d1={}
    for word in words:
        for pos in range(len(word)):
            if word[pos]==word[-pos-1]:
                continue
            else:
                break
        else:
            if word in d1:
                d1[word]+=1
            else:
                d1[word]=1
        file.close()
    return d1
print(find_unique_palindromes('test.txt'))#{'a': 3, 'aba': 2, 'madam': 2}


