# Write a Python program to read first n lines of a file.
# Use test.txt file

def read_n_lines(n):
    file=open('test.txt')
    data=file.read().split('\n')
    for x in range(n):
        print(data[x])
    file.close()

read_n_lines(3)




def file_read_from_head(fname,nlines):
    from itertools import islice
    with open(fname) as f:
        for line in islice(f,nlines):
            print(line)
    f.close()
file_read_from_head('test.txt',3)
