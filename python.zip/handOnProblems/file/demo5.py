#write a python program to print no of words in file
print(len(open('test.txt').read().split()))#100