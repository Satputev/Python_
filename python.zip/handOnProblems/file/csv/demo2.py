r1=["Length","Title","Actress","Awards"]
rr1=[[111,"Tie me Up","Abril,Victoria","NO"],
[96,"High Heels","Abril,Victoria","YES"],
[122,"Dead Zone The","Jacky Chan",'YES'],
[95,"Cube","Michal,Jaxan",'YES'],
[85,"Subway","ARMAN,ARMANI","NO"],
[96,"BlackMall","Michal,Jaxan","NO"],
[90,"Colors","Obama,Jaxan","NO"],
[88,"Final Notice","Trump,Putin","YES"],
     ]
file=open('award.csv','w')

import csv
ref=csv.writer(file)
ref.writerow(r1)
ref.writerows(rr1)
file.close()
print('Data written')