# write a python code to print average lenth of movie by subject

f1=open('movie.csv')
f2=open('award.csv')
import csv
f1r=csv.reader(f1)
f2r=csv.reader(f2)

d1={row[1]:row[2] for row in f1r for x in range(len(row)) if x==1 or x==2}
# print(d1)
d2={row[1]:row[0] for row in f2r for x in range(len(row)) if x==0 or x==1}
# print(d2)
d3={}

for title1 in d1:
    for title in d2:
        if title1==title:
            if d1[title1] in d3:
                d3[d1[title1]]=int((int(d2[title])+int(d3[d1[title1]])))/2
            else:
                if d2[title]== "Length":
                    continue
                d3[d1[title1]]=int(d2[title])

print(d3)#{'Comedy': 103.5, 'Horrer': 105.0, 'Action': 95, 'Drama': 87.5, 'Mistery': 96}
f1.close()
f2.close()