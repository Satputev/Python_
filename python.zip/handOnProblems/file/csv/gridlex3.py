# Write a python code to print the name of actress who acted in most no of movies

file=open('award.csv')
import csv
ref=csv.reader(file)
actress={}
for row in ref:
    for col in range(len(row)):
        if row[col]=='Actress':
            continue
        else:
            if col==2:
                if row[col] in actress:
                    actress[row[col]]+=1
                else:
                    actress[row[col]]=1

m=max(actress.values())
print([actres for actres in actress if actress[actres]==m])#['Abril,Victoria', 'Michal,Jaxan']

