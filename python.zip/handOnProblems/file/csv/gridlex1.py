# write a python code to print no of movies by subject

file=open('movie.csv')
import csv
ref=csv.reader(file)
d1={}
for row in ref:
    for x in range(len(row)):
        if x==2:
            if row[x]=='Subject':
                continue
            if row[x] in d1:
                d1[row[x]]+=1
            else:
                d1[row[x]]=1

print(d1)#{'Comedy': 2, 'Horrer': 2, 'Action': 1, 'Drama': 2, 'Mistery': 1}
file.close()

