import csv

r1=["Year",'Title',"Subject",'Popularity']

rr1=[[1990,"Tie me Up","Comedy",68],
[1991,"High Heels","Comedy",68],
[1993,"Dead Zone The","Horrer",79],
[1979,"Cube","Action",6],
[1978,"Subway","Drama",32],
[1991,"BlackMall","Mistery",2],
[1990,"Colors","Drama",80],
[1988,"Final Notice","Horrer",88],
     ]
file=open('movie.csv','w')
ref=csv.writer(file)

ref.writerow(r1)
ref.writerows(rr1)

file.close()
print('Data written')