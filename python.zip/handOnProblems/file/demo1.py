# Write a Python program to get the file size of a plain file.
# Use test.txt file at same folder

# file=open('test.txt','w')
# file.write("# Write a Python program to get the file size of a plain file.")
# file.close()
# print('Data written successfully..')

file = open('test.txt')
print(file.__sizeof__())#192

file.close()