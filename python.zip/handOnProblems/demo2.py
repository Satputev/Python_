for x in range(1,10):
    if x>5:
        print('*'*(10-x))
    else:
        print('*'*x)

# *
# **
# ***
# ****
# *****
# ****
# ***
# **
# *

print('-------------------------------')
n=5

for x in range(1,n+1):
    print('*'*x,end='')
    print()

for x in range(n-1,0,-1):
    print('*'*x,end='')
    print()


# *
# **
# ***
# ****
# *****
# ****
# ***
# **
# *

print('----------------------------')
