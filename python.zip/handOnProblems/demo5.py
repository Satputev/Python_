# Write a Python program to get the Fibonacci series between 0 to 50

n1,n2=0,1
#
# for x in range(0,50):
#     if n1+n2<=50:
#         if x==0:
#             print(n2,end=' ')
#         n3=n1+n2
#         n1=n2
#         n2=n3
#         print(n2,end=' ')
#     else:
#         break
#
# #1 1 2 3 5 8 13 21 34
#

while n2<50:
    print(n2,end=' ')
    n1,n2=n2,n1+n2

#1 1 2 3 5 8 13 21 34
