# Write a Python program to count the occurrences of each word in a given sentence
sentances=input("Enter the sentence")

def count_words(sentence):
    l1=sentence.split()
    count=0
    d1={}
    for word in l1:
        if word in d1:
            d1[word]+=1
        else:
            d1[word]=1
    return d1
print(count_words(sentances))