# 'The quick brown fox jumps over the lazy dog.'
# input : "The quick brown fox jumps over the lazy dog."
# output : "dog. lazy the over jumps fox brown quick The "

st1="The quick brown fox jumps over the lazy dog."
ft=st1.split()
ft.reverse()
for x in ft:
    print(x,end=' ')#dog. lazy the over jumps fox brown quick The
print()
def reverse_string_word(lines):
    for line in lines.split('/n'):
        return ' '.join(line.split()[::-1])
s=reverse_string_word(st1)
print(s)#dog. lazy the over jumps fox brown quick The

print(st1[::-1])#.god yzal eht revo spmuj xof nworb kciuq ehT


