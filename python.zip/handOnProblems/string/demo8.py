# Write a Python program to calculate the length of a string.
# st='''String
# hello welcome
# hi how are you hello
# hii'''
# c=0
# for line in st.split('\n'):
#     print(line)
#     c+=len(line)
# print(c)#42

def calculate_length(string):
    count=0
    for char in string:
        count+=1
    return count
print(calculate_length('hello world'))#11 empty spaces also calculated