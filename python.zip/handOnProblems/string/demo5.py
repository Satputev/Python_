# Write a Python function that takes a list of words and returns the length of the longest one

# def find_longest_word_lenth(data):
#     list=data.split()
#     l_word=''
#     for x in list:
#         if len(x)>len(l_word):
#             l_word=x
#     return len(l_word)
#
# print(find_longest_word_lenth('hi how are you Im fine'))#4

def find_longest_word(word_list):
    word_len=[]
    for x in word_list:
        word_len.append((len(x),x))
        print(word_len)
        word_len.sort()

    return word_len[-1][1]
print(find_longest_word(["PHP", "Exercises", "Backend"]))#Exercises
