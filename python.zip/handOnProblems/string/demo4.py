# Write a Python function to create the HTML string with tags around the word(s).
# Sample function and result :
# add_tags('i', 'Python') -> '<i>Python</i>'
# add_tags('b', 'Python Tutorial') -> '<b>Python Tutorial </b>'

# def add_tags(tag,data):
#     return '<'+str(tag)+'>'+str(data)+'</'+str(tag)+'>'
#
# print(add_tags('i','Python'))#<i>Python</i>
# print(add_tags('b','Python Tutorial '))#<b>Python Tutorial </b>


def add_tag(tag,word):
    return '<%s>%s</%s>'%(tag,word,tag)
print(add_tag('i','Python'))#<i>Python</i>
print(add_tag('i','Python Titorial'))#<i>Python Titorial</i>


# print('hello<{%s}%s>%s{}>'%(1,2,3))#hello<{1}2>3{}>
