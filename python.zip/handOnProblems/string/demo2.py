# Write a Python program to change a given string to a new string where the first and last chars have been exchanged

# str1='hello'
# exchange=[]
# for x in str1:
#     if str1.index(x)==0:
#         exchange.append(str1[-1])
#     elif str1.index(x)==len(str1)-1:
#         print(str1[0])
#         exchange.append(str1[0])
#     else:
#         exchange.append(x)
# print(''.join(exchange))


def change_str(string):
    return string[-1:]+string[1:-1]+string[:1]

print(change_str('abcd'))#dbca