# Write a Python program to count the number of characters (character frequency) in a string.
# Expected Result : {'o': 3, 'g': 2, '.': 1, 'e': 1, 'l': 1, 'm': 1, 'c': 1}

# import collections
#
# st1='abaabccbdbsaa'
# print(collections.Counter(st1))#Counter({'a': 5, 'b': 4, 'c': 2, 'd': 1, 's': 1})


def char_frequency(st1):
    d1={}
    keys=d1.keys()
    for x in st1:
        if x in keys:
            d1[x]+=1
        else:
            d1[x]=1
    return d1
print(char_frequency('google'))#{'g': 2, 'o': 2, 'l': 1, 'e': 1}