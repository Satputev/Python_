# Write a Python program that accepts a comma separated sequence of words as input and prints the unique words in sorted form (alphanumerically)
# Sample Words : red, white, black, red, green, black
# Expected Result : black, green, red, white,red

# words=input("Enter the words: ")
#
# w=words.split(',')
# ww=set(w)
# sorted_list=list(ww)
# sorted_list.sort()
# print(','.join(sorted_list))#black,green,red,white
#

items=input("Input comma seperated sequence of words")

words=[word for word in items.split(',')]
print(','.join(sorted(list(set(words)))))#black,green,red,white
