#write no of letters and digits in given string

string=input('Enter the string')
d=l=0
for c in string:
    if c.isalpha():
        l+=1
    elif c.isdigit():
        d+=1
    else:
        pass
print('digits: ',d,'\n'+'letters:',l)

# digits:  2
#  letters: 6