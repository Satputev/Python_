# Check if a given key already exists in a dictionary
# input
# d = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
# is_key_present(5)
# is_key_present(9)
# output
# Key is present in the dictionary
# Key is not present in the dictionary

# d=eval(input('Enter the dict: '))
# key=eval(input('Enter the key: '))
#
# if key in d:
#     print('Key is present!')
# else:
#     print("Key is not Present!")
# # Enter the dict: {1:10,2:20,3:30,4:40,5:50,6:60}
# # Enter the key: 5
# # Key is present!

d={1:10,2:20,3:30,4:40,5:50,6:60}

def is_key_present(key):
    if key in d:
        print('Key is Present in dictionary!')
    else:
        print('Key is not present in dictionary..')
is_key_present(5)#Key is Present in dictionary!

is_key_present(9)#Key is not present in dictionary..