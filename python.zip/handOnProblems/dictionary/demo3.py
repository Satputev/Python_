# Write a Python program to iterate over dictionaries using for loops.
# d1={1:10,2:20,3:30,4:40}
#
# for x in d1:
#     print(x,'...',d1[x])

d={'x':10,'y':20,'z':30}

for dict_key,dict_value in d.items():
    print(dict_key,'->',dict_value)

# x -> 10
# y -> 20
# z -> 30