# Write a Python program to sort (ascending and descending) a dictionary by value.
# Original dictionary :  {0: 0, 1: 2, 2: 1, 3: 4, 4: 3}
# Dictionary in ascending order by value :  [(0, 0), (1, 2), (2, 1), (3, 4), (4, 3)]
# Dictionary in descending order by value :  [(4, 3), (3, 4), (2, 1), (1, 2), (0, 0)]

d = {1: 2, 3: 4, 4: 3, 2: 1, 0: 0}
# sort=list(d.items())
# sort.sort()
# print('Accending order by value: ',sort)
# sort.sort(reverse=True)
# print('Decending order by value: ',sort)


import operator
print('acending order: ',sorted(d.items(),key=operator.itemgetter(0)))#acending order:  [(0, 0), (1, 2), (2, 1), (3, 4), (4, 3)]
print('decending order: ',sorted(d.items(),key=operator.itemgetter(0),reverse=True))#decending order:  [(4, 3), (3, 4), (2, 1), (1, 2), (0, 0)]
