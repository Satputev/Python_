# m=int(input("Enter no of rows: "))
# n=int(input("Enter the no of columns: "))
# ml=[]
# for x in range(m):
#     nl=[]
#     for y in range(n):
#         nl.append(x*y)
#     ml.append(nl)
#
# print(ml)

#############their solution####################3
row_num=int(input("Input no of rows:"))
col_num=int(input("Input no of columns:"))
multi_list=[[0 for col in range(col_num)] for row in range(row_num)]
print(multi_list)
for row in range(row_num):
    for col in range(col_num):
        multi_list[row][col]=row*col
print(multi_list)