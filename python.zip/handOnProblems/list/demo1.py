# Convert a list of characters into a string
# Input ['a', 'b', 'c', 'd']
# Output abcd

l1=eval(input('Enter str list: '))

print(''.join(l1))