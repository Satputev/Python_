# Write a Python program to find common items from two lists.
# input
# color1 = "Red", "Green", "Orange", "White"
# color2 = "Black", "Green", "White", "Pink"
# output
# {'Green', 'White'}


color1='Red','Green','Orange','White'
color2='Black','Green','White','Pink'
# l1=[]
# for c in color1:
#     if c in color2:
#         l1.append(c)
#
# for x in l1:print(x)
# # Green
# White

print(set(color1) & set(color2))#{'Green', 'White'}

