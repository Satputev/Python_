# Write a Python program to get the smallest number from a list.
# max_num_in_list([1, 2, -8, 0])
# return 2


# l1=[1,2,-8,0]
# max=0
# for x in l1:
#     if x>max:
#         max=x
# print("max:",max)#max: 2


def max_num_in_list(list):
    max=list[0]
    for a in list:
        if a>max:
            max=a
    return max


print(max_num_in_list([1,2,-8,0]))#2