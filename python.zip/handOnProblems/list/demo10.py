# Write a Python program to sum all the items in a list
# Example sum_list([1,2,-8])
# Return -5

# def sum_list(numbers):
#     return sum(numbers)
# print(sum_list([1,2,-8]))#-5
#

def sum_list(items):
    sum_numbers=0
    for x in items:
        sum_numbers+=x
    return sum_numbers
print(sum_list([1,2,-8]))#-5
