# Write a Python program to find the second smallest number in a list.
# input
# second_smallest([1, 2, -8, -2, 0])
# output
# -2

# a=[1,2,-8,-2,0]
#
# s1=s2=a[1]
#
# for x in a:
#     if x<s1:
#         s1,s2=x,s1
#     elif x<s2:
#         s1,s2=s1,x
# print(s2)#-2


def second_smallest(numbers):
    a1,a2=float('inf'),float('inf')#float('inf') means float of infinity
    for x in numbers:
        if x<a1:
            a1,a2=x,a1
        elif x<a2:
            a1,a2=a1,x
    return a2
print(second_smallest([1, 2, -8, -2, 0]))#-2

