#counting no of odd nos and no of even numbers

numbers=eval(input("Enter the nos:"))
count_even=count_odd=0
for no in numbers:
    if no%2==0:
        count_even+=1
    else:
        count_odd+=1

print("No of odd and even nos are: ",count_odd,count_even,'resp.')
#No of odd and even nos are:  5 4 resp.
