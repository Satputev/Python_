result=(2*(3+4)**2-(3**3)*3)
print(result)#17

#operator precedence
#1.parenthesis
#2.Exponent
#3.Unary positive ,Negative and Not
#4.multification,Division,Modulo,Floor division
#5.Addition,Substraction
#6 and

print("-------------------")
print(bool([False]))
print(bool(3))
print(bool(""))
print(bool(''))

# True
# True
# False
# False

# Empty String, Empty List, Empty tuple,Empty dict and range(0) arguments bool() function returns False

print("-------------------------")
print(bool ([]))#False
print(bool(()))#False
print(bool(range(0)))#False
print(bool({}))#False
print(set())#set()