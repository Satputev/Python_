l1=[4,54,5,52,25,25,58,86,10,20,30,40]
l2=[4,54,5,52,25,25,58,86,10,20,30,40]

print(l1 is l2)#False
print(l1==l2)#True

l2=l1 #assigning l1 ref to l2 so l1 and l2 has same ref
print(l1 is l2)#True
print(l1==l2)#True
print("-------------------------")
l3=[5,10,15,20,25]
l4=['E','J','O','T','Y']

print(l3 is l4)
print(l3==l4)
l3=l4
print(l3 is l4)
print(l3==l4)

# False
# False
# True
# True