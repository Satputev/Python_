#slice operator

l1=[4,54,5,52,25,25,58,86,10,20,30,40]
a=l1[1:-2]
print(a)#[54, 5, 52, 25, 25, 58, 86, 10, 20]

a=l1[:-3]
print(a)#[54, 5, 52, 25, 25, 58, 86, 10]


a=l1[1:-3]
print(a)#[54, 5, 52, 25, 25, 58, 86, 10]

print(l1[0:-2])#[4, 54, 5, 52, 25, 25, 58, 86, 10, 20]

print(l1[0:-3])#[4, 54, 5, 52, 25, 25, 58, 86, 10]

#indexing [0:-3]
# 0 -is starting index ,-3 is ending index we access 0 to -3 mens excluding last three element
print("----------------------------")

#we want only last three

print(len(l1))#12

print(l1[9:])
print(l1[-3:])
print(l1[9:12])

# [20, 30, 40]
# [20, 30, 40]
# [20, 30, 40]
print("------------------------")
print(l1[1:1000])
print(l1[-10:10])
print(l1[0:12])

#list index start with 0 from rhs and -1 with lhs
# [54, 5, 52, 25, 25, 58, 86, 10, 20, 30, 40]
# [5, 52, 25, 25, 58, 86, 10, 20]
# [4, 54, 5, 52, 25, 25, 58, 86, 10, 20, 30, 40]

#slice operator never rises index error

