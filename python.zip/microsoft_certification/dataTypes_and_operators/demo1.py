name='Ravi'
idno=101
salary=185000.0
status=True

print(type(name))
print(type(idno))
print(type(salary))
print(type(status))


# <class 'str'>
# <class 'int'>
# <class 'float'>
# <class 'bool'>