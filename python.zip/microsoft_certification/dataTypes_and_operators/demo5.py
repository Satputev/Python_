a=15
b=3
print(a/b)#5.0

# "/"always meant for floating point arithmatic


print("----------")
c=10
d=3
print(c/d)#3.3333
print(c//d)#3
print(c%d)#1

#/ is meant for floating point
#// is meant for floaing type and int type based on argument type
# % returns the reminder it also float and int type based on argument type