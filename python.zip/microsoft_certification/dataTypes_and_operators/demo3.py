l1=[4,54,5,52,25,25,58,86,10,20,30,40]
print(l1[0])
#print(l1[12])#IndexError: list index out of range
print(l1[-1])
l2=[4,54,5,52,25,25,58,86,10,20,30,40]
print(id(l1))
print(id(l2))
a=10
b=10
print(id(a),id(b))
print(l1 is l2)#False
print(l1==l2)#True

#"is" operator is meant for reference comparision ref(l1 )!= ref(l2)
# "==" operator is meant for content comparision  content(l1)==content(l2)
print("------------------------------")
s1={4,54,5,52,25,25,58,86,10,20,30,40}
s2={4,54,5,52,25,25,58,86,10,20,30,40}
print(s1 is s2)