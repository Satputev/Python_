numbers=[10,20,30,40]
x=0

for i in (30,40,50):
    if i in numbers:
        x=x+5
print(x)#10

for i in (30,40,50):
    if i not in numbers:
        x=x+5
print(x)#5

for i in (30 ,40 ,50):
    if i not in numbers:
        x=x+10
print(x)#10

for i in (30,40,50):
    if i in numbers:
        x=x+10
print(x)#20