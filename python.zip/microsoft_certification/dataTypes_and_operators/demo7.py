a=3
b=5
a+=2**3
a-=b//2//3
print(a)#11

print("-----------------------")
result=8//6%5+2**3-2
print(result)#7

print("-----------------------------")

a=1
b=3
c=5
d=7

print(a+b*2)#7
print(a%b-1)#0
print(a-b//d)#1
print(a**d-1)#0

print("--------------------------")
a=1
b=2
c=4
d=6
print((a+b)//c%d)#0
print((b+c)//a%d)#0
print((a+b)//c*d)#0
print((a+b)//d-c)#-4