
from abc import ABC,abstractmethod

class Employee(ABC):
    @abstractmethod
    def getInfo(self):
        pass
    def insInfo(self):
        print("sathya Technology")


# emp=Employee()#TypeError: Can't instantiate abstract class Employee with abstract methods getInfo

# emp.getInfo()
# emp.insInfo()

class Developer(Employee):
    def getInfo(self):
        print("Idno:101")
        print("Name: Ravi")
        print("Salary: 185000.00")
class Tester(Employee):
    def getInfo(self):
        print("Idno: 111")
        print("Nmae: Kumar")
        print("Salary: 225000.00")
class Designer(Employee):
    def getInfo(self):
        print("Name:Vanketesh")
        print("Idno:100")
        print("Salary:300000.00")
    def insInfo(self):
        print("Nareshit+Sathya")

t1=Tester()
t1.insInfo()
t1.getInfo()
print("------------------------")
d1=Developer()
d1.insInfo()
d1.getInfo()
print("---------------------")
dd1=Designer()
dd1.insInfo()
dd1.getInfo()

