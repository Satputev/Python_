import pandas
idno=[101,102,103,104,105]
names=["Ravi","kumar","mohan","Krushna","myki"]
sal=[185000.00,285000.00,100000.00,251122.00,62532.00]

data={"IDNO":idno,"Name":names,"Salary":sal}
ref=pandas.DataFrame(data)
ref.to_csv("ED.csv")
print("data written")