file=open("sample.txt")
data=file.readlines()
print("total no of lines:",len(data))
file.close()
print("line count success....")

#finding no of words
file=open("sample.txt")
print("No of words:",len(file.read().split()))
file.close()
print("word count success...")