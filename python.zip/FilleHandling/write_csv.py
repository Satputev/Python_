import csv

fields=["IDNO","NAME","SALARY"]
rows=[
    [101,"Ravi",185000.00],
    [102,"Kumar",285000.00],
    [103,"naveen",500000.00]]

file=open("emp_details.csv","w")
ref=csv.writer(file)
ref.writerow(fields)#to write one record
ref.writerows(rows)#to write multiple rows
file.close()

print("data written")

