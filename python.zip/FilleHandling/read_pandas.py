import pandas

data=pandas.read_csv("ED.csv")
print(data)