#example script to open a file and read data from it
# open() function will open a file in given mode and it will return TextIoWrapper object


tiw=open("sample.txt","r")
#read function read data from file and return a string

text=tiw.read()
print(text)

#close the file
tiw.close()
print("Data readed successfully...")