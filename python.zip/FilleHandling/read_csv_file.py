import  csv
file=open("emp_details.csv","r")
ref=csv.reader(file)

for x in ref:
    print(x)
file.close()