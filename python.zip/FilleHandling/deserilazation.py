import pickle as pi

file=open("employee_details.txt","rb")
a=pi.load(file)
print(a)

b=pi.load(file)
print(b)

c=pi.load(file)
print(c)

d=pi.load(file)
print(d)

file.close()
print("data readed from object..")