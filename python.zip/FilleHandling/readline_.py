file=open("sample.txt")
text=file.readline()
print(text)
file.close()
print("readline example..")

#readlines function

file=open("sample.txt")
text=file.readlines()
print(text)
file.close()
print("readlines...success")