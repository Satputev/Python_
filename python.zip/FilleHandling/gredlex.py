s='aba hi kaak aba hi'
data=s.split()
print(data,len(data))
print('------------------')
a=[]
for x in data:
    for y in range(len(x)):
        if x[y]==x[-y-1]:
            continue
        else:
            break
    else:
        a.append(x)
            
print(a)
            
print('finding unique')

s1=set(a)
b=list(s1)
print(b)

print('-----finding maximun length data----')
m1=b[0]
for x in b:
    if len(x)>len(m1):
        m1=x
print(m1)
    
print('-----finding count of each palindrome-----')

d1={}
for x in data:
    count=1
    for y in b:
        if y ==x:
            d1[y]=count
            count=count+1
            if y in d1:
                    d1[y]=d1[y]+1
        
            
            
print(d1)          
print('--------------------------')
l1=[10,20,30,10,20,10,20]
l2=set(l1)
l3=list(l2)

l4=[]
d1={}
for x in range(len(l1)):
    if l1[x] not in l4:
        
        l4.append(l1[x])
        
        d1[l1[x]]=1
        continue
    else:
        
        d1[l1[x]]+=1
        continue
    
print(d1)
