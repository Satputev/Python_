file=open("sample.txt","w")
text=input("Enter data into file")
file.write(text)
file.close()
print("Data written to file")


#EXAMPLE SCRIPT TO ACCEPT FILE NAME AND DATA FROM USER ..

f_name=input("Enter the file name:")
text=input("Enter the text:")
file=open(f_name,"w")
file.write(text)

file.close()
print(" write successfully..")