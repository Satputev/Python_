import os
os.remove("sample.pdf")
print("file removed")