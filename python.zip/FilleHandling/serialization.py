import pickle as pi

file=open("sample.pdf","a")
file.write("hello this is a Naveen..")
file.write("this is demo example..")
file.close()
print("Data written successfully in pdf file....")


#append the data object into a file..
idno=int(input("Enter id :"))
name=input("Enter name:")
sal=float(input("Enter salary:"))
des=input("Enter the designation")

file=open("employee_details.txt","wb")
pi.dump(idno,file)
pi.dump(name,file)
pi.dump(sal,file)
pi.dump(des,file)

file.close()
print("written data to file")