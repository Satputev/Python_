# #append() is used to push the item into the stack
# #pop() is used to pop the item from the stack
#
# #
# # my_stack=list()
# # my_stack.append(10)
# # my_stack.append(20)
# # my_stack.append(30)
# # my_stack.append(40)
# # print(my_stack)#[10, 20, 30, 40]
# #
# # print(my_stack.pop())#40
# # print(my_stack.pop())#30
# # print(my_stack)#[10,20]
# #
#
# #stack using list with wrapper class
#
# class Stack:
#     def __init__(self):
#         self.stack=list()
#     def push(self,item):
#         self.stack.append(item)
#     def pop(self):
#         if len(self.stack)>0:
#             return self.stack.pop()
#         else:
#             return None
#     def peek(self):
#         if len(self.stack)>0:
#             return self.stack[len(self.stack)-1]
#         else:
#             return None
#     def __str__(self):
#         return str(self.stack)
#
# my_stack=Stack()
# my_stack.push(1)
# my_stack.push(3)
# print(my_stack)#[1, 3]
# print(my_stack.peek())#3
# print(my_stack.pop())#3
# print(my_stack.peek())#1
# print(my_stack.pop())#1
# print(my_stack.peek())#None


class Stack:
    def __init__(self):
        self.stack=[]
    def push(self,item):
        self.stack.append(item)
    def pop(self):
        if len(self.stack)>0:
            return self.stack.pop()
        else:
            return None
    def peek(self):
        if len(self.stack)>0:
            return self.stack[len(self.stack)-1]
        else:
            return None
    def __str__(self):
        return str(self.stack)

my_stack=Stack()
my_stack.push(3)
my_stack.push(1)
print(my_stack)#[1,3]
print(my_stack.pop())#3
print(my_stack.peek())#1