#list comprehensions

y=[x for x in range(10)]
print(y)#[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


#getting sqaure values

y=[x**2 for x in range(10)]
print(y)#[0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

#get multiples of 10
ten_x=[x*10 for x in range(1,11)]
print('10 table: '+str(ten_x))#[10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

#getting odd numbers

odd=[x for x in range(10) if x%2==1]
print('Odd numbers: ',str(odd))#[1, 3, 5, 7, 9]


#get all numbers from string
s='I love 2 go t0 7times a w3ek'
nums=[x for x in s if x.isnumeric()]
print('nums: '+ ' '.join(nums))

#getvindex of list item

list=['ravi','Kumar','Mohan']
# index=list.index('Kumar')
# print(index)#1

data=[k for k,v in enumerate(list) if v=='Mohan']
print('Index: '+str(data[0]))# Index: 2
print(data)#[2]

#delete an item from a list

import random
letters=[letter for letter in 'ABCDEF']
random.shuffle(letters)

letrs=[x for x in letters if x !='C']
print(letters,letrs)#['F', 'A', 'E', 'B', 'D', 'C'] ['F', 'A', 'E', 'B', 'D']

# if-else condition in a comprehension (must come before iteration)

new_list=[x if x%2==0 else 10*x for x in range(10)]
print("New List: "+str(new_list))#New List: [0, 10, 2, 30, 4, 50, 6, 70, 8, 90]

# nested loop iteration for 2D list
a=[[10,20],[2,3]]
new_list=[x for b in a for x in b]
print('New_list: '+str(new_list))#New_list: [10, 20, 2, 3]

#6. Write a list comprehension to create the following list [5, 10, 15, 20]

nl=[5*x for x in range(1,5)]
print("nl: "+str(nl))#nl: [5, 10, 15, 20]

