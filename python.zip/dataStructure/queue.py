#from collections import deque
# my_queue=deque()
# my_queue.append(10)
# my_queue.append(20)
# print(my_queue)#deque([10, 20])
#
# print(my_queue.popleft())#10
#

#Wrapper class for queue
from collections import deque
class Queue:
    def __init__(self):
        self.queue=deque()
    def push(self,item):
        self.queue.append(item)
    def pop(self):
        if len(self.queue)>0:
            return self.queue.popleft()
        else:
            return None
    def last(self):
        if len(self.queue)>0:
            return self.queue[len(self.queue)-1]
        else:
            return None
    def first(self):
        if len(self.queue)>0:
            return self.queue[0]
        else:
            return None
    def __str__(self):
        return str(self.queue)

my_queue=Queue()
my_queue.push(10)
my_queue.push(20)
print(my_queue)#deque([10, 20])
print(my_queue.first())#10
print(my_queue.last())#20
print(my_queue.pop())#10
print(my_queue.first(),my_queue.last())#20 20
print(my_queue.pop(),my_queue.first(),my_queue.last())#20 None None
