import speech_recognition as sr

sr.AudioData