import re

name=input("Enter the name:")

res=re.match(r'^([A-Z][a-z])$',name)
print(res)