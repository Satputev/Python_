#queue implementation

from collections import deque
queue=deque([])
print(queue)#deque([])
print(type(queue))#<class 'collections.deque'>

queue.append(1)
queue.append(2)
queue.append(3)
print(queue)#deque([1, 2, 3])

queue.popleft()
print(queue)#deque([2, 3])

if not queue:

    print("Queue is empty")