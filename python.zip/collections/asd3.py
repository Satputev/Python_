collage_data={1101:"BJA",1421:"AJ",7712:"NIM"}

# ccode=int(input("Enter collage code:"))
# cname=input("Enter collage name:").upper()
# print(collage_data)
# collage_data[ccode]=cname
# print(collage_data)

# Enter collage code:2222
# Enter collage name:coep
# {1101: 'BJA', 1421: 'AJ', 7712: 'NIM'}
# {1101: 'BJA', 1421: 'AJ', 7712: 'NIM', 2222: 'COEP'}

# Enter collage code:1421
# Enter collage name:IISC
# {1101: 'BJA', 1421: 'AJ', 7712: 'NIM'}
# {1101: 'BJA', 1421: 'IISC', 7712: 'NIM'}

print("--------------------")

cname=input("Enter collage name:").upper()

for cno,cnam in collage_data.items():
    if cname in cnam:
        print("Collage no:",cno)
        break
    else:
        continue
else:
    print("Collage not Available")
# Enter collage name:abc
# Collage not Available

# Enter collage name:aj
# Collage no: 1421

print("----------------------")

#Display total no of collages

print("Total no of collages:",len(collage_data))#Total no of collages: 3
