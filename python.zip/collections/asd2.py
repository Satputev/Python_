collage={468:"CSE",572:"ECE",621:"EEE",482:"CIVIL"}

#Add one dept
collage[648]="IT"
print(collage)

print("------------------------")
#display all the info in table format

print("CODE","\t","BRANCH")
print("----","\t","-----")
for x,y in collage.items():
    print(y,"\t",x)

# CODE 	 BRANCH
# ---- 	 -----
# CSE 	 468
# ECE 	 572
# EEE 	 621
# CIVIL 	 482
# IT 	 648

print("---------------------")
deptNo=int(input("Enter dept no:"))

if deptNo in collage:
    print("Department Name:",collage[deptNo])
else:
    print("Dept is not Available..")

# Enter dept name:468
# Department Name: CSE

# Enter dept name:123
# Dept is not Available..

print("------------------")

dept=input("Enter Dept name:").upper()

for dno,deptn in collage.items():
    if dept in deptn:
        print("Dept No:",dno)
        break
    else:
        continue
else:
    print("Dept not Availble..")

# Enter dept no:648
# Department Name: IT

# Enter Dept name:cse
# Dept No: 468