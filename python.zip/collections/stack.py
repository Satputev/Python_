#stack implementation

browsing_session=[]

#adding element to stack
browsing_session.append(1)
browsing_session.append(2)
browsing_session.append(3)


print(browsing_session)#[1, 2, 3]

#removing last element from stack
if browsing_session:
    last = browsing_session.pop()
    print(last)  # 3
else:
    print("stack is empty")


print(browsing_session)#[1, 2]

if  browsing_session:
    print("element on top of stack:", browsing_session[-1])  # element on top of stack: 2

#checking stack is empty or not


