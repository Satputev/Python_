d1={"name":"Ravi","Subjects":[{"Python":["Naveen","Nagoor Babu","Satish Gupta"]},{"Django":["Naveen"]}]}
# for x in d1:
#     print(x)#name
#             #subjects
#
# for x,y in d1.items():
#     print(x,"==>",y)

for x,y in d1.items():
    if x=='Subjects':
        for v in y:
            for a,b in v.items():
                for m in b:
                    print(m)


d2=[
	{
		"color": "red",
		"value": "#f00"
	},
	{
		"color": "green",
		"value": "#0f0"
	},
	{
		"color": "blue",
		"value": "#00f"
	},
	{
		"color": "cyan",
		"value": "#0ff"
	},
	{
		"color": "magenta",
		"value": "#f0f"
	},
	{
		"color": "yellow",
		"value": "#ff0"
	},
	{
		"color": "black",
		"value": "#000"
	}
]

for x in d2:
	for a,b in x.items():
		if a=='color':
			print(b,"=>",end=" ")
			continue
		else:
			print(b)
			continue





