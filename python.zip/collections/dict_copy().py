
#method 2
#copy()  ------->It returns the shallow copy of dictionary

dictEx1={"idno":101,"name":"Ravi","salary":185000}
dict2={"Ins_name":"sathyaTech"}
#dictCpy1=dictEx1.copy()+dict2.copy() #TypeError: unsupported operand type(s) for +: 'dict' and 'dict'
dictCpy=dictEx1.copy()
print(dictCpy)#{'idno': 101, 'name': 'Ravi', 'salary': 185000}

