s_data={101:["Ravi",98,65,75],
        102:["Kumar",68,45,76],
        103:["Laxmi",91,98,100]}
print("SNO","\t","sname","\t","s1","\t","s2","\t","s3")

for x,y in s_data.items():
    print(x,end="\t\t")
    for z in y:
        print(z,end="\t\t")
    print()

# SNO 	 sname 	 s1 	 s2 	 s3
# 101		Ravi		98		65		75
# 102		Kumar		68		45		76
# 103		Laxmi		91		98		100

print("-----------------------")

sno=int(input("Enter student no:"))

if sno in s_data:
    print("S1","S2","S3")
    print(s_data[sno][1],s_data[sno][2],s_data[sno][3])
else:
    print("Student not available..")

# Enter student no:111
# Student not available..

# Enter student no:102
# S1 S2 S3
# 68 45 76
