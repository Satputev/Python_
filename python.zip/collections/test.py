# a=[['']]*3
# a[0][0]=1
# print(a)#[[1], [1], [1]]
#
# print("---------------------")
#
# print(round(0.5)-(round(-0.5)))#0
#
# print(round(-0.5))#0
#
#
# a=['10','20']
# print(','.join(a))#10,20


# x={}
#
# x[0]=10
# print(x)#{0: 10}
l1=[10,20,30,40]
for x in enumerate (l1):
    print(x)#(0, 10)
    print(x[0])


