#dict example of 1 employee details

emp={"idno":101,"name":"Ravi","salary":185000}

#print the values from the dictionary we use -> dict_name["key"]

print(emp["idno"])
print(emp["name"])
print(emp["salary"])

#dict example of 3 employees
emps={"101":{"name":"Ravi","salary":185000},
      "102":{"name":"Kumar","salary":175000},
      "103":{"name":"krushna","salary":20000}

}
print(emps["101"]["name"])
print(emps["103"]["salary"])
emps["104"]={"name":"mohan","salaary":16500}
print(emps)
emps["status"]=False
print(emps)

emp={"name":"ravi","name":"kumar","name":"nmk"}
print(emp["name"])#nmk