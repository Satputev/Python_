x=2,5,1
p,q,r=x
print(q)#5
print("-----------------")

x=2,5,1
# p,q,r,s=x
# print(r)#ValueError: not enough values to unpack (expected 4, got 3)

print("-------------------------")

t1=(i*i for i in range (1,5))
print(t1)

print("----------")

t1=(i*i for i in range(1,5))

for i in t1:
    print(i,end="\t")
#1	4	9	16
