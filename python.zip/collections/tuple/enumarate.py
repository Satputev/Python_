s1={"h1":101,"h2":102,"h3":103}

for x,y in enumerate(s1):
    print(x,y)



# 0 h1
# 1 h2
# 2 h3
