#tuple methods

t1=(10,20,30,40,10,30,40)
x=t1.index(30)#index() return the index of given element
print(x)#2

y=t1.count(30)#It return no of occurences of given element
print(y)
print(t1.count(30))#2

t2=0
l1=[10,20,30]
t2=10,
print(t2)
t2=tuple(l1)
print(t2)