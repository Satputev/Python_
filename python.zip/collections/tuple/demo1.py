t1=(10)
print(t1)#10
print(type(t1))#<class 'int'>
print("--------------------------")
t1=(10,20,30,40,50)
print(t1[0])#10
print(t1[-1])#50

#t1[2]=5
#print(t1)#TypeError: 'tuple' object does not support item assignment
print("------------------------")
t4=10,20,30,40
print(t4)#(10, 20, 30, 40)
print(type(t4))#<class 'tuple'>

print("-----------------------")

x,y,z,w=t4
print(x)#10
print(y)#20
print(z)#30
print(w)#40

t2=(10,20,30,[10,20,(10,20,[10,{'name':"ravi",'address':[10,20,30,(5)]}])])
print(t2[3][2][2][1]['address'])
