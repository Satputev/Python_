x=(10)
print(x*3)#30

x=(10,)
print(x*3)#(10, 10, 10)
print("-----------------")
t1=(5,8,2,5,6,9)
print(type(t1))#<class 'tuple'>

print(t1)#(5, 8, 2, 5, 6, 9)

print("----------------------------")
t2=(5,8,2,5,6,9)
print(t2[2])#2

print("---------------------")
t1=(5,8,2,5,6,9)
#t1[2]=12#TypeError: 'tuple' object does not support item assignment

print(t1)

print("---------------------------")

t1=(5,8,2,5,9)
#t1[-2]=12
print(t1)#TypeError: 'tuple' object does not support item assignment
print("------------------------")

t1=(5)
print(type(t1))#<class 'int'>

print("-----------------------------")
t1=(5,)
print(type(t1))#<class 'tuple'>

print("------------------------")

t1=5,
print(type(t1))#<class 'tuple'>
print("--------------------")
t1=2,6,4,5
print(type(t1))#<class 'tuple'>
print("-----------------------")

l1=[5,6,2,4]
t1=tuple(l1)
print(t1)

print("-------------------")

t1=(5,6,2,4)
l1=list(t1)
print(l1)#[5, 6, 2, 4]

print("-------------------------")

a,b,c=10,20,30
print(a,"\t",b,"\t",c)#10 	 20 	 30

print("---------------------------")

a,b=5,7,2,1
print(a,b)#ValueError: too many values to unpack (expected 2)
