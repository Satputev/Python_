for x in set("Sathya"):
    print(x,end=" ")#h t S a y
s1={2,5,6,1}
print(s1)#{1, 2, 5, 6}

print("----------------------")

s1={3,5,6,1,5}
print(s1)#{1, 3, 5, 6}

print("-----------------")

l1=[2,6,1,7,6]
s1=set(l1)
print(l1)#[2, 6, 1, 7, 6]

print(s1)#{1, 2, 6, 7}
print("-----------------")

s1=set(range (5))
print(s1)#{0, 1, 2, 3, 4}
print("-----------------")

# s1={3,7,1,4,9}
# print(s1[3:1:-1])#TypeError: 'set' object is not subscriptable


print("-------------")
s1={3,7,1,4,9}
s1.add(5)
print(s1)#{1, 3, 4, 5, 7, 9}

print("----------------")

s1={3,7,1,4,9}
#s1.add(5,2)#TypeError: add() takes exactly one argument (2 given)

print(s1)
print("-------------------")

s1={3,7,1,4,9}
#s1.update(5,2)#TypeError: 'int' object is not iterable

print(s1)

print("----------------------")

s1={5,9,3,6,4,2}
# for x in s1:
#     if x == 9:
#         s1.remove(x)#RuntimeError: Set changed size during iteration
#
# print(s1)

if 9 in s1:
    s1.remove(9)
print(s1)#{2, 3, 4, 5, 6}

print("-----------------")

s1=set("Ravi Kumar")
print(s1)#{'a', 'r', 'i', 'm', 'R', 'u', ' ', 'v', 'K'}

for x in "Ravi kumar":
    print(x)
print("-------------------")
s1={7,9,3,1,4}
s2={8,2,9,7,6}

s3=s1.symmetric_difference(s2)
print(s3)#{1, 2, 3, 4, 6, 8}

s1={7,8,3,1,4}
s2={8,2,9,7,6}
print(s1-s2)#{1, 3, 4}


sum=0
print([sum+x for x in (s1)])