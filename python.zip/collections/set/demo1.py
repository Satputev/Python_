s1={10,20,40,50,60,70,30}
print(s1)
#print(s1[0])#TypeError: 'set' object is not subscriptable

for x in s1:
    print(x ,end=" ")

#70 40 10 50 20 60 30
print()
s1.add(99) #add() method will add element at begining of set

print(s1)#{99, 70, 40, 10, 50, 20, 60, 30}


print("-----------------------")

# discard()
print(s1.discard(20))#None
print(s1)#{99, 70, 40, 10, 50, 60, 30}
print("-------------------------")

s1.discard(100)#if element is not availble then its dont give error
print(s1)


print("-------------------------")
#remove()
print(s1.remove(10))#None
print(s1)#{99, 70, 40, 50, 60, 30}
s1.remove(100)#if element is not present in set remove function will throw KeyError exception
print(s1)#KeyError: 100


