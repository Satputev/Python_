s1={10,20,30}

# for x in range(s1):
#     print(s1[x])

#TypeError: 'set' object cannot be interpreted as an integer

#print(s1[0:1])#TypeError: 'set' object is not subscriptable

# while True:
#     try:
#         print(s1.pop())
#     except KeyError as k:
#         print(k)#pop from empty set
#         break
s2={10,60,90,80,30,20}
print(s2)
# s2.add(111)
# print(s2)
#
# print(s2.remove(20))
# print(s2.pop())
#
#
# print(s2.discard(80))
# print(s2)
#
# print(s2.update(111,100))
# print(s2)

s2.clear()
print(s2)#set()

