#creating empty set

s1={}
print(s1)
print(type(s1))#<class 'dict'>

print("----------------")

s2=set()
print(s2)#set()
print(type(s2))#<class 'set'>
