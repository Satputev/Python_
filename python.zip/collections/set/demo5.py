s1={10,20,30,40}
s2={20,30,60,80}
s3=s1.intersection(s2)
print(s1)#{40, 10, 20, 30}
print(s2)#{80, 20, 30, 60}
print(s3)#{20, 30}

print(s1 & s2)#{20, 30}
print(s1.union(s2))#{40, 10, 80, 20, 60, 30}

print(s1 | s2)#{40, 10, 80, 20, 60, 30}

print(s1.difference(s2))#{40, 10}
print(s1-s2)#{40, 10}

print(s1.symmetric_difference(s2))#other than common element from both set
#{40, 10, 80, 60}

for x in s1:
    print(x)


