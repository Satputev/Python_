l1=[7,22,31,45,101]
psum=0

for x in l1:
    for y in range(2,len(l1)):
        if(x%y==0):
            break
        else:
            if(y==len(l1)-1):
                psum+=x
                break
            continue

print(psum)
