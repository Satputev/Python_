# + operator and extend() method in list

l1=[10,20,30]
l2=[33,22,11]
print(l1+l2)#[10, 20, 30, 33, 22, 11]

l1.extend(l2)

print(l1)##[10, 20, 30, 33, 22, 11]
print(l2)#[33, 22, 11]

