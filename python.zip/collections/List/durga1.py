#reading list dynamically

#l1=eval(input("Enter the list elements:"))
#print(l1)

#list with list() function

l2=list(range(1,10,2))
print(l2)#[1, 3, 5, 7, 9]
print(type(l2))#<class 'list'>

#with split function

s="Learning python is very very easy!!!"
l=s.split()
print(l)#['Learning', 'python', 'is', 'very', 'very', 'easy!!!']

print(type(l))

n=[1,2,3,4,5,6,7,8,9]
print(n[4::2])#here end is not specied so it will iterate upto end of the list  [5, 7, 9]

