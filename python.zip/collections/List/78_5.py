t_data=[]
for st in range(2):
    s=[]
    print("Enter the ",st+1 ," student marks:")
    for sub in range(3):
        mrk=int(input("Enter Marks:"))
        s.append(mrk)
    t_data.append(s)
print("             S1     S2     S3    Total   Avg")
print("             ---    ---    ---   ------  ----")
print("Student-1","  ",t_data[0][0],"   ",t_data[0][1],"   ",t_data[0][2],"   ",sum(t_data[0]),"   ",int(sum(t_data[0])/len(t_data[0])))
print("Student-2","  ",t_data[1][0],"   ",t_data[1][1],"   ",t_data[1][2],"  ",sum(t_data[1]),"   ",int(sum(t_data[1])/len(t_data[1])))
