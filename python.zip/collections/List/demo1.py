#homogeneous data

marks=[45,20,60,99,50,2]

#list modification

print(marks)#[45, 20, 60, 99, 50, 2]
marks[3]=10
print(marks)#[45, 20, 60, 10, 50, 2]


print("First marks=",marks[0])#First marks= 45

print("Last marks=",marks[-1])#Last marks= 2



#Operations using built in functions
print("Total subject=",len(marks))#Total subject= 6
print("Total marks=",sum(marks))#Total marks= 187
print("max marks=",max(marks))#max marks= 60
print("min marks=",min(marks))#min marks= 2
print("Average Marks=",sum(marks)/len(marks))#Average Marks= 31.166666666666668


#heterogeneous data

stu_info=[101,"Ravi",85.2,582,True]
print("Idno=",stu_info[0])
print("name=",stu_info[1])
print("percentage=",stu_info[2])
print("Total Marks=",stu_info[-2])
print("Status=",stu_info[-1])

