#The "+" operator will concatenate 2 lists and return new list

first_year_marks=[45,95,62]
second_year_marks=[95,15,66]

all_marks=first_year_marks+second_year_marks
print(all_marks)#[45, 95, 62, 95, 15, 66]



#The "*" operator will multiply the list with number and return new list

l1=[10,20,30]
l2=l1*3
print(l1)#[10, 20, 30]
print(l2)#[10, 20, 30, 10, 20, 30, 10, 20, 30]

print("---------------------------------------------------")
#example on slice(:) operator

no=[10,20,30,40,50,60,70,80,90,100]

#positive index(if step +ve do end-1)

print(no[0])#10
print(no[0:5])#[10, 20, 30, 40, 50]
print(no[0:9:2])#[10, 30, 50, 70, 90]
print(no[0:10:3])#[10, 40, 70, 100]
print(no[5:9])#[60, 70, 80, 90]

#negative index(if step -ve do end+1)
print(no[-1])#100
print( no[::-1])#print the list in reverse
print(no[-1:-7:-1])#[100, 90, 80, 70, 60, 50]
print(no[-1:0:-2])#[100, 80, 60, 40, 20]
print(no[-1:1:-2])#[100, 80, 60, 40]
print(no[-1:-11:-1])#print the list in reverse order

