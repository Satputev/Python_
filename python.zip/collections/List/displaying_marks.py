#read 1 student marks and display it
marks=[]
nos=int(input("How many sub you have:"))
for x in range(nos):
    print("enter the ",x+1," Subject marks",end="")
    sub=int(input(":"))
    marks.append(sub)
print("\n\n\n")
for x in range(nos):
    print("S",x+1,end="  ")
print()
for x in range(nos):
    print("---",end="  ")
print()
for x in marks:
    print(x,end="   ")
