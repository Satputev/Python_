#removing duplicate elements from the list

l1=[10,20,30,40,10,20,50,40,20,60,40,50]
wod=[]

for x in l1:
    if x not in wod:
        wod.append(x)
print(wod)