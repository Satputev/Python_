#Intersection of two list

l1=[10,20,30,50,90]
l2=[30,50,88,42,20,223,10]

l3=[]

for x in l1:
    if x in l2:
        l3.append(x)

print(l3)