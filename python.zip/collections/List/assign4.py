l1=[10,20,30,40,50]
l2=[30,40,50,80,90]
l3=[]

for x in l1:
    for y in l2:
        if x==y:
            l3.append(x)

print(l3)