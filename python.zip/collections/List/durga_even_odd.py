#print even numbers in list
n=[0,1,2,3,45,6,7,8,9,10]
print("Even numbers",end="  :")

for n1 in n:
    if(n1%2==0):
        print(n1,end=" ")

#print odd numbers in the list
print()
print("oddNumbers",end="  :")
for n1 in n:

    if(n1%2 !=0):
        print(n1,end=" ")