#using in operator

def has23(ls):
    if len(ls)==2:
        if ((2 in ls) or (3 in ls)):
            return True
        else:
            return False
    else:
        return "only 2 length arry is given in question"

lst=eval(input("enter the arry :"))
print(has23(lst))
print("--------------------------------")
#without using in operator

def has2_3(ls):
    if(len(ls)==2):
        for x in range(len(ls)):
            if (ls[x] == 2 or ls[x] == 3):
                return True
            else:
                return False
    else:
        return "only two length arr is allowes"
print(has2_3(lst))

