l1=[1,2,3]
l2=[5,11,9]
l3=[7,0,0]

def reverse3(li):
    lr = []
    if(len(li)==3):
        lr.append(li[-1])
        lr.append(li[-2])
        lr.append(li[-3])
    print(lr)

reverse3(l1)#[3, 2, 1]

reverse3(l2)#[9, 11, 5]
reverse3(l3)#[0, 0, 7]



