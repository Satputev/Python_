name=input("Enter player name:")
score=[]
for x in range(5):
    print("Match -",x+1," Score",end="")
    idm=int(input(":"))
    score.append(idm)

print("Player name:",name)
print("Average score=",sum(score)/len(score))