#using loop in list
from functools import reduce

marks=[10,20,5,10,20,5]

for x in marks:
    print(x,end=" ")#10 20 5 10 20 5
print("\n-----------------------------------------")

#find the sum of all numbers

s=0
for x in marks:
    s=s+x
print("Total Marks:",s)#Total Marks: 70
print("Total marks=",sum(marks))

#using lambda
print("using lambda sum=",reduce(lambda x,y:x+y ,marks))


print("-------------------------------------")

#find the lowest marks in the list
low=marks[0]
for x in marks:
    if x <=low:
        low=x
print("Lowest marks is:",low)#Lowest marks is: 5
print("Lowest mrks is:",min(marks))#Lowest marks is: 5

#using lambda

from functools import reduce

print(reduce(lambda x,y:x if x<=y else y ,marks))

print("-------------------------------------")

#find highest marks
high_mark=marks[0]

for x in marks:
    if x>=high_mark:
        high_mark=x
print("Highest marks is:",high_mark)#Highest marks is: 20
print("Highest marks is :",max(marks))#Highest marks is: 20

#using lambda

print("using lambda highest marks :",reduce(lambda x,y:x if x>=y else y ,marks))

print(("-----------------------------"))

#average
sm=0
count=0
for x in marks:
    sm+=x
    count=count+1
print("Average is:",sm/count)
print("Average is:",sum(marks)/len(marks))
