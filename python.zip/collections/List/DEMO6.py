#Removing duplicate elements from the list

l1=[10,20,30,40,10,20,50]
l2=[]
for x in l1:
    if x not in l2:
        l2.append(x)

print(l1)
l1=l2
print(l1)

print("---------------------------------------")

l1=[5,6,7,8,9,5,4,8,5,1,6,7,9]
print(l1)#[5, 6, 7, 8, 9, 5, 4, 8, 5, 1, 6, 7, 9]

s1=set(l1)
print(s1)#{1, 4, 5, 6, 7, 8, 9}
l1=list(s1)
print(l1)#[1, 4, 5, 6, 7, 8, 9]

print("---------------------------------------")

s1="aaabbcccddeefffggggghhhhh"
print(s1)
s2=""

for x in s1:
    if x not in s2:
        s2=s2+x
print(s1)#aaabbcccddeefffggggghhhhh

s1=s2
print(s1)#abcdefgh
