#write the program to read three student marks,then calculate their total


total_student=[]
for student in range(3):
    print("enter the marks of:", student + 1)
    s=[]
    for marks in range(3):
        marks=int(input("Enter the marks:"))
        s.append(marks)
    total_student.append(s)

print("Total marks of s1=",sum(total_student[0])," Average is:",sum(total_student[0])/len(total_student[0]))
print("Total marks of s2=",sum(total_student[1]),"Average is:",sum(total_student[1])/len(total_student[1]))
print("Total marks of s3=",sum(total_student[2]),"Average is:",sum(total_student[2])/len(total_student[2]))
