#storing nested list dynamically
l1=[]

ol=int(input("Enter the no of element in outer list:"))
for x in range(ol):
    nl=int(input("How many element you want to store in each nested list:"))
    l2=[]
    for y in range(nl):
        ne=int(input("enter the element: "))
        l2.append(ne)
    l1.append(l2)
print(l1)