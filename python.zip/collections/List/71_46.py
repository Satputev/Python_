#modifying element into 3x2 matrix

lst=[[10,20],[1,2],[50,100]]
row=int(input("Enter the rowno:"))
col=int(input("enter the colno:"))
ele=int(input("enter the element:"))
print("before modifying...",lst)
if(row<3 and col<2):
    lst[row][col] = ele
    print("after modifying", lst)
else:
    print("its 3x2 enter valid position")
