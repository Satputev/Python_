#nested list
#ssalary(developers(5),designer(1),tester(2),mamnager(1),officeboy(2),hr(1)
salary=[[30000,15000,18500,10000],25000,[15000,20000],50000,[10000,10000],50000]

#find total no of developers

print("Total no of developers =",len(salary[0]))#4
print("Total salary of developers=",sum(salary[0]))#73500

print("Total no of testers:",len(salary[2]))#2


#find the total company salary
def cal_sal(all_sal):
    salary=0
    for x in all_sal:
        if isinstance(x,list):
            salary=salary+sum(x)
        else:
            salary=salary+x
    return  salary

print("Total salary is",cal_sal(salary))#Total salary is 253500
