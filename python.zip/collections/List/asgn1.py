l1=5
l2=[1,2,3]
l3=3
print(l1*l3)

a=20
m2=[10,[20,30]]
m1=[10,22,322,6868,50,60]
print(min(m1))
print(max(m1))
#sorting list element in acending order
m1.sort()
print(m1)

#sorting list element in decending order
m1.sort(reverse=True)
print(m1)#[6868, 322, 60, 50, 22, 10]

m1.remove(6868)
print(m1)

print(m1.pop(0))
print(m1)


print(m1)
m=m1.copy()
print(m)

