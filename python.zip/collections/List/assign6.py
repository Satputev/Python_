#clone copy the list

l1=[10,20,30]
l2=l1[:]#clone copy
print(l2)
print(id(l1),id(l2))