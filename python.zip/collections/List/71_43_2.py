a=()
# print(a)#()
# print(type(a))#<class 'tuple'>

m1=(10,20,30,40)
# m1[0]=20
# print(m1)#TypeError: 'tuple' object does not support item assignment

#accessing tuple elements

# for x in m1:
#     print(x,end=" ")#10 20 30 40


#packing

t1=10,20,30,40
print(t1)#(10, 20, 30, 40)
print(type(t1))#<class 'tuple'>

print("-----------------------")

#unpacking

a,b,c,d=t1
print(a,b,c,d)#10 20 30 40



