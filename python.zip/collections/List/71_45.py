#adding element into 3x2 matrix

lst=[[10,20],[30,40],[50,60]]
rown=int(input("Enter row no "))
coln=int(input("Enter the column no:"))
ele=int(input("Enter the element: "))
if(rown<3 and coln<2):
    lst[rown].insert(coln, ele)
else:
    print("Its 3x2 matrix enter valid row and column no(index start from 0)")

print(lst)