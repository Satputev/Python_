l1=[10,20,30,50,40,60,20]
l=[2,3,1,5,4,2]

def same_first_last(li):
    if(len(li)>=1):
        if(li[0]==li[-1]):
            return True
        else:
            return False
print(same_first_last(l1))
print(same_first_last(l))