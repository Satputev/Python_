#traversing list element

n=[2,3,4,5,6,7,8,9,10,11]
i=0
#using while loop
while i<len(n):
    print(n[i],end="_")#2_3_4_5_6_7_8_9_10_11_
    i=i+1
print()
#using for loop
for x in range(len(n)):
    print(n[x],end=" ")#2 3 4 5 6 7 8 9 10 11

#using for loop
print()
for n1 in n:
    print(n1)
