#3x3
lst=[[10,20,30],[5,3,2],[1,2,3]]
for x in range(len(lst)):
    for y in range(len(lst[x])):
        print(lst[x][y],end=" ")
    print()

#4x3
ls=[[1,2,3,2],[1,2,3,4],[4,5,6,5]]
for i in range(len(ls)):
    for j in range(len(ls[i])):
        print(ls[i][j],end=" ")
    print()

#3x2
list1=[[10,20],[30,40],[50,60]]
for r in range(len(list1)):
    for c in range(len(list1[r])):
        print(list1[r][c],end=" ")
    print()