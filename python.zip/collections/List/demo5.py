#calculate the total sum of salary

#"not working" means employee is absent
#"False" means employee is working on site

salary=[[30000,15000,"not working",10000],25000.25,[15000,20000.50],False,[10000,10000],50000]

def cal_sal(all_salaries):
    total_salary=0
    for x in all_salaries:
        if isinstance(x,list):
            t=0
            for y in x:
                if isinstance(y,int) or isinstance(y,float):
                    t=t+y
            total_salary=total_salary+t
        else:
            total_salary=total_salary+x
    return total_salary

print("total salary is =",cal_sal(salary))#185000.75