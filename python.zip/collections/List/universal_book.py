bk_list=["The Secret","Rich Dad poor dad","How to Win Friends","Think & Grow rich","You can Win "]

book=input("Which boook you want??")
if book in bk_list:
    print(book," book is available..")
else:
    print("book is not availabe..")

# Which boook you want??The Secret
# book is available..

# Which boook you want??jobs
# book is not availabe..