#max_end
lste=eval(input("enter the list elements:"))

max12 = lste[0]
def max_end(lst):
    ls=[]
    global max12
    for x in range(len(lst)):
        if lst[x]>max12:
            max12=lst[x]
    for x in range(len(lst)):
        ls.append(max12)
    return ls
res=max_end(lste)
print(res)

print("---------------------------")
x=[]
for y in range(len(lste)):
    x.append(max(lste))
print(x)