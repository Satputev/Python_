a1=[1,2,3]
a2=[11,5,9]
a3=[2,11,3]
max=[]
def max_end3(l):
    max = l[0]
    if(len(l)==3):
        for x in l:
            if x>=max:
                max=x
        for x in range(3):
            l[x]=max
    print(l)

max_end3(a1)#[3, 3, 3]
max_end3(a2)#[11, 11, 11]
max_end3(a3)#[11, 11, 11]