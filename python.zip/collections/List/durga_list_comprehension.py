#list comprehensions

s=[x*x for x in range(1,11)]
print(s)
print("-----------------------")

v=[2**x for x in range(1,6)]
print(v)

cube=[x*x*x for x in range(1,11)]
print(cube)

print("------------------------------")

#using condition

m=[x for x in s if x%2==0]
print(m)