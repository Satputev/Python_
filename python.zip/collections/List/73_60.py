#middle max

l1=eval(input("enter the 1st list: "))
l2=eval(input("enter the 2nd list: "))
def middle_way(ls1,ls2):
    mid_list=[]
    mid_list.append(ls1[int(len(ls1)/2)])
    mid_list.append(ls2[int(len(ls2)/2)])
    return mid_list

res_lst=middle_way(l1,l2)
print(res_lst)
