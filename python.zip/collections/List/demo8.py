arr=[10,20,30,40,5,6,5]

def first_last6(ar):
    if(len(ar)>=1):
        if(ar[0]==6 or arr[-1]==6):
            return True
        else:
            return False

print(first_last6(arr))