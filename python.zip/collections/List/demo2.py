#Example on nested list
# price of Mon,tue,wed
#each day tomato,potato,bringle
price=[[50,25,40],[40,25,42],[60,10,25]]
print("Monday veg price:",price[0])#Monday veg price: [50, 25, 40]
print("Tuesday veg price:",price[1])#Tuesday veg price: [40, 25, 42]
print("Wednesday veg price",price[2])#Wednesday veg price [60, 10, 25]

print("Tomato price on Monday:",price[0][0])#Tomato price on Monday: 50
print("Bringle price on wednesday:",price[2][2])#Bringle price on wednesday: 25

