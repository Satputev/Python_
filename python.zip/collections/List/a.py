no=input("enter the no:").split()
map(int,no)