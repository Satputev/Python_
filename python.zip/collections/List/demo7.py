l1=[1,2,3]
l2=[7,3,5,6]
def common_end(arg1,arg2):
    if(len(arg1)>=0 and len(arg2)>=0):
        if (arg1[0] == arg2[0] or arg1[-1] == arg2[-1]):
            return True
        else:
            return False


print(common_end(l1,l2))