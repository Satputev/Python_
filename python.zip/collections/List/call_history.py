#wap to read cc employee day wise call history for n days and find the average call history
call_log=[]
days=int(input("Enter how many days:"))
for x in range(days):
    print("Enter the Day -",x+1,"Calls", end="")
    call_history=int(input(":"))
    call_log.append(call_history)

print("Average call Rate is:",int(sum(call_log)/len(call_log)))