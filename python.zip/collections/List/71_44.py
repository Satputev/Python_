#removing element from 3x2 matrix

lst=[[10,20],[30,40],[50,60]]
print(lst)
ele=int(input("which element you want to remove:"))
for x in range(len(lst)):
    if ele in lst[x] :
            lst[x].remove(ele)


print(lst)