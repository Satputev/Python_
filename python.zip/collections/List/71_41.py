#storing list element dynamically

l=int(input("enter the length"))
l1=[]
for x in range(l):
    el=int(input("Enter the no:"))
    l1.append(el)
print(l1)