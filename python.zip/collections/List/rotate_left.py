l1=[10,20,30]

l22=[5,11,9]
l3=[7,0,0]

#execute on at a time
def rotate_left3(l1):
    l2 = []
    if(len(l1)==3):
        for x in l1:
           if(x!=l1[0]):
               l2.append(x)

        l2.append(l1[0])
    print(l2)

rotate_left3(l1)
rotate_left3(l22)
rotate_left3(l3)

