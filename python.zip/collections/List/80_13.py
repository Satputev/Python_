l1=eval(input("Enter the 1st list element:"))
l2=eval(input("Enter the second list Element:"))
common=[]
for x in l1:
    if x in l2:
        common.append(x)
print(common)