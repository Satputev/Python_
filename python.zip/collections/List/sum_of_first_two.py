def sum2(l1):
    if(len(l1)>=2):
        for x in l1:
            if(len(l1)==2):

