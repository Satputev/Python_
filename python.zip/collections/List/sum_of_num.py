arr1=[1,2,3]
arr2=[5,11,2]
arr3=[7,0,0]

##without using predefined function

def sum3(arr):
    sum = 0
    if(len(arr)==3):
        for x in arr:
            sum=sum+x
    return sum

print(sum3(arr1))
print(sum3(arr2))
print(sum3(arr3))

print("----------------------------------")

#using predefined function
print(sum(arr1))
print(sum(arr2))
print(sum(arr3))
