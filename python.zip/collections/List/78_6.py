#WAP to calculate the sum of even numbers and sum of odd nos in given list

lst=[10,5,12,17,14,3]
e_sum=0
o_sum=0
for x in lst:
    if(x%2==0):
        e_sum+=x
    else:
        o_sum+=x

print("Even sum=",e_sum)
print("Odd sum=",o_sum)