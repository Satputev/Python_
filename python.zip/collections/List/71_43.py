#storing 2x3 matrix dynamically in list
l1 = []
for x in range(2):
    l2=[]
    for y in range(3):
        ele=input("enter the element: ")
        l2.append(int(ele))
    l1.append(l2)

print(l1)



