l1=list(range(5))
#print(l1)

l2=list(range(1,20,4))
#print(l2)

n3=[0]*5
#print(n3)
#print(len(n3))

n=[4,8,12,16,20]
#n[3]=40
#print(n)

#print(n[-3])
#print(n3+n)

l3=[4,9,12,34,22,10]
l4=l3[1:3]
print(l4)