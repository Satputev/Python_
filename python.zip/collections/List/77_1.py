#modify 5 with 12
l1=[5,8,2,1,9,7,2]
l1[l1.index(5)]=12
print(l1)#[12, 8, 2, 1, 9, 7, 2]

#checking value is available or not
#val=int(input("Enter the value:"))
#print(val in l1)

#removing 1 from the list
#l1.remove(1)
#print(l1)

# print(l1)
# print(l1[0:])
# print(l1[:])
# print(l1[-(len(l1)):])


#by using loop

for x in l1:
    print(x)