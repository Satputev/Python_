#removing duplicate elements in the list

l1=[10,20,30,10,50,52,20,10,30,50,60,80,10]
l2=[]

for x in l1:
    if x not in l2:
        l2.append(x)
print(l2)