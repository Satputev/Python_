#reverse the list

l1=eval(input("Enter the list:"))
def reverse(lst):
    rlist=[]
    for x in range(-1,-len(lst)-1,-1):
        rlist.append(lst[x])
    return rlist

reverse_list=reverse(l1)
print(l1)
print(reverse_list)
