#display the ammount of gross pay
h_rate=float(input("Enter the hourly pay rate:"))
hours=[]
for x in range(4):
    print("Enter the no of hours worked by employee -",x+1,end="")
    hr=float(input(":"))
    hours.append(hr)

for x in range(4):
    print("Gross pay for employee -",x+1,":",h_rate*hours[x])