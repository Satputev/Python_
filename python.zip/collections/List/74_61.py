lst=eval(input("Enter the lst:"))


def make_ends(ls):
    op_lst = []
    if (len(lst) == 1):
        op_lst.append(lst[0])
        return op_lst
    elif len(lst) > 1:
        op_lst.append(lst[0])
        op_lst.append(lst[-1])
        return op_lst
    else:
        return "invlid length array"

res_list=make_ends(lst)
print(res_list)






