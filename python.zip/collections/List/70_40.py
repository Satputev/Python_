#storing list inside list
#store the li3 in li2
#stor li2 in 3rd position and li1 in ssecond last into l1
l1=[10,20,30,40,50]
li1=[50,60]
li2=[70,80]
li3=[1,20,3,4]
print("before inserted",li2)
li2.insert(1,li3)
print("after inserted li2",li2)

print("before inserted l1",l1)

l1.insert(2,li2)
print("after inserted li2 in l1")

print(l1)
print("before inserted")

l1.insert(-2,li1)
print(l1)
print("after inserted li1 in l1")
