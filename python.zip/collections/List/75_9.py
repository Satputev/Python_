# l1=[4,9,12,34,22,10]
# l2=l1[1:]
# print(l2)

# l1=[4,9,12,34,22,10]
# l2=l1[:1]
# print(l2)

# l1=[4,9,12,34,22,10]
# l2=l1[:]
# print(l2)#[4, 9, 12, 34, 22, 10]
#
# l1=[4,9,12,34,22,10]
# l2=l1[-2:]
# print(l2)#[22, 10]

# names=[]
# names[0]="sathya Tech"
# print(names)#IndexError: list assignment index out of range

# names=[]
# names.append("Ravi")
# print(names)#['Ravi']

# l1=[]
# l1.append("s")
# l1.append("v")
# l1.append("r")
# print(l1)#['s', 'v', 'r']

# l1=[10,20,30,10,50]
# l1.remove(10)
# print(l1)#[20, 30, 10, 50]

# l1=[5,9,2,4]
# l1.sort()
# print(l1)#[2, 4, 5, 9]

# names=[5,'s',2,'v',3,'r']
# names.sort()
# print(names)#TypeError: '<' not supported between instances of 'str' and 'int'

# l1=[5,7,3,6]
# l2=l1
# l1[2]=l2
# print(l1)#[5, 7, [...], 6]
# print(l2)#[5, 7, [...], 6]

# l1=[[5,10],[15,20]]
# print(l1[0][2])

# l1=[5,10,15,20]
# l2=[5,10,15,20]
# if(l1==l2):
#     print("hai")
# else:
#     print("bye")

#hai
#
# l1=[[5,10],[15,20]]
# print(l1[1][-1])#20

# l1=[i for i in range(1,5)]
# print(l1)#[1, 2, 3, 4]

# l1=[i*i for i in range(1,5)]
# print(l1)#[1, 4, 9, 16]

# n=[5,8,3,6,1,4]
# l1=[k for k in n if k%2==0]
# print(l1)#[8, 6, 4]

# names=["Sangani","Ravi","kumar"]
# l1=[n[0] for n in names]
# print(l1)#['S', 'R', 'k']

# n="123Ravi45"
# l1=[k for k in n if k.isdigit()]
# print(l1)#['1', '2', '3', '4', '5']

# l1=[p for p in range(1,10) if p%2==0]
# print(l1)
#
# l1=[p for p in range(1,5) for q in range(1,p+1)]
# print(l1)#[1, 2, 2, 3, 3, 3, 4, 4, 4, 4]