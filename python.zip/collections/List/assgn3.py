#append and extend

l1=[10,20,30,40]
l2=[50,60,70,80,90]

l1.append(l2)
print(l1)
print(l2)
print("--------------------------")
l1.append(99)
print(l1)

print("---------------------------------")
l3=[11,22,33,44]
l2.extend(l3)
print(l2)
print(l3)
print("-----------------------------")
#l2.extend(6) #TypeError: 'int' object is not iterable
l1=[10,20,30,40]
l2=[50,60,10,20,70,80,90]
print(l2)
print(list(set(l1)&set(l2)))