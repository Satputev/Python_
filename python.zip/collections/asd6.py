d1={"Education":{1212:["Ravi",500000,4,8.6],
                 2213:["Khaja",300000,3,8.6]},
    "Home":{6653:["John",250000,12,11.2],
            6642:["Amar",150000,7,11.2]}}

#display all the data :Loan Type:Education

print("Lid","     CName","Ammount","Duration","ROI")

for x,y in d1.items():
    if x=='Education':
        for m,n in y.items():
            print(m,"\t",n[0]," ",n[1],"  ",n[2],"   ",n[3])



# Lid      CName Ammount Duration ROI
# 1212 	 Ravi   500000    4     8.6
# 2213 	 Khaja   300000    3     8.6
print("-------------------------")

lt=input("Enter loan type:")

if lt in d1:
    for x,y in d1.items():
        if x==lt:
            for m,n in y.items():
                print(m," ",n[0]," ",n[1]," ",n[2]," ",n[3])
else:
    print("Invalid loan type")

# Enter loan type:car
# Invalid loan type

# Enter loan type:Home
# 6653   John   250000   12   11.2
# 6642   Amar   150000   7   11.2