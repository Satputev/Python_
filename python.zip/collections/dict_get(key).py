#method 3

#get(key)  ------>retuns the value of key if does not exist return None

emps={"101":{"name":"Ravi","salary":185000},
      "102":{"name":"Kumar","salary":175000},
      "103":{"name":"krushna","salary":20000}

}
print(emps.get("101"))#{'name': 'Ravi', 'salary': 185000}
print(emps.get("name"))#None

print(emps.get("101").get("name"))#Ravi
print(emps.get("103").get("salary"))#20000

print(emps.get("102").__len__())#2
print(emps.__len__())#3





