emps={"101":{"name":"Ravi","salary":185000},
      "102":{"name":"Kumar","salary":175000},
      "103":{"name":"krushna","salary":20000}

}

emp={"name":"Naveen Kumar","Ins":"SathyaTech"}

print("--------------------------------------------------------------------------------------")
#method 4
#items()  ----->It returns list of all items (key:value) each pair represents a one tuple
items=emps.items()
print(items)#dict_items([('101', {'name': 'Ravi', 'salary': 185000}), ('102', {'name': 'Kumar', 'salary': 175000}), ('103', {'name': 'krushna', 'salary': 20000})])

print("------------------------------------------------------------------------------------------")
#method 5

#keys()  ------>It returns new view of keys

keys=emps.keys()
print(keys)#dict_keys(['101', '102', '103'])

print("----------------------------------------------------------------------------")
#method 6

#values()    ------>return the new view of dict values

values=emps.values()
print(values)#dict_values([{'name': 'Ravi', 'salary': 185000}, {'name': 'Kumar', 'salary': 175000}, {'name': 'krushna', 'salary': 20000}])




#method 7

#pop(key)  ----->Remove item with key and return its value if key is not found arises error
#if item is not longer needed but we need its value only then we use pop(key) method


emps={"101":{"name":"Ravi","salary":185000},
      "102":{"name":"Kumar","salary":175000},
      "103":{"name":"krushna","salary":20000}

}
print(emps.pop("101"))#{'name': 'Ravi', 'salary': 185000}
print(emps)#{'102': {'name': 'Kumar', 'salary': 175000}, '103': {'name': 'krushna', 'salary': 20000}}

print(emps.pop("103").pop("salary"))#20000
print(emps)#{'102': {'name': 'Kumar', 'salary': 175000}}

print("--------------------------------------------------------------------------------------")


#method 8

emps={"101":{"name":"Ravi","salary":185000},
      "102":{"name":"Kumar","salary":175000},
      "103":{"name":"krushna","salary":20000}
}

#popitem    ------->remove the last (key:value) pair from the dict

x=emps.popitem()
print(x)#('103', {'name': 'krushna', 'salary': 20000})

print(emps)#{'101': {'name': 'Ravi', 'salary': 185000}, '102': {'name': 'Kumar', 'salary': 175000}}


print("--------------------------------------------------------------")

#method 9
#setdefault(key) ----->

emps={"101":{"name":"Ravi","salary":185000},
      "102":{"name":"Kumar","salary":175000},
      "103":{"name":"krushna","salary":20000}
}

default_key=emps.setdefault("101")#if key exist returns the value
print(default_key)#{'name': 'Ravi', 'salary': 185000}
print(emps)

default_key=emps.setdefault("Status")#if key is not exist added new "key" with "None" value
print(default_key)#None
print(emps)#{'101': {'name': 'Ravi', 'salary': 185000}, '102': {'name': 'Kumar', 'salary': 175000}, '103': {'name': 'krushna', 'salary': 20000}, 'Status': None}


