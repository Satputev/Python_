emps={101:{"name":"Ravi","salary":185000},
      102:{"name":"Mohan","salary":175000},
      103:{"name":"kumar","salary":163200}}
print(emps)

# method 1

#clear()  ---->this method removes all the items from the dict

emp1={"name":"Ravi","salary":185000,"idno":101}
print(emp1.clear())#None
print(type(emp1.clear()))#<class 'NoneType'>


emp2=emp1.clear()
print(emp1)#{}
print(emp2)#None

