dept={10:["HR","HYD"],
      20:["Python","Bang"],
      30:["java","Hyd"]}

emp={1001:["Ravi",2000.0,10],
     1002:["Vishnu",3000.0,20],
     1003:["Avinash",2500.0,10],
     1004:["Kumar",2300.00,30]}

#displaying all dept info
print("DNO","POS ","  LOC")
for x,y in dept.items():
    print(x,end="\t")
    for pl in y:
        print(pl,end="  \t")
    print()

# DNO POS    LOC
# 10	HR  	HYD
# 20	Python  	Bang
# 30	java  	Hyd

print("---------------------")
#display all employee info
print("EID", "ENAME", "ESAL", "EDPT")

for x,y in emp.items():
    print(x,end=" ")
    for d in y:
        print(d,end="  ")
    print()
# EID ENAME ESAL EDPT
# 1001 Ravi  2000.0  10
# 1002 Vishnu  3000.0  20
# 1003 Avinash  2500.0  10

print("----------------")


eid=int(input("Enter EID:"))

if eid in emp:
    print("Ename","SAL","dname")
    for x in emp[eid]:
        print(x,end="\t")
else:
    print("Employee not exist..")

# Enter EID:1234
# Employee not exist..

# Enter EID:1001
# Ename SAL dname
# Ravi	2000.0	10

print("\n----------------")

#display employee details whose salary between 2000 to 2600
el=[]
for x in emp:
    if emp[x][1]>2000 and emp[x][1]<2600:
        es=x,emp[x][0],emp[x][1],emp[x][2]
        el.append(es)
        continue

if el:
    for x in el:
        print(x)
else:
    print("That salary range employee not exists..")



# (1003, 'Avinash', 2500.0, 10)
# (1004, 'Kumar', 2300.0, 30)

print("------------------------")

empname=input("Enter Emp name:")

c=0
for x,y in emp.items():
    c = c + 1

    if empname in y:

        print("EMPID:"+str(x),"  EMP_NAME:"+empname+"  E_sal:"+str(emp[x][1]))
        break
    else:
       continue
else:
    print("Employee not available")

# Enter Emp name:Vishnu
# EMPID:1002   EMP_NAME:Vishnu  E_sal:3000.0

# Enter Emp name:kcr
# Employee not available