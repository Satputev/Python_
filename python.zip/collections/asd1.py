d1={}
print(type(d1))
print("------------------")

# d1={101:"Ravikumar",102:"Laks",101:"Vishnu",04:"Avinash"}
# print(d1[101])#SyntaxError: leading zeros in decimal integer literals are not permitted; use an 0o prefix for octal integers

print("----------------")
d1=dict()
print(type(d1))#<class 'dict'>

print("---------------------")

d1={101:"Ravikumar",102:"Lakshhmi"}
d1[102]="Sangani"
print(d1[102])#Sangani

print("-----------------------------")

d1={101:"Ravikumar",102:"Lakshmi"}
d1[103]="Lakshmi"
print(d1)#{101: 'Ravikumar', 102: 'Lakshmi', 103: 'Lakshmi'}

print("-----------------------")

d1={101:"Ravikumar",102:"Lakshmi"}

del d1[101]
print(d1)#{102: 'Lakshmi'}

print("---------------------")

# d1={101:"Ravikumar",102:"Lakshmi"}
# del d1["Lakshmi"]
# print(d1)#KeyError: 'Lakshmi'
print("----------------------")

d1={101:"Ravikumar",102:"Vishnu"}
for i in d1:
    print(i,end="\t")
#101 102

print("\n---------------------")

d1={101:"Ravikumar",102:"Vishnu"}

for i in d1:
    print(i,"\t",d1[i])

#101 	 Ravikumar
#102 	 Vishnu
print("-------------------")

d1={101:"Ravikumar",102:"Vishnu"}
for i in d1.keys():
    print(i)#101
            #102

print("-----------------------")

d1={101:"Ravikumar",102:"Vishnu"}
for x in d1.items():
    print(i)#102
            #102

print("-------------------------")

d1={101:"Ravikumar",102:"Vishnu"}
for i in d1.values():
    print(i)#Ravikumar
            #Vishnu
print("---------------------")

d1={101:["Ravi",2000.0]}
for i in d1:
    print(i)#101

print("-------------------")
d1={101:["Ravi",2000.0]}
for i,j in d1.items():
    print(i,"\t",j)#101 	 ['Ravi', 2000.0]

print("-------------------")

d1={101:["Ravi",2000.0]}
for i,j in d1.items():
    print(i,end="\t")
    for k in j:
        print(k,end="\t")
#101	Ravi	2000.0

print("\n----------------------------")

d1={"HR":{101:"Ravi",102:"Lakshmi"}}

for x,y in d1.items():
    print(x)
    for m ,n in y.items():
        print(m,"=>",n)
# HR
# 101 => Ravi
# 102 => Lakshmi

print("--------------------------")

d1={101:["Ravi",2000.0],
    102:["Avinash",5000.0]}
for x,y in d1.items():
    if x==102:
        for m in y:
            print(m)
# Avinash
# 5000.0

print("--------------------------")

d1={"HR":{101:"Ravi",102:"Lakshmi"},
    "Production":{201:"Vishnu",202:"Avinash"}
    }
#was to display HR data

for x,y in d1.items():
    if x=="HR":
        for m,n in y.items():
            print("IDNO:",m,"Name:",n)

# IDNO: 101 Name: Ravi
# IDNO: 102 Name: Lakshmi

print("--------------------------")

d1={"HR":{101:"Ravi",102:"Lakshmi"},
    "Production":{201:"Vishnu",202:"Avinash"}}
#display only Vishnu data

for x,y in d1.items():
    for m,n in y.items():
        if n=="Vishnu":
            print("Name:",n)
            print("Designation:",x)
            print("IDNO:",m)
# Name: Vishnu
# Designation: Production
# IDNO: 201

print("-----------------------------")