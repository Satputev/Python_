#list using for loop

# s1="Satya Tech"
# for x in s1:
#     print(x)
#
# Printing name reverse reverse order

s1="Satya Tech"
for x in range(-1,(-len(s1))-1,-1):
    print(s1[x],end="")#hceT aytaS

print()
#or
s2=""
for x in s1:
    s2=x+s2
print(s2)#hceT aytaS

print()

s3=s1.split()
res=""
for x in s3:
    res=res+x[::-1]+" "
print(res)#aytaS hceT
