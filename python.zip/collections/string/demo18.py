eids=eval(input("Enter the email ids: "))
compony=input("Enter company names: ").lower()
print("Employees in compony: ",compony,": ")
for x in eids:
    y=x.split('@')
    if y[1]==compony:
        print((y[0]).capitalize())


# Enter the email ids: ["ravi@ibm.com","lakshmi@ibm.com","vishnu@tcs.com","avinash@ibm.com"]
# Enter company names: ibm.com
# Employees in compony:  ibm.com :
# Ravi
# Lakshmi
# Avinash
#
