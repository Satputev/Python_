#search and replace meyhod

#change existing string with new string

a='asdfgh'
print(a)#asdfgh

print(a.replace(a,"hello"))#hello


#finding string end with specific sub-string

a='asdfghbnn'
print(a.endswith("asd",5,9))#False

print(a.endswith("nn"))#True