#Example script to display even position characters
s1=input("Enter the string: ")
print(s1[0::2],end=" ")

