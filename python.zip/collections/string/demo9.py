a='sdfsf'
print(a.isprintable())#True
print(a.isspace())#false
print(a.isdigit())#False
print(a.isalnum())#True
print(a.isalpha())
print(a.islower())
print(a.isupper())
print(a.isdecimal())
print(a.istitle())
print(a.isidentifier())
print(a.isnumeric())
a='    '
# print(a.isspace())#True



