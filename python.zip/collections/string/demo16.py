#display all even index positions

s1="Sathya Technology"
print(s1[::2])#Sty ehooy

print("-------------------------")

#was to check given string is palindrome or nor

s1="madam"
#s1='aa'
for x in range(len(s1)):
    if s1[x]==s1[-x-1]:
        continue
    else:
        print("Strig is not palindrome")
        break
else:
    print("String is palindrome")

#String is palindrome
