#checking string contain any symbol or not

s='Hiii Bill Gates & stev jobs is very innovative person.. '

for x in s:
    if (ord(x)<65 or ord(x) >90) and (ord(x)<97 or ord(x)>122) and ord(x) !=32:
        print("String contains:",x,"Symbols..")

        continue
    else:
        continue


#to check wheather string contain only alphabet or not
s1='ab@cd'
for x in s1:
    if (x<'a' or x> 'z') and (x< 'A' or x> 'Z'):
        print("not all chars are alphabet..")
        break
    else:
        continue
else:
    print("All chars are alphabets..")
