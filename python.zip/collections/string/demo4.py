qualification="B.Tech"
# qualification[0]='M'
# print(qualification)#TypeError: 'str' object does not support item assignment

print(qualification[2::])#Tech

print(qualification[100:1222])#no output and no error

