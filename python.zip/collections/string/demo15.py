phno="9898989898"
if(phno.isdigit()):
    print("valid phone number")
else:
    print("Invalid phone number")#valid phone number
print("-------------------------------------")
name="Ravi Kumar"
if name.isalpha():
    print("valid name")
else:
    print("Invalid name")

#Invalid name
print("-------------------------------")
userid="Ravi2#"
if userid.isalnum():
    print("Valid User Id")
else:
    print("Invalid user id")
#Invalid user id
print("-------------------------")
email="RaviKumar@sathya.com"
s1=email.split('@')
print("User name is:",s1[0])#User name is: RaviKumar
print("-----------------------")

s1="Ravi Kumar"
print("\n",s1[1:4])# avi
print("------------------------")

s1="Ravi Kumar"
print("\n",s1[::-1])# ramuK ivaR

print("-----------------")
s1="Sathya Technology"
print(s1)
print(s1[0])#S
print("----------------------")

s1="Sathya Techology"
print(s1[1:10:2])#ahaTc

print("---------------------")

s1="Sathya Technology"
print(s1[1:20:3])#ayThly

print("----------------------")
s1="sathya Technology"
print(s1[6:1:-1])# ayht
print("-----------------")

s2="Python Java in Sathya Technology"
if "Python" in s2:
    print("Python is available")
else:
    print("Python is not available")

#Python is available

print("---------------------")
s1=["Python","Java",".net"]
if "Python" in s1:
    print("Python is available")
else:
    print("Python is not available")
#Python is available

print("-------------------------")
hallticket="112234001"
if hallticket.startswith("1122"):
    print("Starts with your code")

#Starts with your code
