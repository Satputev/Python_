#Example script to check given string is palindrome or not

s1=input("Enter the String: ")

for x in range(len(s1)):
    if (s1[x]==s1[-x-1]):
        continue
    else:
        print("String is not palindrome")
        break
else:
    print("String is palindrome")









