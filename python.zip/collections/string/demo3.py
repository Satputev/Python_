name='Ravi'
name1='Ravi' \
      'kumar'
name3="Ravi" \
      "kumar"

name4='''Ravi
kumar'''

name5="""Ravi
kumar"""

print(name)#Ravi
print(name1)#Ravikumar

print(name3)#Ravikumar

print(name4)#Ravi
            #kumar

print(name5)#Ravi
            #kumar