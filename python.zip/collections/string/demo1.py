s1="Sathya"
print(s1)
print(s1[0])#S
print(s1[-1])#a

#printing name in reverse
print(s1[::-1])#ayhtaS

#using + operator and * operator

print("----------------------------")

s1="Sathya"
s2="Tech"
s3=s1+s2
print(s1)#Sathya
print(s2)#Tech
print(s3)#SathyaTech

print("-----------------------------")

s1="Python"
s2=s1*10
print(s1)#Python
print(s2)#PythonPythonPythonPythonPythonPythonPythonPythonPythonPython

