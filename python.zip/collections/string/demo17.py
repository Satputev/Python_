#was to display employee name from dynamically input email id
#
# email=input("Enter Email: ")
# print(email.split('@')[0])#Ravikumar
#
#
# print("---------------")
l1=[]
counter=0
while True:
    name=input("Enter Employee Name: ")
    counter+=1

    l1.append((name.split('@')[0]+ str(counter)).capitalize())
    more=input("Add Employee?? y/n:")
    if more.upper()=='Y':

        continue
    else:
        break


print("----------------User Names------------- ")
for x in l1:
    print(x)