s=input("Enter the string:")

for x in s:
    if x <'a' or x >'z':
        print("Not all small letters..")
        break
else:
    print("all small letter alphabets")
