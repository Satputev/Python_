#string is upper

st=input("Enter the string: ")

if st.isupper():
    print("String is in upper case..")
# elif st.islower():
#     print("String is in lowercase")
elif st.isalpha():
    print("Combination of both upper and lower..")
elif st.isalnum():
    print("String is number string..")
elif st.isdigit():
    print("String is digit string..")
elif st.isspace():
    print("String contain whilespace..")
elif st.isprintable():
    print(st)
