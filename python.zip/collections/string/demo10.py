#string modifications

#lowercse

a='ABCDEFG'
b=a.lower()
print(b)#abcdefg


print(id(b))#17593792
print(id(a))#17650592


#uppercase

a='jakshajfhaj'
print(a.upper())#JAKSHAJFHAJ

#delete left side spaces

a='    asdjndbbfb    ewf'

print(a)#    asdjndbbfb    ewf

print(a.lstrip())#asdjndbbfb    ewf

#delete right side spces

a='    jsdfkkdsfj   jksfdj   '
print(a)#    jsdfkkdsfj   jksfdj

print(a.lstrip())#jsdfkkdsfj   jksfdj

print(a.rstrip())#    jsdfkkdsfj   jksfdj

a='    asdf  lkkf     '
print(a)
print(a.strip())