s1="Hai"
print(s1)#Hai
print("--------------")
s1="Ravi"+"Kumar"
print(s1)#RaviKumar

print("------------------------")
s1=10+20
print(s1)#30

print("-----------------------")

s1="10"+"20"
print(s1)#1020

print("------------------------------")

# s1="10"+20
# print(s1)#TypeError: can only concatenate str (not "int") to str
print("----------------")

s1='Python'
s2='Core'+s1
print(s2)#CorePython

print("---------------------")

s1="Ravi Kumar"
for i in s1:
    print(i,end=" ")#R a v i   K u m a r
print("-------------------------")

s1="sathya Technology"
print(s1.capitalize())#Sathya technology

print("-----------------")

s1='sathya Technology'

print(s1.swapcase())#SATHYA tECHNOLOGY
print("-----------------")

s2='core Python and Adv Python are Python'
c=s2.count("java")
print(c)#0

print("---------------------")

phno='9876543210'

if(phno.isdigit()):
    print("valid phone no")
else:
    print("Invalid Phone no..")

#valid phone no

print("---------------------------")

name="Ravi Kumar"
if name.isalpha():
    print("Valid name")
else:
    print("Invalid name")

#Invalid name

print("--------------------")
userid='Ravi12#'
if (userid.isalnum()):
    print("Valid user id")
else:
    print("Invalid user id")#Invalid user id

print("----------------------")

email="RaviKumar@Sathya.com"
s1=email.split('@')
print("User Name is: ",s1[0])#RaviKumar

s1="Ravi Kumar"
print("\n",s1[1:4])## avi

print("-------------------------")

s1="Ravi Kumar"

print("\n",s1[::-1])# ramuK ivaR

print("-------------------")

s1="Sathya Technoogy"
print(s1)
print(s1[0])#S

print("------------------------")

s1="Sathya Technology"

print(s1[1:10:2])#ahaTc

print("----------------------------")

s1="Sathya Technology"
print(s1[1:20:3])#ayThly

print("------------------------------")

s1="Sathya Technology"

print(s1[6:1:-1])# ayht

print("-------------------------")

s2="Python java in Sathya Technology"
if "Python" in s2:
    print("Python is available")
else:
    print("Python is not Available")

#Python is available

print("-------------------------------")

s1=["Python","Java",".net"]
if "Python" in s1:
    print("Python is available")
else:
    print("Python is not available")
#Python is available

print("-----------------------------")

hallticket="112234001"
if hallticket.startswith("1122"):
    print("Start wih code")

#Start wih code
print("-------------------------")
