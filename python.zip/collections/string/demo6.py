#check wheather string contain only digits or not
s='01234hdjj56789'

for x in s:
    if ord(x)<48 or ord(x)>57:
        print("string not contain all digits..")
        break
    else:
        continue
else:
    print("String contail all digits..")
