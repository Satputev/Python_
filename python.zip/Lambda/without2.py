#lambda function can have any no of argument but only one return

#lambda function without argument and without return

#function ex.
def wish():
    print("function example")

wish()#function example



#lambda example

x=lambda :print("lambda example")
x()#lambda example

print("--------------------------------------------------------------------------------")

#with argument without return

#example on function

def add(no1,no2):
    print("the sum =",no1+no2)


add(10,20)#the sum = 30

#lambda example

sum=lambda no1,no2:print("Sum Using lambda is=",no1+no2)
sum(100,300)#Sum Using lambda is= 400


print("--------------------------------------------------------------------------------")

#without argument with return

#example on function

def addition():
    return 10+20
print("the addition is",addition())#the addition is 30


#example on lambda

lsum=lambda:print("the lambda sum is:",56+84)
lsum()#the lambda sum is: 140

print("--------------------------------------------------------------------------------")

#example script on lambda with argument and with return

#function example

def add1(arg1,arg2):
    return arg1+arg2
print("the sum is:",add1(60,20))#the sum is: 80


#lambda example

suml=lambda arg1,arg2:arg1+arg2

print("lambda sum is:",suml(90,40))#lambda sum is: 130
