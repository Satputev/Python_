#example script to display big no
#in this example we are using if condition in lambda function

bigno=lambda no1,no2:no1 if no1>no2 else no2
no1=int(input("Enter 1st no:"))#Enter 1st no:56
no2=int(input("enter 2nd no:"))#enter 2nd no:35

print("The big no is:",bigno(no1,no2))#The big no is: 56
