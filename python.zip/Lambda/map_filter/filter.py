#Filter function expects two arguments,function_object and iterable

#function object return boolean value
#functon object is called for each element of the iterable and filter
#returns only those element for which the function_object return true

#syntax:
#           filter(function_object,iterable)


lst=list(input("enter nos:").split(","))
lis2=[]
for i in lst:
    lis2.append(int(i))



fres=list(filter((lambda x :int(x)%2==0),lis2))

print(fres)#[10, 42, 632, 98, 654, 42]
print("------------------------------------------------")

tpl=50,32,45,84,96,32,21

rest=list(filter((lambda t:t%2==t%3),tpl))
print(rest)#[84, 96]
