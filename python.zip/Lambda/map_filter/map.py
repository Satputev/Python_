#map function expects a function object and any no of iterable like
#list,dictionary,tuple,set,string,file_object,etc.
#it execute the function_object for each element in the squence
#and returns a map of the elements modified by the function object(convert into list)

#syntax:
#           map(function_object,iterable1,iterable2,.....)

#ex1.list

res=map(lambda x:x*2,[10,20,30,40,50,60])
print(res)#<map object at 0x02D403E8>
print(type(res))#<class 'map'>
print(list(res))#[20, 40, 60, 80, 100, 120]

print("--------------------------------------------------------------")

#ex2.tuple

tp=90,80,70,60,50,40

rsTp=list(map((lambda x:x/5),tp))
print(rsTp)#[18.0, 16.0, 14.0, 12.0, 10.0, 8.0]

print("--------------------------------------------------------------")

#ex3.set



stRes1=list(map((lambda x:x*2),{15,55,62,42,22,42,18,85,45}))
print(stRes1)#[84, 90, 30, 36, 170, 44, 110, 124]
print("--------------------------------------------------------------")

f_mark=[60,30,95,45,38,78]
s_mark=[60,90,75,12,30,54]

reslt=list(map((lambda x,y:x+y),f_mark,s_mark))
print(reslt)#[120, 120, 170, 57, 68, 132]

print("--------------------------------------------------------------")

f_res=list(map((lambda x:"PASS" if x>=40 else "FAIL"),f_mark))
print(f_res)#['PASS', 'FAIL', 'PASS', 'PASS', 'FAIL', 'PASS']

print("--------------------------------------------------------------")

s_res=list(map((lambda m:"PASS" if m>=40 else "FAIL"),s_mark))
print(s_res)#['PASS', 'PASS', 'PASS', 'FAIL', 'FAIL', 'PASS']
