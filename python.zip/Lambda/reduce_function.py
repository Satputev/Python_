from functools import reduce
nos=[10,20,30,40,50]
res=reduce(lambda x,y:x+y ,nos )
print(res)#150

res=reduce(lambda x,y:x if x>y else y ,nos)
print(res)