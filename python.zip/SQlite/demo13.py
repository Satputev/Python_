#adding record into table



import sqlite3 as sql

conn=sql.connect("sathya.db")
curs=conn.cursor()
pno=int(input("Enter the product no:"))

curs.execute('select pno from product')
result=curs.fetchall()
for x in result:
    if pno in x:
        print("Pno already available..")
        break
    else:
        continue
else:
    pname = input("Enter the pname:")
    pcost = float(input("Enter the product cost:"))
    pqty = int(input("Enter the product quantity:"))
    try:
        curs.execute('insert into product values(?,?,?,?)', (pno, pname, pcost, pqty))
        conn.commit()
        print("Inserted successfully")
    except sql.IntegrityError:
        print("pno already exist")





conn.close()
print("thanks")

