import sqlite3 as sql
#Reading two columns of row
conn=sql.connect("sathya.db")

curs=conn.cursor()

curs.execute('select pname,pcost from product where pno=1001')
result=curs.fetchone()

for x in result:
    print(x,end=" ")

conn.close()
print("\nthanks")