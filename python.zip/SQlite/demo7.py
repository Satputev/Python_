#Example script to read all records

import sqlite3 as sql

conn=sql.connect("sathya.db")

curs=conn.cursor()

curs.execute("select * from product")
result=curs.fetchall()

print(result)
print("PNO     Name      Price     Quantity")

for x in result:
    for y in x:
        print(y, end="     ")
    print()

conn.close()