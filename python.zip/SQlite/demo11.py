#Reading maxmimum price from all records

import sqlite3 as sql

conn=sql.connect("sathya.db")

curs=conn.cursor()
curs.execute('select max(pcost) from product')
res=curs.fetchone()
if res:
    for x in res:
        print(x)
else:
    print("no records")
conn.close()
print("thanks")