#reading two colums and all rows

import sqlite3 as sql

conn=sql.connect("sathya.db")

curs=conn.cursor()

curs.execute('select pname,pcost from product')

result=curs.fetchall()

if result:
    print("PRODUCT Name     Product COST")
    for x in result:
        for y in x:
            print(y,end="           ")
        print()
else:
    print("records not availabe....")
conn.close()
print("------------------\nthanks")