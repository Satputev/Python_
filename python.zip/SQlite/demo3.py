#step 4
#Insert a one record into table

import sqlite3 as sql

conn=sql.connect("sathya.db")
cur=conn.cursor()

try:
    cur.execute("insert into product values (1001,'Canon',25000.00,15)")
    conn.commit()
    print("Record inserted successfully")
except sql.IntegrityError as e:
    print(e)
conn.close()
print("thanks")