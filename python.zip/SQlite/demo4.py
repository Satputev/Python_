#reading data from keyword/user and insert into table

pno=int(input("Enter the product no:"))
pname=input("Enter the pname:")
pcost=float(input("Enter the product cost:"))
pqty=int(input("Enter the product qty:"))

import sqlite3 as sql

conn=sql.connect("sathya.db")
cur=conn.cursor()


try:
    cur.execute("insert into product values(?,?,?,?)",(pno,pname,pcost,pqty))
    conn.commit()
    print("Data inserted")
except sql.IntegrityError as e:
    print(e,"Insertion fail")

conn.close()
print("thanks")