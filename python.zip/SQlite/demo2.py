#step 2 create cursur object for read/write data into database

#1
import sqlite3 as sql
conn=sql.connect("sathya.db")

#2
cur=conn.cursor()
print(cur)#<sqlite3.Cursor object at 0x03304BA0>

#3
cur.execute("create table product(pno integer unique not null,pname text,pcost real,pqty number)")
conn.close()
print("table created successfully..")
