pno=int(input("Enter product no to delete:"))
import sqlite3 as sql
conn=sql.connect("sathya.db")
curs=conn.cursor()

curs.execute('select pno from product')
result=curs.fetchall()

for x in result:
    if pno in x:
        curs.execute('delete from product where pno=?',(pno,))
        conn.commit()
        print("Deleted successfully")
        break

    else:
        continue
else:
    print("Record does not exist")

conn.close()
print("Thanks")