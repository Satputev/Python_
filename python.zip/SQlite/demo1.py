#step 1 create connection using connect() method

import sqlite3 as sql

conn=sql.connect("sathya.db")
print(conn)#<sqlite3.Connection object at 0x007F3D68>
