#delete record


pno=int(input("Enter the product no:"))

import sqlite3 as sql

conn=sql.connect("sathya.db")
cur=conn.cursor()

try:
    cur.execute("delete from product where pno=?",(pno,))
    conn.commit()
    print("deleted successfully..")

except sql.IntegrityError as e:
    print(e)

conn.close()
print("thanks")