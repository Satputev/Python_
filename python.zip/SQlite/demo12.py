#finding average cost of products

import sqlite3 as sql
conn=sql.connect("sathya.db")

curs=conn.cursor()

curs.execute("select avg(pcost) from product")
res=curs.fetchone()

print(res)

