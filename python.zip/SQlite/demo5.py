pno=int(input("Enter the product no:"))
pprice=float(input("Enter the product cost:"))

import sqlite3 as sql

conn=sql.connect("sathya.db")
cur=conn.cursor()

try:
    cur.execute("update product set pcost=? where pno=?",(pprice,pno))
    conn.commit()
    print("Data updated successfully...")
except sql.IntegrityError as e:
    print(e)

conn.close()
print("thanks")