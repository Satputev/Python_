import sqlite3 as sql

conn=sql.connect("sathya.db")
curs=conn.cursor()
pno=int(input("Enter the product no:"))
#reading all columns from perticular row

curs.execute('select * from product where pno=?',(pno,))
result=curs.fetchone()
if result:
    for x in result:
        print(x, end=" ")
else:
    print("Product no is not available")
conn.close()
print("\nthanks")
