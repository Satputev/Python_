def fun1(n):
    sum1=0
    for x in range(n+1):
        sum1+=x
    return sum1

def fun2(n):
    return (n*(n+1)/2)

print(fun1(5),fun2(5))

# built in commond in notebook
# %timeit sum1(100)
# %timeit sum2(100)