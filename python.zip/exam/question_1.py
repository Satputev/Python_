

file=open("demo.txt")
