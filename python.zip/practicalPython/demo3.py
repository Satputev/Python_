from contextlib import contextmanager

@contextmanager
def CustomLog(*args):
    print('This is the start of custom manager!')
    try:
        print('This is try block')

    except:
        print('This is Except block!')
    finally:
        print('This is finally block!')
    print('This is the end of the block!')

with CustomLog('index.txt','a') as customfile:
    customfile.write ('This is going to fail')