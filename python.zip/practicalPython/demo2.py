import csv,os,argparse

def coroutines_dec(fun):
    def wrap(*args,**kwargs):
        corouted=fun(*args,**kwargs)
        corouted.__next__()
        return corouted
    return wrap