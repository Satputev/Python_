alist=[10,20,30]
blist=alist[:]
print(blist)
print(alist)

class a:
    pass

a=a()
alist.append(a)
print(alist)#[10, 20, 30, <__main__.a object at 0x000001FBDEB25B50>]

print(blist)#[10, 20, 30]

blist.append(5)
print(alist)#[10, 20, 30, <__main__.a object at 0x000001FBDEB25B50>]

print(blist)#[10, 20, 30, 5]

