#import libraries

import  numpy as np
import pandas as pd
import matplotlib.pyplot as plt

path=r"E:\datasets\motor.csv"
df=pd.read_csv(path)
df.head()
df.tail()
df.shape