#stack is the last-in-first-out data structure

#for pushing element to stack we use append() method

stack=[]
stack.append(10)
stack.append(20)
stack.append(30)
stack.append(40)
print(stack)

print(stack.pop())
print(stack.pop())

