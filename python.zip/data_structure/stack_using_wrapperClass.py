class StackWrapper:
    def __init__(self):
        self.my_stack=list()

    def push(self,element):
        self.my_stack.append(element)

    def pop(self):
        if len(self.my_stack) >0:
            return self.my_stack.pop()
        else:
            return None
    def peek(self):
        if len(self.my_stack)>0:
            return self.my_stack[-1]
        else:
            return None
    def __str__(self):
        return str(self.my_stack)

st=StackWrapper()
st.push(10)
st.push(20)
print(st)
print(st.peek())
print(st.pop())
print(st.pop())
print(st.peek())
print(st.pop())